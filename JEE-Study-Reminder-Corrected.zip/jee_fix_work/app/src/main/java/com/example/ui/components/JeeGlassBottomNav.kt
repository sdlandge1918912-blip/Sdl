package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class JeeNavTabItem(
    val title: String,
    val icon: ImageVector,
    val hasBadge: Boolean = false,
    val badgeNumber: Int = 0,
    val tag: String
)

@Composable
fun JeeGlassBottomNav(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // 5 Clean Tabs: HOME, ROUTINE, 11TH, PRACTICE, VIDEOS
    val items = listOf(
        JeeNavTabItem("HOME", Icons.Outlined.Home, tag = "nav_home"),
        JeeNavTabItem("ROUTINE", Icons.Outlined.Today, tag = "nav_routine"),
        JeeNavTabItem("11TH", Icons.Outlined.School, tag = "nav_11th"),
        JeeNavTabItem("PRACTICE", Icons.Outlined.TrackChanges, tag = "nav_practice"),
        JeeNavTabItem("VIDEOS", Icons.Outlined.SmartDisplay, tag = "nav_videos")
    )

    // Floating Capsule Bar with margins and 32dp rounded stadium corners
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Color(0xF50A1120))
            .border(
                BorderStroke(1.2.dp, Color(0x3B38BDF8)),
                RoundedCornerShape(32.dp)
            )
            .padding(horizontal = 4.dp, vertical = 4.dp)
            .testTag("jee_glass_bottom_navigation")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { index, item ->
                val isSelected = selectedTab == index
                val interactionSource = remember { MutableInteractionSource() }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            if (isSelected) Color(0x521E3A8A)
                            else Color.Transparent
                        )
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null
                        ) { onSelectTab(index) }
                        .padding(vertical = 4.dp, horizontal = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Top active indicator dash (as in second photo above active HOME tab)
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .width(22.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color(0xFF38BDF8))
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                        } else {
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        // Icon with optional badge
                        BadgedBox(
                            badge = {
                                if (item.hasBadge && item.badgeNumber > 0) {
                                    Badge(
                                        containerColor = Color(0xFFEF4444),
                                        contentColor = Color.White,
                                        modifier = Modifier.offset(x = 4.dp, y = (-2).dp)
                                    ) {
                                        Text(
                                            text = item.badgeNumber.toString(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = if (isSelected) Color(0xFF38BDF8) else Color(0xFF8E9CB2),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        // Single-line non-wrapping label with compact typography
                        Text(
                            text = item.title,
                            fontSize = 8.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF8E9CB2),
                            letterSpacing = (-0.3).sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
            }
        }
    }
}
