package com.example.data.model

import java.util.Calendar
import java.util.Locale

data class AlarmItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val hour: Int,
    val minute: Int,
    val label: String = "JEE Study Alarm",
    val repeatDays: Set<Int> = setOf(
        Calendar.SUNDAY,
        Calendar.MONDAY,
        Calendar.TUESDAY,
        Calendar.WEDNESDAY,
        Calendar.THURSDAY,
        Calendar.FRIDAY,
        Calendar.SATURDAY
    ),
    val isEnabled: Boolean = true,
    val isVibrationEnabled: Boolean = true,
    val isSnoozeEnabled: Boolean = true
) {
    fun getFormattedTime(): String {
        val amPm = if (hour >= 12) "PM" else "AM"
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return String.format(Locale.getDefault(), "%02d:%02d", displayHour, minute)
    }

    fun getAmPm(): String {
        return if (hour >= 12) "PM" else "AM"
    }

    fun getRepeatDaysSummary(): String {
        if (repeatDays.isEmpty()) return "Never"
        if (repeatDays.size == 7) return "Every day"
        val weekdays = setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)
        val weekends = setOf(Calendar.SATURDAY, Calendar.SUNDAY)
        if (repeatDays == weekdays) return "Weekdays"
        if (repeatDays == weekends) return "Weekends"

        val dayNames = listOf(
            Calendar.SUNDAY to "Sun",
            Calendar.MONDAY to "Mon",
            Calendar.TUESDAY to "Tue",
            Calendar.WEDNESDAY to "Wed",
            Calendar.THURSDAY to "Thu",
            Calendar.FRIDAY to "Fri",
            Calendar.SATURDAY to "Sat"
        )
        return dayNames.filter { it.first in repeatDays }.joinToString(", ") { it.second }
    }
}
