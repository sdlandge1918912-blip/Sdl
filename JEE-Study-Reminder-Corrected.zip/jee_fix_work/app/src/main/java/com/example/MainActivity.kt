package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.ui.MainScreen
import com.example.ui.theme.JeeReminderTheme
import com.example.ui.viewmodel.JeeViewModel

class MainActivity : ComponentActivity() {

    companion object {
        const val EXTRA_NAV_TAB = "extra_nav_tab"
    }

    private val currentTab = mutableIntStateOf(0)
    private var viewModelRef: JeeViewModel? = null
    private var appForegroundJob: Job? = null

    override fun onResume() {
        super.onResume()
        viewModelRef?.refreshShieldState()
        viewModelRef?.refreshStudyTimeStats()
        startAppForegroundTracking()
    }

    override fun onPause() {
        super.onPause()
        stopAppForegroundTracking()
    }

    private fun startAppForegroundTracking() {
        appForegroundJob?.cancel()
        appForegroundJob = lifecycleScope.launch {
            while (true) {
                delay(1000L)
                com.example.service.StudyTimeTracker.recordAppOpenTick(this@MainActivity, 1)
            }
        }
    }

    private fun stopAppForegroundTracking() {
        appForegroundJob?.cancel()
        appForegroundJob = null
        com.example.service.StudyTimeTracker.triggerWidgetsRefresh(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val tab = intent?.getIntExtra(EXTRA_NAV_TAB, 0) ?: 0
        currentTab.intValue = tab

        setContent {
            JeeReminderTheme {
                val viewModel: JeeViewModel = viewModel()
                viewModelRef = viewModel

                // Request notification permission on Android 13+
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    // Reschedule immediately upon permission grant
                    viewModel.scheduleAllSectionAlarms()
                }

                LaunchedEffect(Unit) {
                    // Always schedule alarms so AlarmManager has exact wakeups
                    viewModel.scheduleAllSectionAlarms()

                    // Ensure daily 12:00 AM app usage calculation & rollover alarm is armed
                    com.example.util.JeeNotificationHelper.scheduleMidnightRollover(this@MainActivity)

                    // If Strict Study Mode is active, ensure foreground guard service is running
                    if (com.example.service.FocusShieldManager.isFocusShieldActive(this@MainActivity)) {
                        com.example.service.FocusShieldManager.startStrictStudyService(this@MainActivity)
                    }

                    // Attempt silent auto-sign in for parent telemetry link
                    val credManager = androidx.credentials.CredentialManager.create(this@MainActivity)
                    com.example.auth.GoogleAuthManager.attemptAutoSignIn(
                        context = this@MainActivity,
                        credentialManager = credManager,
                        onAuthSuccess = {
                            viewModel.parentTelemetryRepo.restartParentLinkObserver()
                        },
                        onUnauthenticated = {},
                        scope = lifecycleScope
                    )

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(
                        viewModel = viewModel,
                        initialTab = currentTab.intValue
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val tab = intent.getIntExtra(EXTRA_NAV_TAB, -1)
        if (tab >= 0) {
            currentTab.intValue = tab
        }
    }
}
