package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routine_sessions")
data class RoutineSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // "Physics", "Chemistry", "Mathematics", "Walking/relaxation", "Breaks", "Coaching/classes", "Revision", "Dinner", "Sleep"
    val startTime: String, // e.g. "05:45"
    val endTime: String,   // e.g. "06:00"
    val title: String,     // e.g. "Wake Up + Water & Freshen"
    val emoji: String = "📚",     // e.g. "🌅"
    val focusTopic: String? = null, // e.g. "Theory concepts, derivations & numerical problems"
    val description: String = "",  // e.g. "Wake up, drink 500ml water, and freshen up for the day."
    val days: String = "S,M,T,W,T,F,S", // comma-separated active days
    val isNotificationEnabled: Boolean = true,
    val alertMinutesBefore: Int = 10,
    val displayTime: String = "",
    val orderIndex: Int = 0
) {
    fun getFormattedTime(): String {
        if (displayTime.isNotBlank()) return displayTime
        return if (startTime == endTime) startTime else "$startTime–$endTime"
    }

    fun isStudySlot(): Boolean {
        val nonStudyKeywords = listOf("break", "walk", "freshen", "breakfast", "lunch", "dinner", "sleep", "nap", "water", "wake")
        val catLower = category.trim().lowercase()
        val titleLower = title.trim().lowercase()
        return nonStudyKeywords.none { catLower.contains(it) || titleLower.contains(it) }
    }
}
