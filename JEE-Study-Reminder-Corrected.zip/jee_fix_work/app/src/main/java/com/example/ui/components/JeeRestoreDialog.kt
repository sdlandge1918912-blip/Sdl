package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.JeeViewModel

@Composable
fun JeeRestoreDialog(
    viewModel: JeeViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Defaults, 1: JSON Backup
    var showFullResetConfirm by remember { mutableStateOf(false) }
    var showRoutineResetConfirm by remember { mutableStateOf(false) }
    var showSyllabusResetConfirm by remember { mutableStateOf(false) }
    var showRemindersResetConfirm by remember { mutableStateOf(false) }

    var importJsonText by remember { mutableStateOf("") }
    var showImportField by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xF70A1120),
        shape = RoundedCornerShape(26.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("restore_backup_dialog")
            .border(BorderStroke(1.2.dp, Color(0x4038BDF8)), RoundedCornerShape(26.dp)),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF0284C7), Color(0xFF2563EB))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Restore,
                            contentDescription = "Restore Hub",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Restore & Backup",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "100% Offline • Local Recovery v2.2",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(0x33475569))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Segmented Tabs: Defaults / Local JSON
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    RestoreTabButton(
                        title = "Factory Defaults",
                        icon = Icons.Default.RestartAlt,
                        isSelected = selectedTab == 0,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 0 }
                    )
                    RestoreTabButton(
                        title = "File / JSON Backup",
                        icon = Icons.Default.DataObject,
                        isSelected = selectedTab == 1,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 1 }
                    )
                }

                when (selectedTab) {
                    // TAB 0: FACTORY & SPECIFIC DEFAULTS RESTORE
                    0 -> {
                        // 1. Factory Reset Master Action
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0x661E3A8A), Color(0x663B82F6))
                                    )
                                )
                                .border(BorderStroke(1.dp, Color(0xFF38BDF8)), RoundedCornerShape(18.dp))
                                .padding(14.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF0284C7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SettingsBackupRestore,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Restore All to Factory Defaults",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "Complete fresh reset: 24h routine, syllabus, alarms & theme",
                                            fontSize = 11.sp,
                                            color = Color(0xFFBAE6FD)
                                        )
                                    }
                                }

                                Button(
                                    onClick = { showFullResetConfirm = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Restore Complete JEE System", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        Text(
                            text = "SELECTIVE RESTORE OPTIONS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8),
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(start = 2.dp, top = 2.dp)
                        )

                        // 2. Restore 24h Timetable
                        RestoreOptionCard(
                            icon = Icons.Default.CalendarToday,
                            iconTint = Color(0xFF38BDF8),
                            iconBg = Color(0xFF0C4A6E),
                            title = "Restore 24-Hour Timetable",
                            subtitle = "Reverts to official 21-session JEE daily routine (Physics, Chem, Maths, coaching, breaks)",
                            buttonLabel = "Restore Routine",
                            onClick = { showRoutineResetConfirm = true }
                        )

                        // 3. Restore Class 11 & 12 Syllabus
                        RestoreOptionCard(
                            icon = Icons.Default.MenuBook,
                            iconTint = Color(0xFF34D399),
                            iconBg = Color(0xFF064E3B),
                            title = "Restore Full Syllabus Tracker",
                            subtitle = "Reloads full NCERT chapter breakdown for Class 11th & 12th Physics, Chemistry & Maths",
                            buttonLabel = "Restore Syllabus",
                            onClick = { showSyllabusResetConfirm = true }
                        )

                        // 4. Restore Timetable Reminders & Alarms
                        RestoreOptionCard(
                            icon = Icons.Default.Alarm,
                            iconTint = Color(0xFFFBBF24),
                            iconBg = Color(0xFF78350F),
                            title = "Restore Timetable Reminders",
                            subtitle = "Reschedules 10 official daily timetable alarms and notification triggers",
                            buttonLabel = "Restore Alarms",
                            onClick = { showRemindersResetConfirm = true }
                        )

                        // 5. Restore Target Exam (JEE 2028 / 2026)
                        RestoreOptionCard(
                            icon = Icons.Default.Timer,
                            iconTint = Color(0xFFA78BFA),
                            iconBg = Color(0xFF3B0764),
                            title = "Restore Target JEE Exam",
                            subtitle = "Sets primary countdown to JEE 2028 (Session 1 & Advanced) & JEE 2026",
                            buttonLabel = "Restore Exam",
                            onClick = {
                                viewModel.resetToDefaultJee2028Exams()
                                Toast.makeText(context, "JEE 2028 target countdown restored!", Toast.LENGTH_SHORT).show()
                            }
                        )

                        // 6. Restore Default Cosmic Theme
                        RestoreOptionCard(
                            icon = Icons.Default.Palette,
                            iconTint = Color(0xFFF472B6),
                            iconBg = Color(0xFF831843),
                            title = "Restore Default Cosmic Theme",
                            subtitle = "Resets desk wallpaper, glassmorphism blur intensity, and background dimming",
                            buttonLabel = "Restore Theme",
                            onClick = {
                                viewModel.resetBackgroundToDefault()
                                Toast.makeText(context, "Default Cosmic theme restored!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    // TAB 1: JSON EXPORT & IMPORT BACKUP
                    1 -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x80182236))
                                .border(BorderStroke(1.dp, Color(0x3338BDF8)), RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "Export Local Snapshot",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Generate a complete backup snapshot of all routine slots, syllabus completion, reminders, and study notes on your device.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF94A3B8)
                                )

                                Button(
                                    onClick = {
                                        val backupJson = viewModel.exportBackupJson()
                                        clipboardManager.setText(AnnotatedString(backupJson))
                                        Toast.makeText(context, "Complete backup JSON copied to clipboard!", Toast.LENGTH_LONG).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Copy Full Backup JSON to Clipboard", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }

                                Divider(color = Color(0x3360A5FA), modifier = Modifier.padding(vertical = 4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Restore from JSON",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                    TextButton(onClick = { showImportField = !showImportField }) {
                                        Text(if (showImportField) "Hide Input" else "Paste JSON", fontSize = 11.sp, color = Color(0xFF38BDF8))
                                    }
                                }

                                if (showImportField) {
                                    OutlinedTextField(
                                        value = importJsonText,
                                        onValueChange = { importJsonText = it },
                                        placeholder = { Text("Paste backup JSON here...", fontSize = 11.sp, color = Color(0xFF64748B)) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 90.dp, max = 150.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color(0xFF38BDF8),
                                            unfocusedBorderColor = Color(0xFF334155),
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(10.dp)
                                    )

                                    Button(
                                        onClick = {
                                            if (importJsonText.isBlank()) {
                                                Toast.makeText(context, "Please paste valid backup JSON first", Toast.LENGTH_SHORT).show()
                                            } else {
                                                viewModel.restoreFromJson(importJsonText) { success, msg ->
                                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                                    if (success) {
                                                        importJsonText = ""
                                                        showImportField = false
                                                    }
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Execute JSON Restore", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Close", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )

    // Confirmation Dialogs
    if (showFullResetConfirm) {
        RestoreConfirmationDialog(
            title = "Restore All to Factory Defaults?",
            message = "This will restore the complete JEE system: 24-hr routine (21 sessions), full NCERT Class 11 & 12 syllabus, official study alarms, JEE 2028 countdown, and default cosmic wallpaper. Any custom timetable edits will be reset.",
            confirmButtonText = "Restore All Defaults",
            onConfirm = {
                viewModel.restoreAllDefaults { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
                showFullResetConfirm = false
            },
            onDismiss = { showFullResetConfirm = false }
        )
    }

    if (showRoutineResetConfirm) {
        RestoreConfirmationDialog(
            title = "Restore 24-Hour Timetable?",
            message = "This will restore the 21 optimized JEE daily slots (Physics, Chemistry, Maths, Coaching, Meals, Breaks & Sleep) to default.",
            confirmButtonText = "Restore Timetable",
            onConfirm = {
                viewModel.restoreDefaultRoutine { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
                showRoutineResetConfirm = false
            },
            onDismiss = { showRoutineResetConfirm = false }
        )
    }

    if (showSyllabusResetConfirm) {
        RestoreConfirmationDialog(
            title = "Restore Syllabus Tracker?",
            message = "Choose to either reset completion checkboxes to 0% or restore the complete NCERT Class 11th & 12th syllabus list.",
            confirmButtonText = "Restore Full Syllabus",
            onConfirm = {
                viewModel.restoreDefaultSyllabus(resetProgressOnly = false) { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
                showSyllabusResetConfirm = false
            },
            onDismiss = { showSyllabusResetConfirm = false }
        )
    }

    if (showRemindersResetConfirm) {
        RestoreConfirmationDialog(
            title = "Restore Timetable Reminders?",
            message = "This will restore the 10 scheduled routine reminders aligned with your daily timetable.",
            confirmButtonText = "Restore Reminders",
            onConfirm = {
                viewModel.restoreDefaultReminders { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
                showRemindersResetConfirm = false
            },
            onDismiss = { showRemindersResetConfirm = false }
        )
    }
}

@Composable
private fun RestoreTabButton(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(if (isSelected) Color(0xFF2563EB) else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.White else Color(0xFF94A3B8),
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF94A3B8)
            )
        }
    }
}

@Composable
private fun RestoreOptionCard(
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    title: String,
    subtitle: String,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x80182236))
            .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = subtitle,
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8),
                        lineHeight = 13.sp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0x4060A5FA)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(buttonLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                }
            }
        }
    }
}

@Composable
private fun RestoreConfirmationDialog(
    title: String,
    message: String,
    confirmButtonText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF131929),
        shape = RoundedCornerShape(20.dp),
        icon = {
            Icon(
                imageVector = Icons.Default.WarningAmber,
                contentDescription = null,
                tint = Color(0xFFF59E0B),
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Text(
                text = message,
                color = Color(0xFFCBD5E1),
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(confirmButtonText, color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}
