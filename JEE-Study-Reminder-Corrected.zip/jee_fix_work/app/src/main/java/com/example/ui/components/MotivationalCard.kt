package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JeeAccentGold
import com.example.ui.theme.JeeNavy
import com.example.ui.theme.JeePrimary

private val JEE_TIPS = listOf(
    "Target 99+ Percentile: Accuracy > Speed. Every negative mark costs you thousands of ranks.",
    "NCERT Chemistry is pure gold for JEE Main. Don't skip in-text tables & lab test reactions.",
    "Physics Modern Physics + Thermodynamics + Optics carry 35%+ direct weightage with minimal math traps.",
    "Mathematics Question Selection Strategy: Solve the 10 easiest questions first, don't get trapped in 1 question for 10 mins.",
    "Sunday Mock Routine: 3 hours non-stop sitting from 9 AM to 12 PM with 0 phone distractions.",
    "Formula revision before sleep cements neural pathways. An error notebook reviewed daily prevents repeated slips."
)

@Composable
fun MotivationalCard(modifier: Modifier = Modifier) {
    var tipIndex by remember { mutableIntStateOf(0) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("motivational_card"),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(JeeNavy, JeePrimary)
                    )
                )
                .padding(16.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "JEE Tip Icon",
                        tint = JeeAccentGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "IIT-JEE TOPPER STRATEGY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = JeeAccentGold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(
                        onClick = {
                            tipIndex = (tipIndex + 1) % JEE_TIPS.size
                        },
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("refresh_tip_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Next tip",
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "\"${JEE_TIPS[tipIndex]}\"",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontStyle = FontStyle.Italic,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
