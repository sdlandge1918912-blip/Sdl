package com.example.ui.components

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widget.JeeRoutineWidgetProvider
import com.example.widget.OngoingSectionWidgetProvider

@Composable
fun JeeSettingsDialog(
    onDismiss: () -> Unit,
    onOpenWallpaper: () -> Unit,
    onApkClick: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenWhatsNew: () -> Unit,
    isSectionAlarmsEnabled: Boolean = true,
    onToggleSectionAlarms: (Boolean) -> Unit = {},
    onTestSectionAlarm: () -> Unit = {},
    unreadNotificationsCount: Int = 10,
    isStrictStudyEnabled: Boolean = false,
    onToggleStrictStudy: (Boolean) -> Unit = {},
    onOpenStrictStudyMode: () -> Unit = {},
    onOpenRestoreBackup: () -> Unit = {},
    onOpenParentConnect: () -> Unit = {},
    parentPairingStatus: String = ""
) {
    val context = LocalContext.current
    var showWidgetDialog by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xF70C1322),
        shape = RoundedCornerShape(26.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.2.dp, Color(0x3360A5FA)), RoundedCornerShape(26.dp)),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E3A8A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color(0xFF60A5FA),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Settings & Tools",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "JEE Study System v2.2",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(0x33475569))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // SECTION 1: TIMETABLE ALARMS & BACKGROUND NOTIFICATIONS
                Text(
                    text = "SECTION START ALARMS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                )

                // Section Start Alarm Settings Card with Toggle & Test Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x80182236))
                        .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSectionAlarmsEnabled) Color(0xFF1B382B) else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSectionAlarmsEnabled) Icons.Default.AlarmOn else Icons.Default.AlarmOff,
                                        contentDescription = null,
                                        tint = if (isSectionAlarmsEnabled) Color(0xFF34D399) else Color(0xFF94A3B8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Section Start Alarm",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isSectionAlarmsEnabled) "Exact System AlarmClock (Fires when app closed)" else "Alarms paused",
                                        fontSize = 10.sp,
                                        color = if (isSectionAlarmsEnabled) Color(0xFF34D399) else Color(0xFF94A3B8)
                                    )
                                }
                            }

                            Switch(
                                checked = isSectionAlarmsEnabled,
                                onCheckedChange = { onToggleSectionAlarms(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF059669),
                                    uncheckedThumbColor = Color(0xFF94A3B8),
                                    uncheckedTrackColor = Color(0xFF334155)
                                )
                            )
                        }

                        // Test Alarm Button & Doze Explainer
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Bypasses battery saver & Doze mode",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )

                            Button(
                                onClick = { onTestSectionAlarm() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Test Alert", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                // SECTION 2: STRICT STUDY MODE & APP BLOCKER
                Text(
                    text = "STRICT STUDY MODE & APP BLOCKER",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                // Strict Study Mode Card with Quick Switch & Manage Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isStrictStudyEnabled) Color(0x660F291E) else Color(0x80182236))
                        .border(
                            BorderStroke(
                                1.dp,
                                if (isStrictStudyEnabled) Color(0xFF10B981) else Color(0x2660A5FA)
                            ),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isStrictStudyEnabled) Color(0xFF10B981) else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = if (isStrictStudyEnabled) Color.Black else Color(0xFF94A3B8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Strict Study Guard",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isStrictStudyEnabled) "Distractions Blocked • Study Slot Protected" else "App blocker inactive",
                                        fontSize = 10.sp,
                                        color = if (isStrictStudyEnabled) Color(0xFF34D399) else Color(0xFF94A3B8)
                                    )
                                }
                            }

                            Switch(
                                checked = isStrictStudyEnabled,
                                onCheckedChange = { onToggleStrictStudy(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF10B981),
                                    uncheckedThumbColor = Color(0xFF94A3B8),
                                    uncheckedTrackColor = Color(0xFF334155)
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Blocks Instagram, YouTube, games & more",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )

                            Button(
                                onClick = {
                                    onDismiss()
                                    onOpenStrictStudyMode()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Configure Apps", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                // SECTION: PARENT OVERSIGHT & DASHBOARD SYNC
                Text(
                    text = "PARENT DASHBOARD & SYNC",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                SettingsOptionItem(
                    icon = Icons.Default.SupervisorAccount,
                    iconBgColor = Color(0xFF0C4A6E),
                    iconTint = Color(0xFF38BDF8),
                    title = "Parent Connect / Oversight",
                    subtitle = if (parentPairingStatus.isNotBlank()) parentPairingStatus else "Pair with Study Dashboard using code JEE789",
                    badgeText = "JEE789",
                    badgeColor = Color(0xFF0284C7),
                    onClick = {
                        onDismiss()
                        onOpenParentConnect()
                    }
                )

                // SECTION 3: HOME SCREEN WIDGETS
                Text(
                    text = "HOME SCREEN WIDGETS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                // Widget Settings Button
                SettingsOptionItem(
                    icon = Icons.Default.Dashboard,
                    iconBgColor = Color(0xFF1E293B),
                    iconTint = Color(0xFF38BDF8),
                    title = "Home Screen Widgets",
                    subtitle = "Ongoing Section Live Card & Full Routine widgets",
                    badgeText = "2 Ready",
                    badgeColor = Color(0xFF0284C7),
                    onClick = { showWidgetDialog = true }
                )

                // SECTION 3: APPEARANCE & WALLPAPER
                Text(
                    text = "APPEARANCE & WALLPAPER",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                // Wallpaper Customization Button
                SettingsOptionItem(
                    icon = Icons.Default.Image,
                    iconBgColor = Color(0xFF1E3A8A),
                    iconTint = Color(0xFF60A5FA),
                    title = "Wallpaper & Glass Blur",
                    subtitle = "Customize desk photo, blur intensity & dimming",
                    badgeText = "Custom",
                    badgeColor = Color(0xFF2563EB),
                    onClick = {
                        onDismiss()
                        onOpenWallpaper()
                    }
                )

                // SECTION 4: BACKUP & RESTORE DATA
                Text(
                    text = "BACKUP & RESTORE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                // Restore & Backup Hub Button
                SettingsOptionItem(
                    icon = Icons.Default.Restore,
                    iconBgColor = Color(0xFF0C4A6E),
                    iconTint = Color(0xFF38BDF8),
                    title = "Restore & Backup Hub",
                    subtitle = "Restore default timetable, syllabus, or sync from cloud",
                    badgeText = "Restore Data",
                    badgeColor = Color(0xFF0284C7),
                    onClick = {
                        onDismiss()
                        onOpenRestoreBackup()
                    }
                )

                // SECTION 5: DOWNLOADS & ALERTS
                Text(
                    text = "DOWNLOADS & ALERTS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                // APK Button
                SettingsOptionItem(
                    icon = Icons.Default.Download,
                    iconBgColor = Color(0xFF064E3B),
                    iconTint = Color(0xFF34D399),
                    title = "Download APK (v2.2)",
                    subtitle = "Package updated in root: JEE_Reminder_v2.2.apk (29 MB)",
                    badgeText = "v2.2 Ready",
                    badgeColor = Color(0xFF059669),
                    onClick = { onApkClick() }
                )

                // Notifications Button
                SettingsOptionItem(
                    icon = Icons.Default.Notifications,
                    iconBgColor = Color(0xFF431407),
                    iconTint = Color(0xFFFB923C),
                    title = "Alarms & Notifications",
                    subtitle = "Manage 10 scheduled routine reminders & daily alerts",
                    badgeText = if (unreadNotificationsCount > 0) "$unreadNotificationsCount active" else "Active",
                    badgeColor = Color(0xFFEA580C),
                    onClick = {
                        onDismiss()
                        onOpenNotifications()
                    }
                )

                // SECTION 5: ABOUT
                Text(
                    text = "ABOUT & UPDATES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )

                // What's New Button
                SettingsOptionItem(
                    icon = Icons.Default.AutoAwesome,
                    iconBgColor = Color(0xFF3B0764),
                    iconTint = Color(0xFFC084FC),
                    title = "What's New in Update v2.2",
                    subtitle = "100% offline, privacy mode, and full restore hub",
                    badgeText = "v2.2",
                    badgeColor = Color(0xFF7C3AED),
                    onClick = {
                        onDismiss()
                        onOpenWhatsNew()
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Close", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )

    // Widget Installation & Pin Dialog
    if (showWidgetDialog) {
        AlertDialog(
            onDismissRequest = { showWidgetDialog = false },
            containerColor = Color(0xFF131929),
            shape = RoundedCornerShape(22.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Widgets,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Home Screen Widgets",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "You can add these 2 widgets to your phone's Home Screen for instant live updates:",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )

                    // Widget 1: Ongoing Section
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x661E293B))
                            .border(BorderStroke(1.dp, Color(0x3338BDF8)), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("⚡ Ongoing Section Widget", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                                Button(
                                    onClick = {
                                        pinWidget(context, OngoingSectionWidgetProvider::class.java)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("+ Add", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Shows currently active JEE session, focus topic, remaining time countdown, and quick stopwatch launcher.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    // Widget 2: Full Routine
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x661E293B))
                            .border(BorderStroke(1.dp, Color(0x3310B981)), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("📋 Full Timetable Routine", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                                Button(
                                    onClick = {
                                        pinWidget(context, JeeRoutineWidgetProvider::class.java)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("+ Add", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Full scrollable day timetable with morning, coaching, and evening slots right on your home screen.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    Text(
                        text = "Tip: You can also long-press any empty space on your phone home screen -> Tap 'Widgets' -> Choose 'JEE Reminder'.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showWidgetDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Got It", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

private fun pinWidget(context: Context, providerClass: Class<*>) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val appWidgetManager = context.getSystemService(AppWidgetManager::class.java)
        val myProvider = ComponentName(context, providerClass)
        if (appWidgetManager.isRequestPinAppWidgetSupported) {
            val successCallback = PendingIntent.getBroadcast(
                context,
                0,
                Intent(context, providerClass),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            appWidgetManager.requestPinAppWidget(myProvider, null, successCallback)
            Toast.makeText(context, "Adding widget to Home screen...", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                context,
                "Launcher doesn't support auto-pinning. Please long-press home screen -> Widgets -> JEE Reminder",
                Toast.LENGTH_LONG
            ).show()
        }
    } else {
        Toast.makeText(
            context,
            "Long press home screen -> Widgets -> JEE Reminder",
            Toast.LENGTH_LONG
        ).show()
    }
}

@Composable
private fun SettingsOptionItem(
    icon: ImageVector,
    iconBgColor: Color,
    iconTint: Color,
    title: String,
    subtitle: String,
    badgeText: String? = null,
    badgeColor: Color = Color(0xFF2563EB),
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x80182236))
            .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    if (badgeText != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badgeColor)
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = badgeText,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 14.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = Color(0xFF64748B),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
