package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.database.AppDatabase
import com.example.data.database.DefaultJeeData
import com.example.data.model.RoutineSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class JeeRoutineWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == ACTION_REFRESH_WIDGET ||
            action == Intent.ACTION_TIME_TICK ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == ACTION_SECTION_CHANGED ||
            action == AppWidgetManager.ACTION_APPWIDGET_UPDATE
        ) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, JeeRoutineWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId)
            }
        }
    }

    companion object {
        const val ACTION_REFRESH_WIDGET = "com.example.widget.ACTION_REFRESH_WIDGET"
        const val ACTION_SECTION_CHANGED = "com.example.widget.ACTION_SECTION_CHANGED"

        fun updateAllWidgets(context: Context) {
            try {
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val thisWidget = ComponentName(context, JeeRoutineWidgetProvider::class.java)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
                if (appWidgetIds.isNotEmpty()) {
                    for (id in appWidgetIds) {
                        updateAppWidget(context, appWidgetManager, id)
                    }
                }
            } catch (e: Exception) {
                Log.e("JeeRoutineWidget", "Failed to update widgets", e)
            }
        }

        private fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            // 1. Immediately render with default data so launcher never gets an empty / uninflated state
            val initialList = DefaultJeeData.getDefaultRoutineSessions()
            renderWidget(context, appWidgetManager, appWidgetId, initialList)

            // 2. Asynchronously fetch from database and update if custom user entries exist
            val scope = CoroutineScope(Dispatchers.IO)
            scope.launch {
                try {
                    val db = AppDatabase.getDatabase(context, scope)
                    val dbList = db.routineSessionDao().getAllRoutineSessionsSync()
                    val finalList = if (dbList.isNotEmpty()) dbList else initialList
                    withContext(Dispatchers.Main) {
                        renderWidget(context, appWidgetManager, appWidgetId, finalList)
                    }
                } catch (e: Exception) {
                    Log.w("JeeRoutineWidget", "Could not fetch DB sessions, rendered default", e)
                }
            }
        }

        private fun renderWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            sessions: List<RoutineSession>
        ) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_jee_routine)

                // Current time calculation
                val now = Calendar.getInstance()
                val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

                var activeSession: RoutineSession? = null
                var activeRemainingMin = 0

                // Find currently active session
                for (session in sessions) {
                    val startM = parseTimeToMinutes(session.startTime)
                    val endM = parseTimeToMinutes(session.endTime)
                    if (startM != null && endM != null) {
                        val isOngoing = if (endM > startM) {
                            currentMinutes in startM until endM
                        } else if (endM < startM) {
                            currentMinutes >= startM || currentMinutes < endM
                        } else {
                            currentMinutes in startM until (startM + 15)
                        }

                        if (isOngoing) {
                            activeSession = session
                            val actualEnd = if (endM == startM) startM + 15 else endM
                            activeRemainingMin = if (actualEnd >= currentMinutes) actualEnd - currentMinutes else (actualEnd + 1440 - currentMinutes)
                            break
                        }
                    }
                }

                // Find next upcoming session
                var nextSession: RoutineSession? = null
                var nextStartsInMin = 0
                for (session in sessions) {
                    val startM = parseTimeToMinutes(session.startTime)
                    if (startM != null) {
                        val wait = if (startM >= currentMinutes) (startM - currentMinutes) else (startM + 1440 - currentMinutes)
                        if (nextSession == null || wait < nextStartsInMin) {
                            nextSession = session
                            nextStartsInMin = wait
                        }
                    }
                }
                if (nextSession == null && sessions.isNotEmpty()) {
                    // Wrap around to first session tomorrow morning
                    nextSession = sessions.first()
                }

                // Bind Active or Upcoming Section
                if (activeSession != null) {
                    views.setTextViewText(R.id.widget_status_badge, "● LIVE")
                    try {
                        views.setInt(
                            R.id.widget_status_badge,
                            "setBackgroundResource",
                            R.drawable.widget_badge_active
                        )
                    } catch (_: Exception) {}
                    views.setTextColor(R.id.widget_status_badge, android.graphics.Color.parseColor("#30D158"))

                    views.setTextViewText(R.id.widget_section_emoji, activeSession.emoji.ifBlank { "⚡" })
                    views.setTextViewText(R.id.widget_section_title, activeSession.title)

                    val details = "${activeSession.getFormattedTime()} • ${activeSession.category}"
                    views.setTextViewText(R.id.widget_section_time, details)

                    val remainingText = if (activeRemainingMin > 0) {
                        "⏳ Still $activeRemainingMin min left"
                    } else {
                        "⏳ Ending now"
                    }
                    views.setTextViewText(R.id.widget_remaining_time, remainingText)
                    views.setTextColor(R.id.widget_remaining_time, android.graphics.Color.parseColor("#0A84FF"))
                } else if (nextSession != null) {
                    views.setTextViewText(R.id.widget_status_badge, "UPCOMING")
                    try {
                        views.setInt(
                            R.id.widget_status_badge,
                            "setBackgroundResource",
                            R.drawable.widget_badge_next
                        )
                    } catch (_: Exception) {}
                    views.setTextColor(R.id.widget_status_badge, android.graphics.Color.parseColor("#FF9F0A"))

                    views.setTextViewText(R.id.widget_section_emoji, nextSession.emoji.ifBlank { "⏰" })
                    views.setTextViewText(R.id.widget_section_title, nextSession.title)

                    val details = "Starts at ${nextSession.getFormattedTime()} • ${nextSession.category}"
                    views.setTextViewText(R.id.widget_section_time, details)

                    val waitText = if (nextStartsInMin > 0) {
                        "⏳ Starts in $nextStartsInMin min"
                    } else {
                        "⏳ Starting soon"
                    }
                    views.setTextViewText(R.id.widget_remaining_time, waitText)
                    views.setTextColor(R.id.widget_remaining_time, android.graphics.Color.parseColor("#FF9F0A"))
                } else {
                    views.setTextViewText(R.id.widget_status_badge, "FREE TIME")
                    views.setTextViewText(R.id.widget_section_emoji, "☕")
                    views.setTextViewText(R.id.widget_section_title, "No Active Timetable Slot")
                    views.setTextViewText(R.id.widget_section_time, "Relax, hydrate or review formulas")
                    views.setTextViewText(R.id.widget_remaining_time, "✨ Rest Period")
                    views.setTextColor(R.id.widget_remaining_time, android.graphics.Color.parseColor("#8E8E93"))
                }

                // Next Section preview
                if (nextSession != null && activeSession != null) {
                    views.setViewVisibility(R.id.widget_next_section, View.VISIBLE)
                    views.setTextViewText(
                        R.id.widget_next_section,
                        "${nextSession.getFormattedTime()} ${nextSession.title}"
                    )
                } else if (sessions.size > 1 && nextSession != null) {
                    views.setViewVisibility(R.id.widget_next_section, View.VISIBLE)
                    views.setTextViewText(
                        R.id.widget_next_section,
                        "${nextSession.getFormattedTime()} ${nextSession.title}"
                    )
                } else {
                    views.setTextViewText(R.id.widget_next_section, "Daily Routine Complete")
                }

                // Timestamp
                val timeSdf = SimpleDateFormat("h:mm a", Locale.getDefault())
                views.setTextViewText(R.id.widget_last_updated, timeSdf.format(Date()))

                // Tap on widget opens MainActivity
                val clickIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingClick = PendingIntent.getActivity(
                    context,
                    0,
                    clickIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pendingClick)

                // Tap on refresh button sends broadcast to refresh widget immediately
                val refreshIntent = Intent(context, JeeRoutineWidgetProvider::class.java).apply {
                    action = ACTION_REFRESH_WIDGET
                }
                val pendingRefresh = PendingIntent.getBroadcast(
                    context,
                    appWidgetId,
                    refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_btn_refresh, pendingRefresh)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                Log.e("JeeRoutineWidget", "Error rendering widget views", e)
            }
        }

        private fun parseTimeToMinutes(timeStr: String): Int? {
            val parts = timeStr.trim().split(":")
            if (parts.size >= 2) {
                val h = parts[0].toIntOrNull() ?: return null
                val m = parts[1].toIntOrNull() ?: return null
                return h * 60 + m
            }
            return null
        }
    }
}
