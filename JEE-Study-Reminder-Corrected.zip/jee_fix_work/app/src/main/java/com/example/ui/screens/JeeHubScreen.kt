package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.IosSegmentedControl
import com.example.ui.viewmodel.JeeViewModel

@Composable
fun JeeHubScreen(
    viewModel: JeeViewModel,
    modifier: Modifier = Modifier
) {
    var selectedHubTab by remember { mutableIntStateOf(0) }
    val hubTabs = listOf("Study Log", "11th Syllabus", "Practice", "Videos")

    val syllabusTopics by viewModel.syllabusTopics.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "JEE Preparation Hub",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Study Hours Log, Syllabus, PYQs & YouTube Video Vault",
                    fontSize = 13.sp,
                    color = Color(0xFF8E8E93)
                )
            }
        }

        IosSegmentedControl(
            items = hubTabs,
            selectedIndex = selectedHubTab,
            onItemSelected = { selectedHubTab = it },
            modifier = Modifier.padding(vertical = 6.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedHubTab) {
                0 -> StudyLogScreen(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )

                1 -> SyllabusScreen(
                    topics = syllabusTopics,
                    onToggleTopicCompleted = { viewModel.toggleTopicCompleted(it) },
                    onTogglePyqSolved = { viewModel.togglePyqSolved(it) },
                    onIncrementRevision = { viewModel.incrementTopicRevision(it) }
                )

                2 -> PracticeScreen(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )

                3 -> VideosScreen(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
