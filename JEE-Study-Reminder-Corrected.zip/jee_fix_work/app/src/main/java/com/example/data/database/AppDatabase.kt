package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.ExamDao
import com.example.data.dao.FormulaDao
import com.example.data.dao.MistakeDao
import com.example.data.dao.MockTestDao
import com.example.data.dao.RoutineSessionDao
import com.example.data.dao.StudyReminderDao
import com.example.data.dao.StudySessionDao
import com.example.data.dao.SyllabusDao
import com.example.data.model.ExamEvent
import com.example.data.model.FormulaCard
import com.example.data.model.MistakeItem
import com.example.data.model.MockTestRecord
import com.example.data.model.RoutineSession
import com.example.data.model.StudyReminder
import com.example.data.model.StudySession
import com.example.data.model.SyllabusTopic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ExamEvent::class,
        RoutineSession::class,
        StudyReminder::class,
        SyllabusTopic::class,
        MockTestRecord::class,
        FormulaCard::class,
        StudySession::class,
        MistakeItem::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun examDao(): ExamDao
    abstract fun routineSessionDao(): RoutineSessionDao
    abstract fun studyReminderDao(): StudyReminderDao
    abstract fun syllabusDao(): SyllabusDao
    abstract fun mockTestDao(): MockTestDao
    abstract fun formulaDao(): FormulaDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun mistakeDao(): MistakeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "jee_reminder_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        if (database.routineSessionDao().countSessions() < 21) {
                            database.routineSessionDao().deleteAll()
                            database.routineSessionDao().insertAll(DefaultJeeData.getDefaultRoutineSessions())
                        }
                        if (database.studyReminderDao().countReminders() < 21) {
                            database.studyReminderDao().deleteAllReminders()
                            database.studyReminderDao().insertAll(DefaultJeeData.getDefaultReminders())
                        }
                        if (database.studySessionDao().countSessions() == 0) {
                            database.studySessionDao().insertAll(DefaultJeeData.getDefaultStudySessions())
                        }
                        if (database.examDao().countExams() == 0 || database.examDao().getJee2028Exam() == null) {
                            val defaultExams = DefaultJeeData.getDefaultExams()
                            database.examDao().insertAll(defaultExams)
                            val target = database.examDao().getJee2028Exam()
                            if (target != null) {
                                database.examDao().setTargetExam(target.id)
                            }
                        }
                    }
                }
            }

            private suspend fun populateInitialData(database: AppDatabase) {
                if (database.routineSessionDao().countSessions() == 0) {
                    database.routineSessionDao().insertAll(DefaultJeeData.getDefaultRoutineSessions())
                }
                if (database.examDao().countExams() == 0) {
                    database.examDao().insertAll(DefaultJeeData.getDefaultExams())
                }
                if (database.studyReminderDao().countReminders() == 0) {
                    database.studyReminderDao().insertAll(DefaultJeeData.getDefaultReminders())
                }
                if (database.syllabusDao().countTopics() == 0) {
                    database.syllabusDao().insertAll(DefaultJeeData.getDefaultSyllabus())
                }
                if (database.formulaDao().countFormulas() == 0) {
                    database.formulaDao().insertAll(DefaultJeeData.getDefaultFormulas())
                }
                if (database.mockTestDao().countMockTests() == 0) {
                    database.mockTestDao().insertAll(DefaultJeeData.getDefaultMockTests())
                }
                if (database.mistakeDao().countMistakes() == 0) {
                    database.mistakeDao().insertAll(DefaultJeeData.getDefaultMistakes())
                }
                if (database.studySessionDao().countSessions() == 0) {
                    database.studySessionDao().insertAll(DefaultJeeData.getDefaultStudySessions())
                }
            }
        }
    }
}
