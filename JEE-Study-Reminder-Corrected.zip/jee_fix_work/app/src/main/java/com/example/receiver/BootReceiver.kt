package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.database.AppDatabase
import com.example.util.JeeNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val pendingResult = goAsync()
            val scope = CoroutineScope(Dispatchers.IO)
            scope.launch {
                try {
                    val db = AppDatabase.getDatabase(context, scope)
                    val sessions = db.routineSessionDao().getAllRoutineSessionsSync()
                    if (sessions.isNotEmpty()) {
                        JeeNotificationHelper.scheduleSectionAlarms(context, sessions)
                    }

                    // Schedule 12:00 AM daily app usage calculation and reset alarm
                    JeeNotificationHelper.scheduleMidnightRollover(context)

                    // Restart strict study service if enabled
                    if (com.example.service.FocusShieldManager.isFocusShieldActive(context)) {
                        com.example.service.FocusShieldManager.startStrictStudyService(context)
                    }

                    // Refresh widgets
                    com.example.service.StudyTimeTracker.triggerWidgetsRefresh(context)
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
