package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import com.example.service.StudyTimeTracker
import com.example.util.JeeNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver triggered at 12:00 AM (midnight) every day by AlarmManager,
 * as well as on system date/time adjustments.
 *
 * Responsibilities:
 * 1. Finalizes and archives the complete 24-hour app usage (12:00 AM to 11:59:59 PM) for yesterday.
 * 2. Initializes and clears daily live screen time counters for the new day starting at 12:00 AM.
 * 3. Schedules the next exact 12:00 AM midnight alarm for tomorrow.
 * 4. Refreshes all Home Screen App Widgets with fresh 12:00 AM metrics.
 * 5. Notifies running activities of the daily rollover.
 */
class MidnightResetReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: ACTION_MIDNIGHT_RESET
        Log.d(TAG, "MidnightResetReceiver triggered with action: $action")

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "JeeReminder:MidnightResetWakeLock"
        )
        try {
            wakeLock?.acquire(6000L)
        } catch (_: Exception) {}

        val pendingResult = goAsync()
        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                // 1. Calculate and archive yesterday's 12am-12am usage
                val archived = StudyTimeTracker.performMidnightCalculationAndArchive(context)
                Log.d(TAG, "Successfully archived usage for ${archived.date} at 12:00 AM")

                // 2. Schedule the next 12:00 AM alarm
                JeeNotificationHelper.scheduleMidnightRollover(context)

                // 3. Refresh all widgets (App Screen Time, Ongoing Section, Timetable)
                StudyTimeTracker.triggerWidgetsRefresh(context)

                // 4. Notify app components (e.g. JeeViewModel)
                val updateIntent = Intent(ACTION_MIDNIGHT_RESET_COMPLETE).apply {
                    setPackage(context.packageName)
                    putExtra("archivedDate", archived.date)
                }
                context.sendBroadcast(updateIntent)
            } catch (e: Exception) {
                Log.e(TAG, "Error handling midnight rollover", e)
            } finally {
                try {
                    if (wakeLock?.isHeld == true) {
                        wakeLock.release()
                    }
                } catch (_: Exception) {}
                pendingResult.finish()
            }
        }
    }

    companion object {
        private const val TAG = "MidnightResetReceiver"
        const val ACTION_MIDNIGHT_RESET = "com.example.receiver.ACTION_MIDNIGHT_RESET"
        const val ACTION_MIDNIGHT_RESET_COMPLETE = "com.example.receiver.ACTION_MIDNIGHT_RESET_COMPLETE"
    }
}
