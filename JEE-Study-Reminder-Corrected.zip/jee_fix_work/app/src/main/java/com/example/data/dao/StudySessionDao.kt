package com.example.data.dao

import androidx.room.*
import com.example.data.model.StudySession
import kotlinx.coroutines.flow.Flow

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    suspend fun getAllSessionsSync(): List<StudySession>

    @Query("SELECT * FROM study_sessions WHERE subject = :subject ORDER BY timestamp DESC")
    fun getSessionsBySubject(subject: String): Flow<List<StudySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySession): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(sessions: List<StudySession>)

    @Delete
    suspend fun deleteSession(session: StudySession)

    @Query("DELETE FROM study_sessions WHERE id = :id")
    suspend fun deleteSessionById(id: Long)

    @Query("SELECT SUM(durationSeconds) FROM study_sessions WHERE timestamp >= :sinceTimestamp")
    fun getTotalFocusSecondsSince(sinceTimestamp: Long): Flow<Long?>

    @Query("SELECT SUM(durationSeconds) FROM study_sessions")
    fun getTotalDurationSeconds(): Flow<Long?>

    @Query("SELECT COUNT(*) FROM study_sessions")
    suspend fun countSessions(): Int
}
