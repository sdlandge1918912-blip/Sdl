package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.service.StudyTimeTracker
import com.example.ui.components.GlassCard
import com.example.ui.viewmodel.JeeViewModel
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class VideoResource(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subject: String, // "Physics", "Chemistry", "Mathematics", "Strategy"
    val duration: String = "45m",
    val instructorOrChannel: String = "YouTube",
    val videoId: String,
    val videoUrl: String,
    val description: String = "",
    val isCompleted: Boolean = false,
    val isBookmarked: Boolean = false,
    val isCustom: Boolean = false,
    val dateAddedMillis: Long = System.currentTimeMillis()
) {
    val thumbnailUrl: String
        get() = if (videoId.isNotBlank()) "https://img.youtube.com/vi/$videoId/hqdefault.jpg" else ""

    val embedUrl: String
        get() = if (videoId.isNotBlank()) "https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&playsinline=1" else videoUrl
}

@Composable
fun VideosScreen(
    viewModel: JeeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Video state
    var videosList by remember { mutableStateOf(loadVideosFromPrefs(context)) }
    var selectedSubject by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    // Paste YouTube URL bar state
    var inputUrl by remember { mutableStateOf("") }
    var detectedVideoId by remember { mutableStateOf<String?>(null) }
    var inputTitle by remember { mutableStateOf("") }
    var inputSubject by remember { mutableStateOf("Physics") }
    var inputNotes by remember { mutableStateOf("") }

    // In-App Embedded Video Player state
    var activePlayingVideo by remember { mutableStateOf<VideoResource?>(null) }
    var watchSecondsElapsed by remember { mutableIntStateOf(0) }

    // Dialog state
    var showAddDialog by remember { mutableStateOf(false) }

    // Synchronize video ID detection on URL change
    LaunchedEffect(inputUrl) {
        val extracted = extractYouTubeVideoId(inputUrl)
        detectedVideoId = extracted
        if (extracted != null && inputTitle.isBlank()) {
            inputTitle = "JEE Lecture (${extracted})"
        }
    }

    // Timer for in-app video watch study tracking
    LaunchedEffect(activePlayingVideo) {
        if (activePlayingVideo != null) {
            watchSecondsElapsed = 0
            while (activePlayingVideo != null) {
                delay(1000L)
                watchSecondsElapsed += 1
                // Log watch time to study tracker every 10 seconds
                if (watchSecondsElapsed % 10 == 0) {
                    StudyTimeTracker.recordAppOpenTick(context, 10)
                }
            }
        }
    }

    // Persist changes helper
    fun persistVideos(updated: List<VideoResource>) {
        videosList = updated
        saveVideosToPrefs(context, updated)
    }

    // Filtered videos
    val filteredVideos = remember(videosList, selectedSubject, searchQuery) {
        videosList.filter { video ->
            val matchSubject = when (selectedSubject) {
                "All" -> true
                "Bookmarks" -> video.isBookmarked
                "My Pasted" -> video.isCustom
                else -> video.subject.equals(selectedSubject, ignoreCase = true)
            }
            val matchSearch = searchQuery.isBlank() ||
                    video.title.contains(searchQuery, ignoreCase = true) ||
                    video.description.contains(searchQuery, ignoreCase = true) ||
                    video.instructorOrChannel.contains(searchQuery, ignoreCase = true)
            matchSubject && matchSearch
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero Card: Vibrant Red-to-Purple-to-Blue Glassy Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xE6E11D48),
                                    Color(0xCC9333EA),
                                    Color(0x992563EB)
                                )
                            )
                        )
                        .border(
                            BorderStroke(1.dp, Color(0x40FFFFFF)),
                            RoundedCornerShape(26.dp)
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        // Subtitle Row: "▶ LECTURE VAULT" pill + "Distraction-Free Video Mode"
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x4D000000))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "YOUTUBE STUDY VAULT",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }

                            Text(
                                text = "Distraction-Free Player",
                                fontSize = 11.sp,
                                color = Color(0xCCFFFFFF),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Paste & Watch YouTube Lectures",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Paste any YouTube lecture link to watch directly inside the app with zero ads or algorithmic distraction. Track your study time while watching!",
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            color = Color(0xE6FFFFFF)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // 4 Mini Glass Stat Cards in 2x2 Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MiniGlassCard(
                                value = "${videosList.size}",
                                label = "Total Lectures",
                                modifier = Modifier.weight(1f)
                            )
                            MiniGlassCard(
                                value = "${videosList.count { it.isCompleted }}",
                                label = "Finished ✔",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MiniGlassCard(
                                value = "${videosList.count { it.isCustom }}",
                                label = "Pasted by You",
                                modifier = Modifier.weight(1f)
                            )
                            MiniGlassCard(
                                value = "${videosList.count { it.isBookmarked }}",
                                label = "Bookmarked ⭐",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 2. ACTIVE IN-APP EMBEDDED VIDEO PLAYER (When a video is playing)
            if (activePlayingVideo != null) {
                item {
                    val currentVideo = activePlayingVideo!!
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("in_app_youtube_player_card"),
                        shape = RoundedCornerShape(24.dp),
                        backgroundColor = Color(0xFA090D16),
                        borderColor = Color(0xFFEF4444)
                    ) {
                        Column {
                            // Header of Player
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFEF4444))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "NOW PLAYING",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFEF4444),
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "⏱️ ${watchSecondsElapsed / 60}m ${watchSecondsElapsed % 60}s logged",
                                        fontSize = 11.sp,
                                        color = Color(0xFF34D399),
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                IconButton(
                                    onClick = { activePlayingVideo = null },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Close Player",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Embedded WebView Player
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(230.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.Black)
                            ) {
                                InAppYouTubeWebView(videoId = currentVideo.videoId)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = currentVideo.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "${currentVideo.subject} • ${currentVideo.instructorOrChannel}",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Player Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val updated = videosList.map {
                                            if (it.id == currentVideo.id) it.copy(isCompleted = !it.isCompleted) else it
                                        }
                                        persistVideos(updated)
                                        activePlayingVideo = activePlayingVideo?.copy(isCompleted = !currentVideo.isCompleted)
                                        Toast.makeText(context, if (!currentVideo.isCompleted) "Marked as Finished! 🎯" else "Marked as Unfinished", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (currentVideo.isCompleted) Color(0xFF059669) else Color(0xFF1E293B)
                                    ),
                                    contentPadding = PaddingValues(vertical = 8.dp)
                                ) {
                                    Icon(
                                        if (currentVideo.isCompleted) Icons.Default.CheckCircle else Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (currentVideo.isCompleted) "Completed ✔" else "Mark Done",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${currentVideo.videoId}"))
                                        context.startActivity(intent)
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF93C5FD)),
                                    border = BorderStroke(1.dp, Color(0x4D60A5FA)),
                                    contentPadding = PaddingValues(vertical = 8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.OpenInNew,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Open in App",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. QUICK PASTE YOUTUBE LINK SECTION ("as I paste youtube video link and see")
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("paste_youtube_link_section"),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xCC0D1527),
                    borderColor = Color(0x4038BDF8),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE11D48)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "PASTE YOUTUBE VIDEO LINK",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF38BDF8),
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = "Paste any lecture URL to watch & bookmark",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            // Clipboard Paste Button
                            Button(
                                onClick = {
                                    val clipText = clipboardManager.getText()?.text
                                    if (!clipText.isNullOrBlank()) {
                                        inputUrl = clipText.trim()
                                        keyboardController?.hide()
                                        Toast.makeText(context, "Pasted from Clipboard!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Paste", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // URL Input Field
                        OutlinedTextField(
                            value = inputUrl,
                            onValueChange = { inputUrl = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("youtube_url_input"),
                            placeholder = {
                                Text(
                                    "Paste youtu.be/... or youtube.com/watch?v=...",
                                    color = Color(0xFF64748B),
                                    fontSize = 12.sp
                                )
                            },
                            trailingIcon = {
                                if (inputUrl.isNotBlank()) {
                                    IconButton(onClick = {
                                        inputUrl = ""
                                        detectedVideoId = null
                                    }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF94A3B8))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF090E1A),
                                unfocusedContainerColor = Color(0xFF090E1A),
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0x3360A5FA),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() })
                        )

                        // Live Detection & Instant Preview Card
                        if (detectedVideoId != null) {
                            val videoId = detectedVideoId!!
                            Spacer(modifier = Modifier.height(12.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFF081224))
                                    .border(BorderStroke(1.dp, Color(0xFF10B981)), RoundedCornerShape(16.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFF34D399),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "YouTube Video Detected",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF34D399)
                                            )
                                        }

                                        Text(
                                            text = "ID: $videoId",
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF94A3B8)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Thumbnail with Play overlay
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(140.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.Black)
                                            .clickable {
                                                // Start in-app playback immediately!
                                                activePlayingVideo = VideoResource(
                                                    title = if (inputTitle.isNotBlank()) inputTitle else "Pasted YouTube Lecture",
                                                    subject = inputSubject,
                                                    videoId = videoId,
                                                    videoUrl = inputUrl,
                                                    instructorOrChannel = "YouTube",
                                                    description = inputNotes,
                                                    isCustom = true
                                                )
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data("https://img.youtube.com/vi/$videoId/hqdefault.jpg")
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = "Video Thumbnail",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )

                                        // Dark scrim
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color(0x33000000))
                                        )

                                        // Big Play Button
                                        Box(
                                            modifier = Modifier
                                                .size(54.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xE6E11D48)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.PlayArrow,
                                                contentDescription = "Watch",
                                                tint = Color.White,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Title Input
                                    OutlinedTextField(
                                        value = inputTitle,
                                        onValueChange = { inputTitle = it },
                                        label = { Text("Lecture Title", fontSize = 11.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = Color(0xFF0F172A),
                                            unfocusedContainerColor = Color(0xFF0F172A),
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Subject selection pills
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf("Physics", "Chemistry", "Mathematics", "Strategy").forEach { subj ->
                                            val isSel = inputSubject == subj
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSel) Color(0xFF2563EB) else Color(0xFF1E293B))
                                                    .border(BorderStroke(1.dp, if (isSel) Color(0xFF60A5FA) else Color(0x33475569)), RoundedCornerShape(8.dp))
                                                    .clickable { inputSubject = subj }
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = subj,
                                                    fontSize = 10.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSel) Color.White else Color(0xFF94A3B8)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Action Buttons: Watch Now & Save to Vault
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                val newResource = VideoResource(
                                                    title = if (inputTitle.isNotBlank()) inputTitle else "Pasted YouTube Lecture",
                                                    subject = inputSubject,
                                                    videoId = videoId,
                                                    videoUrl = inputUrl,
                                                    instructorOrChannel = "YouTube",
                                                    description = inputNotes,
                                                    isCustom = true
                                                )
                                                activePlayingVideo = newResource
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                                            contentPadding = PaddingValues(vertical = 10.dp)
                                        ) {
                                            Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("▶ Watch Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                val newResource = VideoResource(
                                                    title = if (inputTitle.isNotBlank()) inputTitle else "Pasted YouTube Lecture",
                                                    subject = inputSubject,
                                                    videoId = videoId,
                                                    videoUrl = inputUrl,
                                                    instructorOrChannel = "YouTube",
                                                    description = inputNotes,
                                                    isCustom = true
                                                )
                                                val updated = listOf(newResource) + videosList.filter { it.videoId != videoId }
                                                persistVideos(updated)
                                                inputUrl = ""
                                                detectedVideoId = null
                                                inputTitle = ""
                                                Toast.makeText(context, "Added to Lecture Vault!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                            contentPadding = PaddingValues(vertical = 10.dp)
                                        ) {
                                            Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("💾 Save to Vault", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        } else if (inputUrl.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "⚠️ Waiting for a valid YouTube video URL or ID...",
                                fontSize = 11.sp,
                                color = Color(0xFFFCA5A5)
                            )
                        }
                    }
                }
            }

            // 4. Section Header: "JEE Video Lecture Vault" + Search
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = null,
                            tint = Color(0xFF60A5FA),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "JEE Video Lecture Vault",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Text(
                        text = "${filteredVideos.size} videos",
                        fontSize = 11.sp,
                        color = Color(0xFF8E8E93)
                    )
                }
            }

            // 5. Subject Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Physics", "Chemistry", "Mathematics", "My Pasted", "Bookmarks").forEach { sub ->
                        val isSelected = selectedSubject == sub
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (isSelected) Color(0xFF2563EB) else Color(0x66182236))
                                .border(
                                    BorderStroke(
                                        1.dp,
                                        if (isSelected) Color(0xFF60A5FA) else Color(0x334B5563)
                                    ),
                                    RoundedCornerShape(18.dp)
                                )
                                .clickable { selectedSubject = sub }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = sub,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // 6. Video Cards with Real YouTube Thumbnails & In-App Watch Action
            if (filteredVideos.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F172A))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🎬", fontSize = 28.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "No lectures found in this category",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Paste a YouTube link above to add and watch your favorite lectures!",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            } else {
                items(filteredVideos, key = { it.id }) { video ->
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                // Tap to play in-app!
                                activePlayingVideo = video
                            },
                        shape = RoundedCornerShape(20.dp),
                        backgroundColor = Color(0xB310172A),
                        borderColor = if (video.isCompleted) Color(0x3310B981) else Color(0x2660A5FA)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Thumbnail with Play button overlay
                                Box(
                                    modifier = Modifier
                                        .size(width = 110.dp, height = 75.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (video.thumbnailUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data(video.thumbnailUrl)
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = video.title,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }

                                    // Scrim
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color(0x2E000000))
                                    )

                                    // Play icon
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xB3E11D48)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = "Play",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    when (video.subject.lowercase()) {
                                                        "physics" -> Color(0xFF1E3A8A)
                                                        "chemistry" -> Color(0xFF78350F)
                                                        "mathematics" -> Color(0xFF064E3B)
                                                        else -> Color(0xFF312E81)
                                                    }
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = video.subject.uppercase(),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (video.subject.lowercase()) {
                                                    "physics" -> Color(0xFF93C5FD)
                                                    "chemistry" -> Color(0xFFFDE68A)
                                                    "mathematics" -> Color(0xFFA7F3D0)
                                                    else -> Color(0xFFC7D2FE)
                                                }
                                            )
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            // Bookmark Icon
                                            IconButton(
                                                onClick = {
                                                    val updated = videosList.map {
                                                        if (it.id == video.id) it.copy(isBookmarked = !it.isBookmarked) else it
                                                    }
                                                    persistVideos(updated)
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    if (video.isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                                                    contentDescription = "Bookmark",
                                                    tint = if (video.isBookmarked) Color(0xFFF59E0B) else Color(0xFF64748B),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            // If custom video, delete button
                                            if (video.isCustom) {
                                                IconButton(
                                                    onClick = {
                                                        val updated = videosList.filter { it.id != video.id }
                                                        persistVideos(updated)
                                                        if (activePlayingVideo?.id == video.id) {
                                                            activePlayingVideo = null
                                                        }
                                                        Toast.makeText(context, "Video removed", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Delete,
                                                        contentDescription = "Delete",
                                                        tint = Color(0xFFEF4444),
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = video.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = "${video.instructorOrChannel} • ${video.duration}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Bottom Row: Watch Now & External Open Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (video.isCompleted) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF34D399),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Completed",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF34D399)
                                        )
                                    }
                                } else {
                                    Text(
                                        text = if (video.isCustom) "Pasted by You" else "Curated One-Shot",
                                        fontSize = 10.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(video.videoUrl))
                                            context.startActivity(intent)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF93C5FD)),
                                        border = BorderStroke(1.dp, Color(0x3360A5FA)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("YouTube", fontSize = 10.sp)
                                    }

                                    Button(
                                        onClick = {
                                            activePlayingVideo = video
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Watch In-App", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * In-App YouTube Embedded Player running inside WebView
 */
@Composable
fun InAppYouTubeWebView(
    videoId: String,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.allowFileAccess = false
                settings.userAgentString = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        return false
                    }
                }
            }
        },
        update = { webView ->
            val embedHtml = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        html, body { width: 100%; height: 100%; background: #000000; overflow: hidden; }
                        .video-wrapper { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
                        iframe { width: 100%; height: 100%; border: none; }
                    </style>
                </head>
                <body>
                    <div class="video-wrapper">
                        <iframe 
                            src="https://www.youtube-nocookie.com/embed/$videoId?autoplay=1&playsinline=1&modestbranding=1&rel=0&iv_load_policy=3" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                            allowfullscreen>
                        </iframe>
                    </div>
                </body>
                </html>
            """.trimIndent()
            webView.loadDataWithBaseURL("https://www.youtube.com", embedHtml, "text/html", "UTF-8", null)
        }
    )
}

/**
 * Extracts 11-char YouTube video ID from various link formats:
 * - youtu.be/VIDEO_ID
 * - youtube.com/watch?v=VIDEO_ID
 * - youtube.com/shorts/VIDEO_ID
 * - youtube.com/embed/VIDEO_ID
 * - Direct 11-character video ID
 */
fun extractYouTubeVideoId(input: String): String? {
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return null

    // Direct 11-char video ID
    if (trimmed.length == 11 && trimmed.matches(Regex("^[a-zA-Z0-9_-]{11}$"))) {
        return trimmed
    }

    // Standard URL patterns
    val pattern = Regex(
        "(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?.*?v=|embed\\/|v\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})",
        RegexOption.IGNORE_CASE
    )
    val match = pattern.find(trimmed)
    if (match != null) {
        return match.groupValues[1]
    }

    // Fallback: Query parameter 'v'
    try {
        val uri = Uri.parse(trimmed)
        val vParam = uri.getQueryParameter("v")
        if (!vParam.isNullOrBlank() && vParam.length == 11) {
            return vParam
        }
        val segments = uri.pathSegments
        if (segments.isNotEmpty()) {
            val last = segments.last()
            if (last.length == 11 && last.matches(Regex("^[a-zA-Z0-9_-]{11}$"))) {
                return last
            }
        }
    } catch (_: Exception) { }

    return null
}

private const val PREFS_VIDEOS = "jee_saved_videos_vault"
private const val KEY_VIDEOS = "saved_videos_list"

fun saveVideosToPrefs(context: Context, videos: List<VideoResource>) {
    val prefs = context.getSharedPreferences(PREFS_VIDEOS, Context.MODE_PRIVATE)
    val jsonArray = JSONArray()
    for (v in videos) {
        val obj = JSONObject().apply {
            put("id", v.id)
            put("title", v.title)
            put("subject", v.subject)
            put("duration", v.duration)
            put("instructor", v.instructorOrChannel)
            put("videoId", v.videoId)
            put("videoUrl", v.videoUrl)
            put("description", v.description)
            put("isCompleted", v.isCompleted)
            put("isBookmarked", v.isBookmarked)
            put("isCustom", v.isCustom)
            put("dateAddedMillis", v.dateAddedMillis)
        }
        jsonArray.put(obj)
    }
    prefs.edit().putString(KEY_VIDEOS, jsonArray.toString()).apply()
}

fun loadVideosFromPrefs(context: Context): List<VideoResource> {
    val prefs = context.getSharedPreferences(PREFS_VIDEOS, Context.MODE_PRIVATE)
    val jsonString = prefs.getString(KEY_VIDEOS, null) ?: return getDefaultVideoList()
    try {
        val jsonArray = JSONArray(jsonString)
        val list = mutableListOf<VideoResource>()
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            list.add(
                VideoResource(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    title = obj.optString("title", "YouTube Lecture"),
                    subject = obj.optString("subject", "Physics"),
                    duration = obj.optString("duration", "45m"),
                    instructorOrChannel = obj.optString("instructor", "YouTube"),
                    videoId = obj.optString("videoId", ""),
                    videoUrl = obj.optString("videoUrl", ""),
                    description = obj.optString("description", ""),
                    isCompleted = obj.optBoolean("isCompleted", false),
                    isBookmarked = obj.optBoolean("isBookmarked", false),
                    isCustom = obj.optBoolean("isCustom", false),
                    dateAddedMillis = obj.optLong("dateAddedMillis", System.currentTimeMillis())
                )
            )
        }
        return if (list.isEmpty()) getDefaultVideoList() else list
    } catch (_: Exception) {
        return getDefaultVideoList()
    }
}

fun getDefaultVideoList(): List<VideoResource> {
    return listOf(
        VideoResource(
            title = "Rotational Motion in One-Shot (IIT JEE Advanced)",
            subject = "Physics",
            duration = "3h 45m",
            instructorOrChannel = "JEE Physics Marathon",
            videoId = "lW_P0JkUv7o",
            videoUrl = "https://www.youtube.com/watch?v=lW_P0JkUv7o",
            description = "Complete COM, Torque, Angular Momentum conservation & rolling motion.",
            isCompleted = true,
            isBookmarked = true
        ),
        VideoResource(
            title = "Electrostatics & Gauss Law High-Yield Derivations",
            subject = "Physics",
            duration = "2h 30m",
            instructorOrChannel = "Concepts of JEE",
            videoId = "kJQP7kiw5Fk",
            videoUrl = "https://www.youtube.com/watch?v=kJQP7kiw5Fk",
            description = "Dipoles, flux, conductors, and variable charge distributions.",
            isCompleted = false
        ),
        VideoResource(
            title = "Complete GOC & All Named Reactions for JEE",
            subject = "Chemistry",
            duration = "4h 10m",
            instructorOrChannel = "Organic Mastery",
            videoId = "9bZkp7q19f0",
            videoUrl = "https://www.youtube.com/watch?v=9bZkp7q19f0",
            description = "Aldol, Cannizzaro, Reimer-Tiemann, and reaction mechanisms summary.",
            isBookmarked = true
        ),
        VideoResource(
            title = "Coordination Compounds & CFT Complete Breakdown",
            subject = "Chemistry",
            duration = "1h 55m",
            instructorOrChannel = "Inorganic Pulse",
            videoId = "fJ9rUzIMcZQ",
            videoUrl = "https://www.youtube.com/watch?v=fJ9rUzIMcZQ",
            description = "Isomerism, Crystal Field Theory, and magnetic moments calculation.",
            isBookmarked = true
        ),
        VideoResource(
            title = "Definite Integration & King's Rule Masterclass",
            subject = "Mathematics",
            duration = "3h 15m",
            instructorOrChannel = "Calculus Edge",
            videoId = "3JZ_D3ELwOQ",
            videoUrl = "https://www.youtube.com/watch?v=3JZ_D3ELwOQ",
            description = "Standard substitutions, Leibniz integral rule, and estimation integrals.",
            isBookmarked = true
        ),
        VideoResource(
            title = "Vectors & 3D Geometry 100% Score Strategy",
            subject = "Mathematics",
            duration = "2h 40m",
            instructorOrChannel = "Vector Pro",
            videoId = "ZZ5LpwO-An4",
            videoUrl = "https://www.youtube.com/watch?v=ZZ5LpwO-An4",
            description = "Line equations, shortest distance, planes, and scalar/vector triple products.",
            isBookmarked = true
        )
    )
}

@Composable
private fun MiniGlassCard(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33000000))
            .border(BorderStroke(1.dp, Color(0x33FFFFFF)), RoundedCornerShape(16.dp))
            .padding(vertical = 12.dp, horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                color = Color(0xCCFFFFFF),
                fontWeight = FontWeight.Medium
            )
        }
    }
}
