package com.example.data.database

import com.example.data.model.ExamEvent
import com.example.data.model.FormulaCard
import com.example.data.model.MistakeItem
import com.example.data.model.MockTestRecord
import com.example.data.model.RoutineSession
import com.example.data.model.StudyReminder
import com.example.data.model.StudySession
import com.example.data.model.SyllabusTopic
import java.util.Calendar

object DefaultJeeData {

    fun getDefaultRoutineSessions(): List<RoutineSession> {
        return listOf(
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "05:45",
                endTime = "05:50",
                displayTime = "5:45–5:50",
                title = "Wake up + water",
                emoji = "🌅",
                focusTopic = "Metabolism activation & hydration",
                description = "Wake up, drink 500ml room-temperature water to activate metabolism.",
                alertMinutesBefore = 0,
                orderIndex = 1
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "05:50",
                endTime = "06:00",
                displayTime = "5:50–6:00",
                title = "Freshen up",
                emoji = "🚿",
                focusTopic = null,
                description = "Brush teeth, wash face with cold water, and get ready.",
                alertMinutesBefore = 0,
                orderIndex = 2
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "06:00",
                endTime = "06:20",
                displayTime = "6:00–6:20",
                title = "Light walk/stretching",
                emoji = "🚶",
                focusTopic = null,
                description = "Light physical movement, dynamic stretches & oxygenate brain.",
                alertMinutesBefore = 5,
                orderIndex = 3
            ),
            RoutineSession(
                category = "Breaks",
                startTime = "06:20",
                endTime = "06:40",
                displayTime = "6:20–6:40",
                title = "Breakfast",
                emoji = "🥣",
                focusTopic = null,
                description = "Energizing high-protein breakfast and hydration.",
                alertMinutesBefore = 5,
                orderIndex = 4
            ),
            RoutineSession(
                category = "Mathematics",
                startTime = "06:40",
                endTime = "07:40",
                displayTime = "6:40–7:40",
                title = "Mathematics – practice/revision",
                emoji = "📐",
                focusTopic = "Problem solving & formula revision",
                description = "Morning high-focus maths slot: solve core problems & key formula revisions.",
                alertMinutesBefore = 10,
                orderIndex = 5
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "07:40",
                endTime = "08:00",
                displayTime = "7:40–8:00",
                title = "Get ready/travel",
                emoji = "🎒",
                focusTopic = null,
                description = "Organize notebooks, formula sheets, and travel to coaching/classes.",
                alertMinutesBefore = 5,
                orderIndex = 6
            ),
            RoutineSession(
                category = "Coaching/classes",
                startTime = "08:00",
                endTime = "13:00",
                displayTime = "8:00–1:00",
                title = "JEE Classes",
                emoji = "🏫",
                focusTopic = "Lectures, concept clarity & class problem sheets",
                description = "5-hour coaching block: active classroom listening, derivations & noting down doubt questions.",
                alertMinutesBefore = 10,
                orderIndex = 7
            ),
            RoutineSession(
                category = "Breaks",
                startTime = "13:00",
                endTime = "13:30",
                displayTime = "1:00–1:30",
                title = "Lunch + relax",
                emoji = "🍛",
                focusTopic = null,
                description = "Nutritious lunch and screen-free mental relaxation.",
                alertMinutesBefore = 5,
                orderIndex = 8
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "13:30",
                endTime = "14:00",
                displayTime = "1:30–2:00",
                title = "Rest/short nap",
                emoji = "😴",
                focusTopic = null,
                description = "30-minute power nap to reset focus and recharge mental stamina.",
                alertMinutesBefore = 5,
                orderIndex = 9
            ),
            RoutineSession(
                category = "Physics",
                startTime = "14:00",
                endTime = "15:30",
                displayTime = "2:00–3:30",
                title = "Physics – concepts + questions",
                emoji = "⚡",
                focusTopic = "Theory concepts, derivations & numerical problems",
                description = "Deep conceptual physics study, NCERT understanding & solving practice problems.",
                alertMinutesBefore = 10,
                orderIndex = 10
            ),
            RoutineSession(
                category = "Breaks",
                startTime = "15:30",
                endTime = "15:45",
                displayTime = "3:30–3:45",
                title = "Break + water/snack",
                emoji = "💧",
                focusTopic = null,
                description = "Drink water, stretch eyes, and light snack.",
                alertMinutesBefore = 5,
                orderIndex = 11
            ),
            RoutineSession(
                category = "Chemistry",
                startTime = "15:45",
                endTime = "17:15",
                displayTime = "3:45–5:15",
                title = "Chemistry – theory + questions",
                emoji = "🧪",
                focusTopic = "NCERT theory, mechanisms, reactions & chapter questions",
                description = "Chemistry focus session: Physical / Organic / Inorganic theory and high-yield questions.",
                alertMinutesBefore = 10,
                orderIndex = 12
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "17:15",
                endTime = "17:45",
                displayTime = "5:15–5:45",
                title = "Walk + refresh",
                emoji = "🚶",
                focusTopic = null,
                description = "Outdoor walk, fresh air, and mental reset to avoid burnout.",
                alertMinutesBefore = 5,
                orderIndex = 13
            ),
            RoutineSession(
                category = "Mathematics",
                startTime = "17:45",
                endTime = "19:15",
                displayTime = "5:45–7:15",
                title = "Mathematics – problem solving",
                emoji = "📐",
                focusTopic = "Intensive JEE problem solving & speed training",
                description = "Timed problem practice, challenging multi-step questions & shortcut techniques.",
                alertMinutesBefore = 10,
                orderIndex = 14
            ),
            RoutineSession(
                category = "Breaks",
                startTime = "19:15",
                endTime = "19:45",
                displayTime = "7:15–7:45",
                title = "Snack + break",
                emoji = "🍎",
                focusTopic = null,
                description = "Healthy evening snack & brain recharge.",
                alertMinutesBefore = 5,
                orderIndex = 15
            ),
            RoutineSession(
                category = "Revision",
                startTime = "19:45",
                endTime = "20:30",
                displayTime = "7:45–8:30",
                title = "Daily revision – class notes/formulas",
                emoji = "🔄",
                focusTopic = "Today's class notes, formula flashcards & key points",
                description = "Review all concepts covered in today's classes and consolidate short notes.",
                alertMinutesBefore = 10,
                orderIndex = 16
            ),
            RoutineSession(
                category = "Dinner",
                startTime = "20:30",
                endTime = "21:15",
                displayTime = "8:30–9:15",
                title = "Dinner + travel",
                emoji = "🍽️",
                focusTopic = null,
                description = "Wholesome dinner and travel wind-down.",
                alertMinutesBefore = 5,
                orderIndex = 17
            ),
            RoutineSession(
                category = "Revision",
                startTime = "21:15",
                endTime = "21:45",
                displayTime = "9:15–9:45",
                title = "Quick revision/test",
                emoji = "📝",
                focusTopic = "Timed mini-test & Mistake Notebook review",
                description = "30-minute timed quiz to test retention & log errors in the Mistake Notebook.",
                alertMinutesBefore = 10,
                orderIndex = 18
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "21:45",
                endTime = "22:15",
                displayTime = "9:45–10:15",
                title = "Prepare for tomorrow + relax",
                emoji = "🎒",
                focusTopic = null,
                description = "Pack books for next day, review upcoming class topics & relax.",
                alertMinutesBefore = 5,
                orderIndex = 19
            ),
            RoutineSession(
                category = "Walking/relaxation",
                startTime = "22:15",
                endTime = "22:30",
                displayTime = "10:15–10:30",
                title = "No-screen wind-down",
                emoji = "📵",
                focusTopic = null,
                description = "Turn off all screens & phones to allow melatonin production.",
                alertMinutesBefore = 5,
                orderIndex = 20
            ),
            RoutineSession(
                category = "Sleep",
                startTime = "22:30",
                endTime = "05:45",
                displayTime = "10:30 PM",
                title = "Sleep",
                emoji = "😴",
                focusTopic = null,
                description = "7 hours 15 minutes of restful sleep for brain repair and memory consolidation.",
                alertMinutesBefore = 15,
                orderIndex = 21
            )
        )
    }

    fun getDefaultMistakes(): List<MistakeItem> {
        return listOf(
            MistakeItem(
                subject = "Physics",
                chapter = "Rotational Motion",
                questionSummary = "Moment of Inertia about tangent perpendicular to plane of disk",
                mistakeType = "Formula Forgotten",
                correctiveAction = "Used Parallel Axis theorem wrong: I = I_cm + md^2 = (1/2)mR^2 + mR^2 = 5/4 mR^2, remember axis direction!",
                isResolved = false
            ),
            MistakeItem(
                subject = "Mathematics",
                chapter = "Definite Integration",
                questionSummary = "Forgot negative sign while applying King's property on (pi - x)",
                mistakeType = "Calculation Error",
                correctiveAction = "Always check lower & upper limit swap signs when substituting (a+b-x).",
                isResolved = false
            ),
            MistakeItem(
                subject = "Chemistry",
                chapter = "Chemical Equilibrium",
                questionSummary = "Kp calculation with inert gas added at constant pressure vs constant volume",
                mistakeType = "Conceptual Flaw",
                correctiveAction = "At constant pressure, total volume increases, shifts towards more moles. At constant volume, no shift.",
                isResolved = false
            ),
            MistakeItem(
                subject = "Mathematics",
                chapter = "Matrices & Determinants",
                questionSummary = "adj(adj(A)) formula determinant power condition",
                mistakeType = "Formula Forgotten",
                correctiveAction = "|adj(adj(A))| = |A|^{(n-1)^2}. For 3x3 matrix, power is (3-1)^2 = 4.",
                isResolved = false
            )
        )
    }

    fun getDefaultExams(): List<ExamEvent> {
        val s1Cal = Calendar.getInstance().apply {
            set(2028, Calendar.JANUARY, 24, 9, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val s2Cal = Calendar.getInstance().apply {
            set(2028, Calendar.APRIL, 6, 9, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val advCal = Calendar.getInstance().apply {
            set(2028, Calendar.MAY, 21, 9, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }

        return listOf(
            ExamEvent(
                title = "JEE Main 2028 (Session 1)",
                examDateMillis = s1Cal.timeInMillis,
                category = "EXAM",
                notes = "Primary target: January 2028 - Target 99.8+ Percentile",
                isTargetExam = true
            ),
            ExamEvent(
                title = "JEE Main 2028 (Session 2)",
                examDateMillis = s2Cal.timeInMillis,
                category = "EXAM",
                notes = "April 2028 session score & rank booster",
                isTargetExam = false
            ),
            ExamEvent(
                title = "JEE Advanced 2028",
                examDateMillis = advCal.timeInMillis,
                category = "EXAM",
                notes = "IIT Admissions - Paper 1 & Paper 2 (May 2028)",
                isTargetExam = false
            )
        )
    }

    private fun getTodayTimestamp(hour: Int, minute: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getDefaultReminders(): List<StudyReminder> {
        return listOf(
            StudyReminder(
                title = "🌅 Wake up + water (5:45 AM)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(5, 45),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "Drink 500ml water to kickstart metabolism"
            ),
            StudyReminder(
                title = "🚿 Freshen up (5:45–6:00)",
                subject = "GENERAL",
                dueTimeMillis = getTodayTimestamp(5, 45),
                priority = "LOW",
                recurrence = "DAILY",
                notes = "Freshen up for the study day ahead"
            ),
            StudyReminder(
                title = "🚶 Light walk/stretching (6:00–6:20)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(6, 0),
                priority = "LOW",
                recurrence = "DAILY",
                notes = "Morning walk & dynamic stretches to oxygenate the brain"
            ),
            StudyReminder(
                title = "🥣 Breakfast (6:20–6:40)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(6, 20),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "High-protein breakfast to fuel focus"
            ),
            StudyReminder(
                title = "📐 Mathematics – practice/revision (6:40–7:40)",
                subject = "MATHEMATICS",
                dueTimeMillis = getTodayTimestamp(6, 40),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "Morning high-focus problem solving & formula revision"
            ),
            StudyReminder(
                title = "🎒 Get ready/travel (7:40–8:00)",
                subject = "GENERAL",
                dueTimeMillis = getTodayTimestamp(7, 40),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "Pack formula books & travel to classes"
            ),
            StudyReminder(
                title = "🏫 JEE Classes (8:00–1:00)",
                subject = "COACHING",
                dueTimeMillis = getTodayTimestamp(8, 0),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "5-hour core coaching block & classroom lectures"
            ),
            StudyReminder(
                title = "🍛 Lunch + relax (1:00–1:30)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(13, 0),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "Wholesome lunch and screen-free reset"
            ),
            StudyReminder(
                title = "😴 Rest/short nap (1:30–2:00)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(13, 30),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "30-min power nap to recharge mental stamina"
            ),
            StudyReminder(
                title = "⚡ Physics – concepts + questions (2:00–3:30)",
                subject = "PHYSICS",
                dueTimeMillis = getTodayTimestamp(14, 0),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "Theory concepts, derivations & numericals"
            ),
            StudyReminder(
                title = "💧 Break + water/snack (3:30–3:45)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(15, 30),
                priority = "LOW",
                recurrence = "DAILY",
                notes = "Eye relaxation & hydration break"
            ),
            StudyReminder(
                title = "🧪 Chemistry – theory + questions (3:45–5:15)",
                subject = "CHEMISTRY",
                dueTimeMillis = getTodayTimestamp(15, 45),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "NCERT theory, mechanisms & reactions"
            ),
            StudyReminder(
                title = "🚶 Walk + refresh (5:15–5:45)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(17, 15),
                priority = "LOW",
                recurrence = "DAILY",
                notes = "Outdoor evening walk to avoid burnout"
            ),
            StudyReminder(
                title = "📐 Mathematics – problem solving (5:45–7:15)",
                subject = "MATHEMATICS",
                dueTimeMillis = getTodayTimestamp(17, 45),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "Speed training & multi-step problems"
            ),
            StudyReminder(
                title = "🍎 Snack + break (7:15–7:45)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(19, 15),
                priority = "LOW",
                recurrence = "DAILY",
                notes = "Healthy brain recharge snack"
            ),
            StudyReminder(
                title = "🔄 Daily revision – class notes/formulas (7:45–8:25)",
                subject = "REVISION",
                dueTimeMillis = getTodayTimestamp(19, 45),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "Today's class notes, formula flashcards & key points"
            ),
            StudyReminder(
                title = "🍽️ Dinner + travel (8:30–9:15)",
                subject = "HEALTH",
                dueTimeMillis = getTodayTimestamp(20, 30),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "Dinner and travel wind-down"
            ),
            StudyReminder(
                title = "📝 Quick revision/test (9:15–9:45)",
                subject = "REVISION",
                dueTimeMillis = getTodayTimestamp(21, 15),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "30-min timed quiz & Mistake Notebook review"
            ),
            StudyReminder(
                title = "🎒 Prepare for tomorrow + relax (9:45–10:15)",
                subject = "GENERAL",
                dueTimeMillis = getTodayTimestamp(21, 45),
                priority = "LOW",
                recurrence = "DAILY",
                notes = "Review upcoming topics & organize desk"
            ),
            StudyReminder(
                title = "📵 No-screen wind-down (10:15–10:30)",
                subject = "GENERAL",
                dueTimeMillis = getTodayTimestamp(22, 15),
                priority = "MEDIUM",
                recurrence = "DAILY",
                notes = "Screen blackout for melatonin production"
            ),
            StudyReminder(
                title = "😴 Sleep (10:30 PM)",
                subject = "GENERAL",
                dueTimeMillis = getTodayTimestamp(22, 30),
                priority = "HIGH",
                recurrence = "DAILY",
                notes = "7h 15m deep sleep for memory consolidation"
            )
        )
    }

    fun getDefaultSyllabus(): List<SyllabusTopic> {
        return listOf(
            // 11th Physics
            SyllabusTopic(subject = "PHYSICS", standardClass = "11TH", chapterName = "Kinematics & Motion in 1D/2D", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 5.5f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "11TH", chapterName = "Laws of Motion & Friction", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 6.0f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "11TH", chapterName = "Work, Energy & Power", isCompleted = true, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 4.5f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "11TH", chapterName = "Rotational Dynamics & COM", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 7.0f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "11TH", chapterName = "Gravitation", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 3.5f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "11TH", chapterName = "Thermodynamics & KTG", isCompleted = false, pyqsSolved = false, revisionCount = 0, totalWeightagePercent = 6.5f),

            // 12th Physics
            SyllabusTopic(subject = "PHYSICS", standardClass = "12TH", chapterName = "Electrostatics & Gauss Law", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 6.5f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "12TH", chapterName = "Current Electricity", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 6.0f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "12TH", chapterName = "Magnetic Effects of Current & EMI", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 7.0f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "12TH", chapterName = "Ray & Wave Optics", isCompleted = false, pyqsSolved = false, revisionCount = 0, totalWeightagePercent = 6.0f),
            SyllabusTopic(subject = "PHYSICS", standardClass = "12TH", chapterName = "Modern Physics & Dual Nature", isCompleted = true, pyqsSolved = true, revisionCount = 3, totalWeightagePercent = 8.5f),

            // 11th Chemistry
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "11TH", chapterName = "Some Basic Concepts of Chemistry (Mole)", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 4.0f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "11TH", chapterName = "Structure of Atom", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 4.5f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "11TH", chapterName = "Chemical Bonding & Molecular Structure", isCompleted = true, pyqsSolved = true, revisionCount = 3, totalWeightagePercent = 7.0f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "11TH", chapterName = "Thermodynamics & Equilibrium", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 6.5f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "11TH", chapterName = "General Organic Chemistry (GOC)", isCompleted = true, pyqsSolved = true, revisionCount = 3, totalWeightagePercent = 8.0f),

            // 12th Chemistry
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "12TH", chapterName = "Solutions & Colligative Properties", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 5.0f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "12TH", chapterName = "Electrochemistry & Chemical Kinetics", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 6.5f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "12TH", chapterName = "Coordination Compounds", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 6.0f),
            SyllabusTopic(subject = "CHEMISTRY", standardClass = "12TH", chapterName = "Aldehydes, Ketones & Carboxylic Acids", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 7.5f),

            // 11th Maths
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "11TH", chapterName = "Sets, Relations & Functions", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 5.0f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "11TH", chapterName = "Trigonometric Ratios & Equations", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 4.5f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "11TH", chapterName = "Quadratic Equations & Complex Numbers", isCompleted = true, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 5.5f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "11TH", chapterName = "Permutations & Combinations + Binomial", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 6.0f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "11TH", chapterName = "Conic Sections (Parabola, Ellipse, Hyperbola)", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 7.0f),

            // 12th Maths
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "12TH", chapterName = "Matrices & Determinants", isCompleted = true, pyqsSolved = true, revisionCount = 3, totalWeightagePercent = 6.5f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "12TH", chapterName = "Continuity, Differentiability & MOD", isCompleted = true, pyqsSolved = true, revisionCount = 2, totalWeightagePercent = 6.0f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "12TH", chapterName = "Application of Derivatives (AOD)", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 6.5f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "12TH", chapterName = "Indefinite & Definite Integrals", isCompleted = false, pyqsSolved = false, revisionCount = 1, totalWeightagePercent = 8.0f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "12TH", chapterName = "Vectors & 3D Geometry", isCompleted = true, pyqsSolved = true, revisionCount = 3, totalWeightagePercent = 8.5f),
            SyllabusTopic(subject = "MATHEMATICS", standardClass = "12TH", chapterName = "Probability & Statistics", isCompleted = false, pyqsSolved = false, revisionCount = 0, totalWeightagePercent = 6.0f)
        )
    }

    fun getDefaultFormulas(): List<FormulaCard> {
        return listOf(
            FormulaCard(
                subject = "PHYSICS",
                chapter = "Rotational Motion",
                title = "Parallel & Perpendicular Axes Theorems",
                formulaLatex = "I = I_cm + M*d^2  |  I_z = I_x + I_y (planar)",
                keyVariables = "I_cm = Inertia about COM, d = distance to axis",
                tips = "Perpendicular axis theorem ONLY applies to 2D laminar bodies!"
            ),
            FormulaCard(
                subject = "PHYSICS",
                chapter = "Current Electricity",
                title = "Temperature Dependence of Resistance",
                formulaLatex = "R_T = R_0(1 + α*ΔT)",
                keyVariables = "α = temperature coefficient of resistance",
                tips = "For semiconductors, α is negative; resistance decreases with heat."
            ),
            FormulaCard(
                subject = "CHEMISTRY",
                chapter = "Electrochemistry",
                title = "Nernst Equation",
                formulaLatex = "E_cell = E°_cell - (0.0591/n) * log(Q)",
                keyVariables = "n = moles of e⁻, Q = reaction quotient at 298K",
                tips = "Only include aqueous/gaseous species in Q, solids are 1."
            ),
            FormulaCard(
                subject = "CHEMISTRY",
                chapter = "Chemical Kinetics",
                title = "First-Order Rate Law & Half-Life",
                formulaLatex = "k = (2.303/t)*log(A_0/A_t)  |  t_{1/2} = 0.693/k",
                keyVariables = "k = rate constant, t_{1/2} is independent of [A_0]",
                tips = "Radioactive decay always follows first-order kinetics."
            ),
            FormulaCard(
                subject = "MATHEMATICS",
                chapter = "Calculus",
                title = "King's Rule in Definite Integration",
                formulaLatex = "∫_a^b f(x)dx = ∫_a^b f(a + b - x)dx",
                keyVariables = "a, b = integration bounds",
                tips = "Add original I and transformed I to cancel complicated denominators."
            ),
            FormulaCard(
                subject = "MATHEMATICS",
                chapter = "Vectors & 3D Geometry",
                title = "Shortest Distance Between Skew Lines",
                formulaLatex = "d = |(b_1 × b_2) · (a_2 - a_1)| / |b_1 × b_2|",
                keyVariables = "a_1, a_2 = points on lines, b_1, b_2 = direction vectors",
                tips = "If numerator is 0, the lines intersect (coplanar)."
            )
        )
    }

    fun getDefaultMockTests(): List<MockTestRecord> {
        val now = System.currentTimeMillis()
        val oneDay = 86400 * 1000L
        return listOf(
            MockTestRecord(
                testName = "All India CBT Full Mock #1",
                testDateMillis = now - 6 * oneDay,
                physicsScore = 68,
                chemistryScore = 76,
                mathsScore = 54,
                totalScore = 198,
                estimatedPercentile = 98.4,
                negativeMarks = -12,
                weakAreas = "Good Chemistry attempt, need to improve speed in Maths Section B."
            ),
            MockTestRecord(
                testName = "Chapterwise Part Mock - Mechanics & Calculus",
                testDateMillis = now - 2 * oneDay,
                physicsScore = 74,
                chemistryScore = 70,
                mathsScore = 65,
                totalScore = 209,
                estimatedPercentile = 99.1,
                negativeMarks = -8,
                weakAreas = "Higher accuracy maintained. Rotational motion doubts noted in Mistake Notebook."
            )
        )
    }

    fun getDefaultStudySessions(): List<StudySession> {
        val now = System.currentTimeMillis()
        val hourMillis = 3600 * 1000L
        val dayMillis = 24 * hourMillis
        return listOf(
            StudySession(
                subject = "PHYSICS",
                topic = "Rotational Dynamics & Torque PYQs",
                durationSeconds = 9000L, // 2.5 hours
                timestamp = now - (2 * hourMillis),
                mode = "PROBLEM_SOLVING"
            ),
            StudySession(
                subject = "MATHEMATICS",
                topic = "Definite Integrals & Properties",
                durationSeconds = 10800L, // 3.0 hours
                timestamp = now - (6 * hourMillis),
                mode = "THEORY_PRACTICE"
            ),
            StudySession(
                subject = "CHEMISTRY",
                topic = "Chemical Equilibrium & Le Chatelier",
                durationSeconds = 7200L, // 2.0 hours
                timestamp = now - dayMillis - (3 * hourMillis),
                mode = "REVISION"
            ),
            StudySession(
                subject = "PHYSICS",
                topic = "Electrostatics & Capacitance",
                durationSeconds = 7200L, // 2.0 hours
                timestamp = now - (2 * dayMillis) - (4 * hourMillis),
                mode = "PROBLEM_SOLVING"
            ),
            StudySession(
                subject = "MATHEMATICS",
                topic = "Conic Sections (Parabola & Ellipse)",
                durationSeconds = 9000L, // 2.5 hours
                timestamp = now - (3 * dayMillis) - (2 * hourMillis),
                mode = "MOCK_TEST"
            ),
            StudySession(
                subject = "CHEMISTRY",
                topic = "Thermodynamics & Hess's Law",
                durationSeconds = 5400L, // 1.5 hours
                timestamp = now - (4 * dayMillis) - (5 * hourMillis),
                mode = "THEORY_PRACTICE"
            )
        )
    }
}
