package com.example.ui.viewmodel

import android.app.Application
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.DefaultJeeData
import com.example.data.model.*
import com.example.data.repository.JeeRepository
import com.example.service.FocusShieldManager
import com.example.service.StudyTimeTracker
import com.example.service.DailyStudySummary
import com.example.service.SectionStudyRecord
import com.example.service.AppUsageRecord
import com.example.util.JeeNotificationHelper
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

class JeeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: JeeRepository
    val parentTelemetryRepo = com.example.data.repository.ParentTelemetryRepository(application)
    private val prefs: SharedPreferences = application.getSharedPreferences("jee_student_prefs", Context.MODE_PRIVATE)

    // Parent Telemetry & Oversight Flows
    val parentUids: StateFlow<List<String>> = parentTelemetryRepo.parentUids
    val parentPairingStatus: StateFlow<String> = parentTelemetryRepo.pairingStatus

    // Room Database Flows
    val routineSessions: StateFlow<List<RoutineSession>>
    val exams: StateFlow<List<ExamEvent>>
    val targetExam: StateFlow<ExamEvent?>
    val reminders: StateFlow<List<StudyReminder>>
    val syllabusTopics: StateFlow<List<SyllabusTopic>>
    val mockTests: StateFlow<List<MockTestRecord>>
    val formulas: StateFlow<List<FormulaCard>>
    val mistakes: StateFlow<List<MistakeItem>>
    val unresolvedMistakeCount: StateFlow<Int>
    val studySessions: StateFlow<List<StudySession>>

    // Routine Filtering state
    private val _selectedCategory = MutableStateFlow("All Categories")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedDay = MutableStateFlow("All")
    val selectedDay: StateFlow<String> = _selectedDay.asStateFlow()

    // Daily Reset & Session Completion
    private val _completedSessionIds = MutableStateFlow<Set<Long>>(emptySet())
    val completedSessionIds: StateFlow<Set<Long>> = _completedSessionIds.asStateFlow()

    private val _dailyResetMessage = MutableStateFlow<String?>(null)
    val dailyResetMessage: StateFlow<String?> = _dailyResetMessage.asStateFlow()

    // Section Start Notifications
    private val _isSectionNotificationEnabled = MutableStateFlow(true)
    val isSectionNotificationEnabled: StateFlow<Boolean> = _isSectionNotificationEnabled.asStateFlow()

    private val _activeRoutineSession = MutableStateFlow<RoutineSession?>(null)
    val activeRoutineSession: StateFlow<RoutineSession?> = _activeRoutineSession.asStateFlow()

    // iOS Clock - Alarms State
    private val _alarms = MutableStateFlow<List<AlarmItem>>(emptyList())
    val alarms: StateFlow<List<AlarmItem>> = _alarms.asStateFlow()

    // iOS Clock - Stopwatch State
    private val _stopwatchMillis = MutableStateFlow(0L)
    val stopwatchMillis: StateFlow<Long> = _stopwatchMillis.asStateFlow()

    private val _isStopwatchRunning = MutableStateFlow(false)
    val isStopwatchRunning: StateFlow<Boolean> = _isStopwatchRunning.asStateFlow()

    private val _stopwatchLaps = MutableStateFlow<List<Long>>(emptyList())
    val stopwatchLaps: StateFlow<List<Long>> = _stopwatchLaps.asStateFlow()

    private var stopwatchJob: Job? = null

    // iOS Clock - Countdown Timer State
    private val _timerTotalSeconds = MutableStateFlow(45 * 60L) // Default 45m JEE Sprint
    val timerTotalSeconds: StateFlow<Long> = _timerTotalSeconds.asStateFlow()

    private val _timerRemainingSeconds = MutableStateFlow(45 * 60L)
    val timerRemainingSeconds: StateFlow<Long> = _timerRemainingSeconds.asStateFlow()

    // Practice Screen Timer Compatibility State
    private val _timerMode = MutableStateFlow("Stopwatch")
    val timerMode: StateFlow<String> = _timerMode.asStateFlow()

    private val _selectedTimerSubject = MutableStateFlow("Physics")
    val selectedTimerSubject: StateFlow<String> = _selectedTimerSubject.asStateFlow()

    private val _timerTopic = MutableStateFlow("")
    val timerTopic: StateFlow<String> = _timerTopic.asStateFlow()

    private val _timerSeconds = MutableStateFlow(0L)
    val timerSeconds: StateFlow<Long> = _timerSeconds.asStateFlow()

    private var practiceTimerJob: Job? = null

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _timerPresetName = MutableStateFlow("JEE Problem Sprint (45m)")
    val timerPresetName: StateFlow<String> = _timerPresetName.asStateFlow()

    private var countdownJob: Job? = null

    // Focus & Distraction App Blocker
    private val _isFocusShieldActive = MutableStateFlow(FocusShieldManager.isFocusShieldActive(application))
    val isFocusShieldActive: StateFlow<Boolean> = _isFocusShieldActive.asStateFlow()

    private val _isAutoTimetableSync = MutableStateFlow(FocusShieldManager.isAutoTimetableSync(application))
    val isAutoTimetableSync: StateFlow<Boolean> = _isAutoTimetableSync.asStateFlow()

    private val _isManualSessionActive = MutableStateFlow(FocusShieldManager.isManualSessionActive(application))
    val isManualSessionActive: StateFlow<Boolean> = _isManualSessionActive.asStateFlow()

    private val _manualSessionRemainingSeconds = MutableStateFlow(FocusShieldManager.getManualSessionRemainingSeconds(application))
    val manualSessionRemainingSeconds: StateFlow<Long> = _manualSessionRemainingSeconds.asStateFlow()

    private val _manualSessionLabel = MutableStateFlow(FocusShieldManager.getManualSessionLabel(application))
    val manualSessionLabel: StateFlow<String> = _manualSessionLabel.asStateFlow()

    private val _hasUsagePermission = MutableStateFlow(FocusShieldManager.hasUsageStatsPermission(application))
    val hasUsagePermission: StateFlow<Boolean> = _hasUsagePermission.asStateFlow()

    private val _hasOverlayPermission = MutableStateFlow(FocusShieldManager.hasOverlayPermission(application))
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _hasBatteryExemption = MutableStateFlow(FocusShieldManager.isBatteryOptimizationIgnored(application))
    val hasBatteryExemption: StateFlow<Boolean> = _hasBatteryExemption.asStateFlow()

    private val _installedUserApps = MutableStateFlow<List<BlockedApp>>(emptyList())
    val installedUserApps: StateFlow<List<BlockedApp>> = _installedUserApps.asStateFlow()

    private val _blockedApps = MutableStateFlow<List<BlockedApp>>(FocusShieldManager.getBlockedApps(application))
    val blockedApps: StateFlow<List<BlockedApp>> = _blockedApps.asStateFlow()

    private val _showDistractionShieldOverlay = MutableStateFlow(false)
    val showDistractionShieldOverlay: StateFlow<Boolean> = _showDistractionShieldOverlay.asStateFlow()

    private val _blockedAppToPreview = MutableStateFlow<BlockedApp?>(null)
    val blockedAppToPreview: StateFlow<BlockedApp?> = _blockedAppToPreview.asStateFlow()

    private val _isStrictEnforcedNow = MutableStateFlow(FocusShieldManager.isStrictStudyCurrentlyEnforced(application))
    val isStrictEnforcedNow: StateFlow<Boolean> = _isStrictEnforcedNow.asStateFlow()

    private val _isOngoingStudySlot = MutableStateFlow(FocusShieldManager.isCurrentlyInStudySection(application))
    val isOngoingStudySlot: StateFlow<Boolean> = _isOngoingStudySlot.asStateFlow()

    private val _isOngoingBreakSlot = MutableStateFlow(FocusShieldManager.isCurrentlyInBreak(application))
    val isOngoingBreakSlot: StateFlow<Boolean> = _isOngoingBreakSlot.asStateFlow()

    // Background Customization & Blur Effect State
    // bgType: "PRESET", "CUSTOM_IMAGE", "DEFAULT"
    private val _backgroundType = MutableStateFlow(prefs.getString("bg_type", "DEFAULT") ?: "DEFAULT")
    val backgroundType: StateFlow<String> = _backgroundType.asStateFlow()

    // presetKey: "COSMIC", "CYBER_NEON", "DEEP_FOREST", "CHILL_AURA", "SUNSET", "MINIMAL_DARK"
    private val _backgroundPreset = MutableStateFlow(prefs.getString("bg_preset", "COSMIC") ?: "COSMIC")
    val backgroundPreset: StateFlow<String> = _backgroundPreset.asStateFlow()

    private val _customBgUri = MutableStateFlow(prefs.getString("bg_custom_uri", null))
    val customBgUri: StateFlow<String?> = _customBgUri.asStateFlow()

    // Blur amount in dp (0 to 30)
    private val _blurIntensity = MutableStateFlow(prefs.getFloat("bg_blur_intensity", 14f))
    val blurIntensity: StateFlow<Float> = _blurIntensity.asStateFlow()

    // Dark overlay opacity for readability (0.1f to 0.9f)
    private val _bgDimOpacity = MutableStateFlow(prefs.getFloat("bg_dim_opacity", 0.65f))
    val bgDimOpacity: StateFlow<Float> = _bgDimOpacity.asStateFlow()

    // Study Time & Distraction Tracking System (12:00 AM Daily Cycle)
    private val _todayStudySummary = MutableStateFlow(StudyTimeTracker.getTodayStudySummary(application))
    val todayStudySummary: StateFlow<DailyStudySummary> = _todayStudySummary.asStateFlow()

    private val _selectedScreenTimeDate = MutableStateFlow(StudyTimeTracker.getTodayDateString())
    val selectedScreenTimeDate: StateFlow<String> = _selectedScreenTimeDate.asStateFlow()

    private val _displayedStudySummary = MutableStateFlow(StudyTimeTracker.getTodayStudySummary(application))
    val displayedStudySummary: StateFlow<DailyStudySummary> = _displayedStudySummary.asStateFlow()

    private val _availableArchiveDates = MutableStateFlow(StudyTimeTracker.getArchivedDates(application))
    val availableArchiveDates: StateFlow<List<String>> = _availableArchiveDates.asStateFlow()

    fun selectScreenTimeDate(dateString: String) {
        _selectedScreenTimeDate.value = dateString
        viewModelScope.launch(Dispatchers.IO) {
            val summary = StudyTimeTracker.getDailyStudySummaryForDate(getApplication(), dateString)
            _displayedStudySummary.value = summary
        }
    }

    fun refresh12AmUsageStats() {
        viewModelScope.launch(Dispatchers.IO) {
            val summary = StudyTimeTracker.getTodayStudySummary(getApplication())
            _todayStudySummary.value = summary
            if (_selectedScreenTimeDate.value == StudyTimeTracker.getTodayDateString()) {
                _displayedStudySummary.value = summary
            } else {
                _displayedStudySummary.value = StudyTimeTracker.getDailyStudySummaryForDate(getApplication(), _selectedScreenTimeDate.value)
            }
            _availableArchiveDates.value = StudyTimeTracker.getArchivedDates(getApplication())
            StudyTimeTracker.triggerWidgetsRefresh(getApplication())

            // Sync daily app usages to Parent Dashboard (/app_usages)
            val todayStr = StudyTimeTracker.getTodayDateString()
            for ((idx, app) in summary.allAppsUsage.take(15).withIndex()) {
                try {
                    val minutes = (app.foregroundMillis / 60000L).coerceAtLeast(1L)
                    val cat = if (app.isDistraction) "distraction" else "study"
                    parentTelemetryRepo.pushAppUsage(
                        appName = app.appName,
                        packageName = app.packageName,
                        minutesSpent = minutes,
                        category = cat,
                        index = idx,
                        dateStr = todayStr
                    )
                } catch (_: Exception) {}
            }
        }
    }

    fun refreshStudyTimeStats() {
        refresh12AmUsageStats()
    }

    init {
        JeeNotificationHelper.initChannels(application)

        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = JeeRepository(
            examDao = db.examDao(),
            routineSessionDao = db.routineSessionDao(),
            reminderDao = db.studyReminderDao(),
            syllabusDao = db.syllabusDao(),
            mockTestDao = db.mockTestDao(),
            formulaDao = db.formulaDao(),
            sessionDao = db.studySessionDao(),
            mistakeDao = db.mistakeDao()
        )

        routineSessions = repository.allRoutineSessions
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        exams = repository.allExams
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        targetExam = repository.targetExam
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

        reminders = repository.allReminders
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        syllabusTopics = repository.allTopics
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        mockTests = repository.allMockTests
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        formulas = repository.allFormulas
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        mistakes = repository.allMistakes
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        unresolvedMistakeCount = repository.unresolvedMistakeCount
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 4)

        studySessions = repository.allSessions
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Initialize features
        loadInitialAlarms()
        loadInitialBlockedApps()
        checkAndPerformDailyReset()
        checkAndRestoreWallpaper()

        // Observe routine sessions to auto-schedule exact alarms and update active section
        viewModelScope.launch {
            routineSessions.collectLatest { list ->
                if (list.isNotEmpty()) {
                    FocusShieldManager.syncRoutineSessions(getApplication(), list)
                    updateCurrentActiveSection()
                    if (_isSectionNotificationEnabled.value) {
                        JeeNotificationHelper.scheduleSectionAlarms(getApplication(), list)
                    }
                }
            }
        }

        // Background ticker for checking current active session & section notifications
        viewModelScope.launch {
            while (true) {
                updateCurrentActiveSection()
                delay(15000) // check every 15 seconds
            }
        }

        // Periodic ticker for live study & distraction tracking stats
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                val summary = StudyTimeTracker.getTodayStudySummary(getApplication())
                _todayStudySummary.value = summary
                if (_selectedScreenTimeDate.value == StudyTimeTracker.getTodayDateString()) {
                    _displayedStudySummary.value = summary
                }
                delay(4000)
            }
        }
    }

    // -------------------------------------------------------------
    // DAILY TIMETABLE RESET SYSTEM
    // -------------------------------------------------------------
    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun checkAndPerformDailyReset() {
        val today = getTodayDateString()
        val lastResetDate = prefs.getString("last_timetable_reset_date", "")

        if (lastResetDate != today) {
            // New day detected! Ensure previous date's 12am usage was safely archived
            if (!lastResetDate.isNullOrBlank() && StudyTimeTracker.getArchivedSummary(getApplication(), lastResetDate) == null) {
                StudyTimeTracker.getDailyStudySummaryForDate(getApplication(), lastResetDate)
            }
            _availableArchiveDates.value = StudyTimeTracker.getArchivedDates(getApplication())

            // Reset all timetable completion marks for the new day
            _completedSessionIds.value = emptySet()
            prefs.edit()
                .putString("last_timetable_reset_date", today)
                .putStringSet("completed_sessions_$today", emptySet())
                .apply()

            val friendlyFormat = SimpleDateFormat("EEEE, MMM d", Locale.getDefault())
            _dailyResetMessage.value = "🌅 Good Morning! Timetable has been freshly reset for ${friendlyFormat.format(Date())}."
        } else {
            // Load saved completed sessions for today
            val saved = prefs.getStringSet("completed_sessions_$today", emptySet()) ?: emptySet()
            _completedSessionIds.value = saved.mapNotNull { it.toLongOrNull() }.toSet()
        }
    }

    fun resetTimetableToday() {
        val today = getTodayDateString()
        _completedSessionIds.value = emptySet()
        prefs.edit()
            .putStringSet("completed_sessions_$today", emptySet())
            .apply()
        _dailyResetMessage.value = "Timetable successfully reset for today!"
    }

    fun toggleSessionCompletion(sessionId: Long) {
        val current = _completedSessionIds.value.toMutableSet()
        if (current.contains(sessionId)) {
            current.remove(sessionId)
        } else {
            current.add(sessionId)
        }
        _completedSessionIds.value = current

        val today = getTodayDateString()
        prefs.edit()
            .putStringSet("completed_sessions_$today", current.map { it.toString() }.toSet())
            .apply()
    }

    fun clearDailyResetMessage() {
        _dailyResetMessage.value = null
    }

    // -------------------------------------------------------------
    // SECTION START NOTIFICATIONS & LIVE TRACKER
    // -------------------------------------------------------------
    private var lastNotifiedSessionTitle: String? = null

    private fun updateCurrentActiveSection() {
        val sessions = routineSessions.value
        if (sessions.isEmpty()) return

        val now = Calendar.getInstance()
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

        var matched: RoutineSession? = null
        for (session in sessions) {
            val startParts = session.startTime.split(":")
            val endParts = session.endTime.split(":")
            if (startParts.size >= 2 && endParts.size >= 2) {
                val startM = (startParts[0].toIntOrNull() ?: 0) * 60 + (startParts[1].toIntOrNull() ?: 0)
                val endM = (endParts[0].toIntOrNull() ?: 0) * 60 + (endParts[1].toIntOrNull() ?: 0)

                val isOngoing = if (endM > startM) {
                    currentMinutes in startM until endM
                } else if (endM < startM) {
                    currentMinutes >= startM || currentMinutes < endM
                } else {
                    currentMinutes in startM until (startM + 15)
                }

                if (isOngoing) {
                    matched = session
                    break
                }
            }
        }

        // If in a gap between sessions, find next upcoming session
        if (matched == null) {
            matched = sessions.firstOrNull { s ->
                val startParts = s.startTime.split(":")
                val startM = (startParts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (startParts.getOrNull(1)?.toIntOrNull() ?: 0)
                startM > currentMinutes
            } ?: sessions.firstOrNull()
        }

        _activeRoutineSession.value = matched
        com.example.widget.JeeRoutineWidgetProvider.updateAllWidgets(getApplication())
        com.example.widget.OngoingSectionWidgetProvider.updateAllWidgets(getApplication())

        // Automatic Strict Study Mode: auto-start if in ongoing study session
        val isStudy = matched?.isStudySlot() ?: false
        if (FocusShieldManager.isAutoTimetableSync(getApplication())) {
            if (isStudy) {
                FocusShieldManager.startStrictStudyService(getApplication())
            }
        }
        _isStrictEnforcedNow.value = FocusShieldManager.isStrictStudyCurrentlyEnforced(getApplication())
        _isOngoingStudySlot.value = FocusShieldManager.isCurrentlyInStudySection(getApplication())
        _isOngoingBreakSlot.value = FocusShieldManager.isCurrentlyInBreak(getApplication())

        // If a section is actively starting right now and hasn't been notified yet
        if (matched != null && _isSectionNotificationEnabled.value && matched.isNotificationEnabled) {
            if (lastNotifiedSessionTitle != matched.title) {
                lastNotifiedSessionTitle = matched.title
                JeeNotificationHelper.sendSectionStartNotification(
                    context = getApplication(),
                    title = matched.title,
                    category = matched.category,
                    timeSpan = matched.getFormattedTime(),
                    emoji = matched.emoji
                )
            }
        }
    }

    fun toggleSectionNotifications(enabled: Boolean) {
        _isSectionNotificationEnabled.value = enabled
        if (enabled) {
            scheduleAllSectionAlarms()
        }
    }

    fun scheduleAllSectionAlarms() {
        viewModelScope.launch(Dispatchers.IO) {
            val sessions = if (routineSessions.value.isNotEmpty()) {
                routineSessions.value
            } else {
                repository.getAllRoutineSessionsSync()
            }
            if (sessions.isNotEmpty()) {
                JeeNotificationHelper.scheduleSectionAlarms(getApplication(), sessions)
            }
        }
    }

    fun testSectionNotification() {
        val current = _activeRoutineSession.value ?: routineSessions.value.firstOrNull()
        JeeNotificationHelper.sendSectionStartNotification(
            context = getApplication(),
            title = current?.title ?: "Physics Mechanics Numerical Practice",
            category = current?.category ?: "Physics",
            timeSpan = current?.getFormattedTime() ?: "06:00 AM - 08:00 AM",
            emoji = current?.emoji ?: "⚛️"
        )
    }

    // -------------------------------------------------------------
    // ROUTINE EDIT / FILTER ACTIONS
    // -------------------------------------------------------------
    fun setCategoryFilter(category: String) {
        _selectedCategory.value = category
    }

    fun setDayFilter(day: String) {
        _selectedDay.value = day
    }

    fun toggleRoutineNotification(session: RoutineSession) {
        viewModelScope.launch {
            repository.toggleRoutineNotification(session.id, !session.isNotificationEnabled)
        }
    }

    fun deleteRoutineSession(session: RoutineSession) {
        viewModelScope.launch {
            repository.deleteRoutineSession(session)
        }
    }

    fun saveRoutineSession(session: RoutineSession) {
        viewModelScope.launch {
            if (session.id == 0L) {
                repository.insertRoutineSession(session)
            } else {
                repository.updateRoutineSession(session)
            }
            scheduleAllSectionAlarms()
        }
    }

    fun resetDefaultRoutine() {
        viewModelScope.launch {
            repository.resetDefaultRoutine(DefaultJeeData.getDefaultRoutineSessions())
            scheduleAllSectionAlarms()
        }
    }

    // -------------------------------------------------------------
    // IOS CLOCK: ALARMS SYSTEM
    // -------------------------------------------------------------
    private fun loadInitialAlarms() {
        _alarms.value = listOf(
            AlarmItem(hour = 5, minute = 45, label = "🌅 Wake Up + Water & Freshen", isEnabled = true),
            AlarmItem(hour = 6, minute = 0, label = "⚛️ Physics Numerical Slot", isEnabled = true),
            AlarmItem(hour = 9, minute = 30, label = "🧪 Chemistry NCERT / Revision", isEnabled = true),
            AlarmItem(hour = 14, minute = 0, label = "📐 Maths Calculus Sprint", isEnabled = true),
            AlarmItem(hour = 22, minute = 30, label = "🌙 Wind Down & Sleep", isEnabled = true)
        )
    }

    fun addAlarm(
        hour: Int,
        minute: Int,
        label: String,
        repeatDays: Set<Int>,
        isVibrate: Boolean,
        isSnooze: Boolean
    ) {
        val newAlarm = AlarmItem(
            hour = hour,
            minute = minute,
            label = label.ifBlank { "Study Alarm" },
            repeatDays = repeatDays,
            isEnabled = true,
            isVibrationEnabled = isVibrate,
            isSnoozeEnabled = isSnooze
        )
        _alarms.value = _alarms.value + newAlarm
        JeeNotificationHelper.scheduleUserAlarm(getApplication(), newAlarm)
    }

    fun toggleAlarm(alarmId: String) {
        val updated = _alarms.value.map { alarm ->
            if (alarm.id == alarmId) {
                val newState = !alarm.isEnabled
                if (newState) {
                    JeeNotificationHelper.scheduleUserAlarm(getApplication(), alarm.copy(isEnabled = true))
                } else {
                    JeeNotificationHelper.cancelUserAlarm(getApplication(), alarm.id)
                }
                alarm.copy(isEnabled = newState)
            } else {
                alarm
            }
        }
        _alarms.value = updated
    }

    fun deleteAlarm(alarmId: String) {
        JeeNotificationHelper.cancelUserAlarm(getApplication(), alarmId)
        _alarms.value = _alarms.value.filter { it.id != alarmId }
    }

    fun testAlarmSound(alarm: AlarmItem) {
        try {
            val alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(getApplication(), alert)
            ringtone?.play()
        } catch (_: Exception) {}

        JeeNotificationHelper.sendAlarmNotification(
            context = getApplication(),
            alarmId = alarm.id,
            label = alarm.label,
            timeFormatted = "${alarm.getFormattedTime()} ${alarm.getAmPm()}"
        )
    }

    // -------------------------------------------------------------
    // IOS CLOCK: STOPWATCH SYSTEM
    // -------------------------------------------------------------
    fun startStopwatch() {
        if (_isStopwatchRunning.value) return
        _isStopwatchRunning.value = true
        stopwatchJob = viewModelScope.launch {
            val startBase = System.currentTimeMillis() - _stopwatchMillis.value
            var lastTrackedSec = _stopwatchMillis.value / 1000
            while (_isStopwatchRunning.value) {
                val currentMillis = System.currentTimeMillis() - startBase
                _stopwatchMillis.value = currentMillis
                val currentSec = currentMillis / 1000
                if (currentSec > lastTrackedSec) {
                    val delta = (currentSec - lastTrackedSec).toInt()
                    lastTrackedSec = currentSec
                    StudyTimeTracker.recordTimerTick(getApplication(), delta)
                }
                delay(10) // 10ms for smooth hundredths of second
            }
        }
    }

    fun pauseStopwatch() {
        _isStopwatchRunning.value = false
        stopwatchJob?.cancel()
    }

    fun resetStopwatch() {
        pauseStopwatch()
        _stopwatchMillis.value = 0L
        _stopwatchLaps.value = emptyList()
    }

    fun lapStopwatch() {
        val current = _stopwatchMillis.value
        _stopwatchLaps.value = listOf(current) + _stopwatchLaps.value
    }

    // -------------------------------------------------------------
    // IOS CLOCK: COUNTDOWN TIMER SYSTEM
    // -------------------------------------------------------------
    fun startCountdown(totalSeconds: Long, label: String) {
        _timerTotalSeconds.value = totalSeconds
        _timerRemainingSeconds.value = totalSeconds
        _timerPresetName.value = label
        _isTimerRunning.value = true

        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (_isTimerRunning.value && _timerRemainingSeconds.value > 0) {
                delay(1000)
                _timerRemainingSeconds.value -= 1
                StudyTimeTracker.recordTimerTick(getApplication(), 1)
            }

            if (_timerRemainingSeconds.value <= 0 && _isTimerRunning.value) {
                _isTimerRunning.value = false
                triggerTimerCompletionAlert()
            }
        }
    }

    fun toggleCountdownPause() {
        if (_isTimerRunning.value) {
            _isTimerRunning.value = false
            countdownJob?.cancel()
        } else {
            if (_timerRemainingSeconds.value <= 0) {
                _timerRemainingSeconds.value = _timerTotalSeconds.value
            }
            _isTimerRunning.value = true
            countdownJob = viewModelScope.launch {
                while (_isTimerRunning.value && _timerRemainingSeconds.value > 0) {
                    delay(1000)
                    _timerRemainingSeconds.value -= 1
                    StudyTimeTracker.recordTimerTick(getApplication(), 1)
                }
                if (_timerRemainingSeconds.value <= 0 && _isTimerRunning.value) {
                    _isTimerRunning.value = false
                    triggerTimerCompletionAlert()
                }
            }
        }
    }

    fun resetCountdown() {
        _isTimerRunning.value = false
        countdownJob?.cancel()
        _timerRemainingSeconds.value = _timerTotalSeconds.value
    }

    private fun triggerTimerCompletionAlert() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getApplication<Application>().getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 400), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 400, 200, 400, 200, 400), -1)
            }

            val ringtone = RingtoneManager.getRingtone(
                getApplication(),
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            )
            ringtone?.play()
        } catch (_: Exception) {}

        JeeNotificationHelper.sendTimerFinishedNotification(
            context = getApplication(),
            label = _timerPresetName.value
        )
    }

    // -------------------------------------------------------------
    // FOCUS & DISTRACTION APP BLOCKER SYSTEM
    // -------------------------------------------------------------
    private fun loadInitialBlockedApps() {
        val loaded = FocusShieldManager.getBlockedApps(getApplication())
        _blockedApps.value = loaded
    }

    fun refreshShieldState() {
        val app = getApplication<android.app.Application>()
        _isFocusShieldActive.value = FocusShieldManager.isFocusShieldActive(app)
        _isAutoTimetableSync.value = FocusShieldManager.isAutoTimetableSync(app)
        _isManualSessionActive.value = FocusShieldManager.isManualSessionActive(app)
        _manualSessionRemainingSeconds.value = FocusShieldManager.getManualSessionRemainingSeconds(app)
        _manualSessionLabel.value = FocusShieldManager.getManualSessionLabel(app)
        _hasUsagePermission.value = FocusShieldManager.hasUsageStatsPermission(app)
        _hasOverlayPermission.value = FocusShieldManager.hasOverlayPermission(app)
        _hasBatteryExemption.value = FocusShieldManager.isBatteryOptimizationIgnored(app)
        _blockedApps.value = FocusShieldManager.getBlockedApps(app)
        _isStrictEnforcedNow.value = FocusShieldManager.isStrictStudyCurrentlyEnforced(app)
        _isOngoingStudySlot.value = FocusShieldManager.isCurrentlyInStudySection(app)
        _isOngoingBreakSlot.value = FocusShieldManager.isCurrentlyInBreak(app)
    }

    fun toggleFocusShield(active: Boolean) {
        _isFocusShieldActive.value = active
        FocusShieldManager.setFocusShieldActive(getApplication(), active)
        refreshShieldState()
    }

    fun toggleAutoTimetableSync(enabled: Boolean) {
        _isAutoTimetableSync.value = enabled
        FocusShieldManager.setAutoTimetableSync(getApplication(), enabled)
        refreshShieldState()
    }

    fun startManualFocusSession(durationMinutes: Int, label: String = "Strict Study Session") {
        FocusShieldManager.startManualFocusSession(getApplication(), durationMinutes, label)
        _isFocusShieldActive.value = true
        _isManualSessionActive.value = true
        _manualSessionRemainingSeconds.value = (durationMinutes * 60).toLong()
        _manualSessionLabel.value = label
        startManualSessionCountdown()
    }

    fun stopManualFocusSession() {
        FocusShieldManager.stopManualFocusSession(getApplication())
        _isManualSessionActive.value = false
        _manualSessionRemainingSeconds.value = 0L
    }

    private var manualSessionJob: Job? = null
    private fun startManualSessionCountdown() {
        manualSessionJob?.cancel()
        manualSessionJob = viewModelScope.launch {
            while (isActive && FocusShieldManager.isManualSessionActive(getApplication())) {
                _manualSessionRemainingSeconds.value = FocusShieldManager.getManualSessionRemainingSeconds(getApplication())
                delay(1000L)
            }
            _isManualSessionActive.value = false
            _manualSessionRemainingSeconds.value = 0L
        }
    }

    fun loadInstalledUserApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = FocusShieldManager.getInstalledUserApps(getApplication())
            _installedUserApps.value = list
        }
    }

    fun toggleInstalledApp(app: BlockedApp) {
        val currentBlocked = _blockedApps.value.toMutableList()
        val existingIndex = currentBlocked.indexOfFirst { it.packageName.equals(app.packageName, ignoreCase = true) }
        if (existingIndex >= 0) {
            val old = currentBlocked[existingIndex]
            currentBlocked[existingIndex] = old.copy(isBlocked = !old.isBlocked)
        } else {
            currentBlocked.add(app.copy(isBlocked = true))
        }
        _blockedApps.value = currentBlocked
        FocusShieldManager.saveBlockedApps(getApplication(), currentBlocked)

        // Also update installedUserApps list state
        _installedUserApps.value = _installedUserApps.value.map { item ->
            if (item.packageName.equals(app.packageName, ignoreCase = true)) {
                item.copy(isBlocked = !item.isBlocked)
            } else item
        }
    }

    fun grantEmergencyBreak(minutes: Int = 2) {
        FocusShieldManager.grantEmergencyBreak(getApplication(), minutes)
    }

    fun toggleAppBlocked(id: String) {
        val updated = _blockedApps.value.map { app ->
            if (app.id == id) app.copy(isBlocked = !app.isBlocked) else app
        }
        _blockedApps.value = updated
        FocusShieldManager.saveBlockedApps(getApplication(), updated)
        refreshStudyTimeStats()
    }

    fun toggleAppType(id: String) {
        val updated = _blockedApps.value.map { app ->
            if (app.id == id) {
                val newIsStudy = !app.isStudyApp
                app.copy(
                    isStudyApp = newIsStudy,
                    isBlocked = !newIsStudy,
                    category = if (newIsStudy) "Study & Prep" else "Distraction"
                )
            } else app
        }
        _blockedApps.value = updated
        FocusShieldManager.saveBlockedApps(getApplication(), updated)
        refreshStudyTimeStats()
    }

    fun addCustomBlockedApp(name: String, pkg: String, category: String = "Distracting App", emoji: String = "📱") {
        addCustomApp(name = name, pkg = pkg, category = category, emoji = emoji, isStudyApp = false)
    }

    fun addStudyApp(name: String, pkg: String, category: String = "Study & Prep", emoji: String = "📚") {
        addCustomApp(name = name, pkg = pkg, category = category, emoji = emoji, isStudyApp = true)
    }

    fun addCustomApp(name: String, pkg: String, category: String, emoji: String, isStudyApp: Boolean) {
        val newApp = BlockedApp(
            name = name,
            packageName = pkg.ifBlank { "custom.app.${name.lowercase().replace(" ", "")}" },
            category = category,
            iconEmoji = emoji,
            isBlocked = !isStudyApp,
            isStudyApp = isStudyApp
        )
        val updated = _blockedApps.value + newApp
        _blockedApps.value = updated
        FocusShieldManager.saveBlockedApps(getApplication(), updated)
        refreshStudyTimeStats()
    }

    fun addInstalledAsStudyApp(app: BlockedApp) {
        val currentBlocked = _blockedApps.value.toMutableList()
        val existingIndex = currentBlocked.indexOfFirst { it.packageName.equals(app.packageName, ignoreCase = true) }
        if (existingIndex >= 0) {
            currentBlocked[existingIndex] = currentBlocked[existingIndex].copy(
                isStudyApp = true,
                isBlocked = false,
                category = "Study & Prep",
                iconEmoji = if (currentBlocked[existingIndex].iconEmoji == "📱") "📚" else currentBlocked[existingIndex].iconEmoji
            )
        } else {
            currentBlocked.add(app.copy(isStudyApp = true, isBlocked = false, category = "Study & Prep", iconEmoji = "📚"))
        }
        _blockedApps.value = currentBlocked
        FocusShieldManager.saveBlockedApps(getApplication(), currentBlocked)
        refreshStudyTimeStats()
    }

    fun deleteBlockedApp(id: String) {
        val updated = _blockedApps.value.filter { it.id != id }
        _blockedApps.value = updated
        FocusShieldManager.saveBlockedApps(getApplication(), updated)
        refreshStudyTimeStats()
    }

    fun triggerDistractionShieldSimulation(app: BlockedApp) {
        _blockedAppToPreview.value = app
        _showDistractionShieldOverlay.value = true
    }

    fun dismissDistractionShield() {
        _showDistractionShieldOverlay.value = false
        _blockedAppToPreview.value = null
    }

    // -------------------------------------------------------------
    // SYLLABUS, MISTAKES, MOCKS & REMINDERS ACTIONS
    // -------------------------------------------------------------
    fun toggleTopicCompleted(topic: SyllabusTopic) {
        viewModelScope.launch {
            repository.setTopicCompleted(topic.id, !topic.isCompleted)
        }
    }

    fun togglePyqSolved(topic: SyllabusTopic) {
        viewModelScope.launch {
            repository.setPyqSolved(topic.id, !topic.pyqsSolved)
        }
    }

    fun incrementTopicRevision(topic: SyllabusTopic) {
        viewModelScope.launch {
            repository.incrementTopicRevision(topic.id)
        }
    }

    fun addMistake(mistake: MistakeItem) {
        viewModelScope.launch {
            repository.insertMistake(mistake)
        }
    }

    fun toggleMistakeResolved(mistake: MistakeItem) {
        viewModelScope.launch {
            repository.setMistakeResolved(mistake.id, !mistake.isResolved)
        }
    }

    fun deleteMistake(mistake: MistakeItem) {
        viewModelScope.launch {
            repository.deleteMistake(mistake)
        }
    }

    fun addMockTest(record: MockTestRecord) {
        viewModelScope.launch {
            repository.insertMockTest(record)
        }
    }

    fun deleteMockTest(record: MockTestRecord) {
        viewModelScope.launch {
            repository.deleteMockTest(record)
        }
    }

    fun toggleFormulaBookmark(card: FormulaCard) {
        viewModelScope.launch {
            repository.toggleFormulaBookmark(card.id, !card.isBookmarked)
        }
    }

    fun toggleReminder(reminder: StudyReminder) {
        viewModelScope.launch {
            repository.setReminderCompleted(reminder.id, !reminder.isCompleted)
        }
    }

    fun deleteReminder(reminder: StudyReminder) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
        }
    }

    fun addReminder(
        title: String,
        subject: String,
        dueMillis: Long,
        priority: String,
        notes: String,
        recurrence: String
    ) {
        viewModelScope.launch {
            repository.insertReminder(
                StudyReminder(
                    title = title,
                    subject = subject,
                    dueTimeMillis = dueMillis,
                    priority = priority,
                    notes = notes,
                    recurrence = recurrence
                )
            )
        }
    }

    fun resetRemindersToTimetable() {
        viewModelScope.launch {
            repository.resetReminders(DefaultJeeData.getDefaultReminders())
        }
    }

    // Practice Screen Timer methods
    fun setTimerMode(mode: String) {
        _timerMode.value = mode
        practiceTimerJob?.cancel()
        _timerSeconds.value = if (mode == "Sprint") 45 * 60L else 0L
    }

    fun setTimerSubject(subject: String) {
        _selectedTimerSubject.value = subject
    }

    fun setTimerTopic(topic: String) {
        _timerTopic.value = topic
    }

    fun toggleTimer() {
        if (practiceTimerJob?.isActive == true) {
            practiceTimerJob?.cancel()
        } else {
            practiceTimerJob = viewModelScope.launch {
                while (true) {
                    delay(1000)
                    if (_timerMode.value == "Sprint") {
                        if (_timerSeconds.value > 0) _timerSeconds.value -= 1
                    } else {
                        _timerSeconds.value += 1
                    }
                    StudyTimeTracker.recordTimerTick(getApplication(), 1)
                }
            }
        }
    }

    fun resetTimer() {
        practiceTimerJob?.cancel()
        _timerSeconds.value = if (_timerMode.value == "Sprint") 45 * 60L else 0L
    }

    fun saveTimerSession() {
        val duration = if (_timerMode.value == "Sprint") (45 * 60L - _timerSeconds.value) else _timerSeconds.value
        if (duration > 0) {
            viewModelScope.launch {
                val subjectName = _selectedTimerSubject.value.uppercase()
                val topicTitle = _timerTopic.value.ifBlank { "Deep Study Session" }
                repository.logSession(
                    StudySession(
                        subject = subjectName,
                        topic = topicTitle,
                        durationSeconds = duration,
                        mode = _timerMode.value.uppercase()
                    )
                )

                // Push real-time telemetry to Parent Dashboard (/study_sessions)
                try {
                    val durationMin = (duration / 60L).coerceAtLeast(1L)
                    parentTelemetryRepo.pushStudySession(
                        subjectName = subjectName,
                        topicTitle = topicTitle,
                        sessionMinutes = durationMin
                    )
                } catch (_: Exception) {}

                resetTimer()
            }
        }
    }

    private fun checkAndRestoreWallpaper() {
        val savedType = prefs.getString("bg_type", "DEFAULT") ?: "DEFAULT"
        val savedCustomUri = prefs.getString("bg_custom_uri", null)
        val internalWallpaper = File(getApplication<Application>().filesDir, "custom_study_wallpaper.jpg")

        if (savedType == "CUSTOM_IMAGE") {
            _backgroundType.value = "CUSTOM_IMAGE"
            if (internalWallpaper.exists() && internalWallpaper.length() > 0) {
                _customBgUri.value = internalWallpaper.absolutePath
            } else if (!savedCustomUri.isNullOrBlank()) {
                val cleanPath = savedCustomUri.removePrefix("file://")
                val file = File(cleanPath)
                if (file.exists() && file.length() > 0) {
                    _customBgUri.value = file.absolutePath
                } else {
                    _customBgUri.value = internalWallpaper.absolutePath
                }
            } else {
                _customBgUri.value = internalWallpaper.absolutePath
            }
        } else if (savedType == "PRESET") {
            val preset = prefs.getString("bg_preset", "COSMIC") ?: "COSMIC"
            _backgroundPreset.value = preset
            _backgroundType.value = "PRESET"
        }
    }

    // -------------------------------------------------------------
    // BACKGROUND & BLUR EFFECT CONTROLS
    // -------------------------------------------------------------
    fun setBackgroundPreset(presetKey: String) {
        _backgroundType.value = "PRESET"
        _backgroundPreset.value = presetKey
        prefs.edit()
            .putString("bg_type", "PRESET")
            .putString("bg_preset", presetKey)
            .apply()
    }

    fun setCustomBackgroundUri(uriString: String) {
        val internalWallpaper = File(getApplication<Application>().filesDir, "custom_study_wallpaper.jpg")
        val cleanPath = if (internalWallpaper.exists() && internalWallpaper.length() > 0) {
            internalWallpaper.absolutePath
        } else {
            uriString
        }

        _backgroundType.value = "CUSTOM_IMAGE"
        _customBgUri.value = cleanPath
        prefs.edit()
            .putString("bg_type", "CUSTOM_IMAGE")
            .putString("bg_custom_uri", cleanPath)
            .apply()

        // Mirror content URIs into internal app storage if needed
        if (uriString.startsWith("content://")) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    getApplication<Application>().contentResolver.openInputStream(Uri.parse(uriString))?.use { input ->
                        FileOutputStream(internalWallpaper).use { output ->
                            input.copyTo(output)
                            output.flush()
                        }
                    }
                    if (internalWallpaper.exists() && internalWallpaper.length() > 0) {
                        _customBgUri.value = internalWallpaper.absolutePath
                        prefs.edit()
                            .putString("bg_custom_uri", internalWallpaper.absolutePath)
                            .apply()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun setBlurIntensity(blur: Float) {
        _blurIntensity.value = blur
        prefs.edit().putFloat("bg_blur_intensity", blur).apply()
    }

    fun setBgDimOpacity(opacity: Float) {
        _bgDimOpacity.value = opacity
        prefs.edit().putFloat("bg_dim_opacity", opacity).apply()
    }

    fun resetBackgroundToDefault() {
        _backgroundType.value = "DEFAULT"
        prefs.edit().putString("bg_type", "DEFAULT").apply()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val internalWallpaper = File(getApplication<Application>().filesDir, "custom_study_wallpaper.jpg")
                if (internalWallpaper.exists()) {
                    internalWallpaper.delete()
                }
            } catch (_: Exception) {}
        }
    }

    // -------------------------------------------------------------
    // STUDY SESSION LOGGING (ROOM PERSISTENCE)
    // -------------------------------------------------------------
    fun logStudyHours(
        subject: String,
        topic: String,
        hours: Double,
        mode: String = "THEORY_PRACTICE",
        timestamp: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            val durationSec = (hours * 3600).toLong().coerceAtLeast(60L)
            val session = StudySession(
                subject = subject.trim().uppercase(),
                topic = topic.trim().ifBlank { "${subject.trim().lowercase().replaceFirstChar { it.uppercase() }} Study" },
                durationSeconds = durationSec,
                timestamp = timestamp,
                mode = mode
            )
            repository.logSession(session)

            // Real-time telemetry to Parent Dashboard (/study_sessions)
            try {
                val durationMin = (durationSec / 60L).coerceAtLeast(1L)
                parentTelemetryRepo.pushStudySession(
                    subjectName = subject.trim(),
                    topicTitle = session.topic,
                    sessionMinutes = durationMin
                )
            } catch (_: Exception) {}
        }
    }

    fun deleteStudySession(session: StudySession) {
        viewModelScope.launch {
            repository.deleteSession(session)
        }
    }

    fun deleteStudySessionById(id: Long) {
        viewModelScope.launch {
            repository.deleteSessionById(id)
        }
    }

    // -------------------------------------------------------------
    // HOME SCREEN WIDGET PINNING (ANDROID 8.0+)
    // -------------------------------------------------------------
    fun requestPinRoutineWidget(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val myProvider = ComponentName(context, com.example.widget.JeeRoutineWidgetProvider::class.java)
            if (appWidgetManager.isRequestPinAppWidgetSupported) {
                appWidgetManager.requestPinAppWidget(myProvider, null, null)
                return true
            }
        }
        return false
    }

    fun requestPinOngoingWidget(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val myProvider = ComponentName(context, com.example.widget.OngoingSectionWidgetProvider::class.java)
            if (appWidgetManager.isRequestPinAppWidgetSupported) {
                appWidgetManager.requestPinAppWidget(myProvider, null, null)
                return true
            }
        }
        return false
    }

    fun requestPinAppScreenTimeWidget(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val myProvider = ComponentName(context, com.example.widget.AppScreenTimeWidgetProvider::class.java)
            if (appWidgetManager.isRequestPinAppWidgetSupported) {
                appWidgetManager.requestPinAppWidget(myProvider, null, null)
                return true
            }
        }
        return false
    }

    fun requestPinStudyTimeWidget(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val myProvider = ComponentName(context, com.example.widget.StudyTimeWidgetProvider::class.java)
            if (appWidgetManager.isRequestPinAppWidgetSupported) {
                appWidgetManager.requestPinAppWidget(myProvider, null, null)
                return true
            }
        }
        return false
    }

    // -------------------------------------------------------------
    // EXAM MANAGEMENT & JEE 2028 COUNTDOWN TARGETS
    // -------------------------------------------------------------
    fun setTargetExam(examId: Long) {
        viewModelScope.launch {
            repository.setTargetExam(examId)
        }
    }

    fun addCustomExam(
        title: String,
        examDateMillis: Long,
        category: String = "EXAM",
        notes: String = "",
        setAsTarget: Boolean = true
    ) {
        viewModelScope.launch {
            val exam = ExamEvent(
                title = title,
                examDateMillis = examDateMillis,
                category = category,
                notes = notes,
                isTargetExam = setAsTarget
            )
            val newId = repository.insertExam(exam)
            if (setAsTarget) {
                repository.setTargetExam(newId)
            }
        }
    }

    fun updateExamDate(exam: ExamEvent, newDateMillis: Long) {
        viewModelScope.launch {
            repository.updateExam(exam.copy(examDateMillis = newDateMillis))
        }
    }

    fun resetToDefaultJee2028Exams() {
        viewModelScope.launch {
            val defaults = DefaultJeeData.getDefaultExams()
            for (ex in defaults) {
                repository.insertExam(ex)
            }
            val primary = exams.value.firstOrNull { it.title.contains("2028") && it.title.contains("Session 1") }
            if (primary != null) {
                repository.setTargetExam(primary.id)
            }
        }
    }

    /**
     * Complete Factory Restore: Restores 24h timetable, syllabus, reminders, exams, formulas, mistakes & theme.
     */
    fun restoreAllDefaults(onComplete: (String) -> Unit = {}) {
        viewModelScope.launch {
            // 1. Reset 24-hr routine
            val defaults = DefaultJeeData.getDefaultRoutineSessions()
            repository.resetDefaultRoutine(defaults)
            scheduleAllSectionAlarms()

            // 2. Reset reminders
            repository.resetReminders(DefaultJeeData.getDefaultReminders())

            // 3. Reset full NCERT syllabus
            repository.resetDefaultSyllabus(DefaultJeeData.getDefaultSyllabus())

            // 4. Reset target exams (JEE 2028 & 2026)
            repository.resetDefaultExams(DefaultJeeData.getDefaultExams())

            // 5. Reset high-yield formulas
            repository.resetDefaultFormulas(DefaultJeeData.getDefaultFormulas())

            // 6. Reset mistake deck
            repository.resetDefaultMistakes(DefaultJeeData.getDefaultMistakes())

            // 7. Reset mock test records
            repository.resetDefaultMockTests(DefaultJeeData.getDefaultMockTests())

            // 8. Reset theme and desk wallpaper
            resetBackgroundToDefault()

            // 9. Reset today's completed session checkmarks
            _completedSessionIds.value = emptySet()
            prefs.edit().remove("completed_sessions_today").apply()

            _dailyResetMessage.value = "All default JEE routines, syllabus & reminders successfully restored!"
            onComplete("All app data successfully restored to factory defaults!")
        }
    }

    fun restoreDefaultRoutine(onComplete: (String) -> Unit = {}) {
        viewModelScope.launch {
            val defaults = DefaultJeeData.getDefaultRoutineSessions()
            repository.resetDefaultRoutine(defaults)
            scheduleAllSectionAlarms()
            onComplete("24-Hour JEE routine (21 sessions) successfully restored!")
        }
    }

    fun restoreDefaultSyllabus(resetProgressOnly: Boolean = false, onComplete: (String) -> Unit = {}) {
        viewModelScope.launch {
            if (resetProgressOnly) {
                repository.resetSyllabusProgress()
                onComplete("Syllabus progress reset to 0%!")
            } else {
                repository.resetDefaultSyllabus(DefaultJeeData.getDefaultSyllabus())
                onComplete("Class 11th & 12th NCERT Syllabus restored!")
            }
        }
    }

    fun restoreDefaultReminders(onComplete: (String) -> Unit = {}) {
        viewModelScope.launch {
            repository.resetReminders(DefaultJeeData.getDefaultReminders())
            onComplete("10 official timetable study alarms restored!")
        }
    }

    fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("version", 2)
        root.put("timestamp", System.currentTimeMillis())
        root.put("appName", "JEE Reminder")

        // 1. Routine Sessions
        val routineArray = JSONArray()
        routineSessions.value.forEach { s ->
            val obj = JSONObject()
            obj.put("title", s.title)
            obj.put("startTime", s.startTime)
            obj.put("endTime", s.endTime)
            obj.put("displayTime", s.displayTime)
            obj.put("category", s.category)
            obj.put("emoji", s.emoji)
            obj.put("focusTopic", s.focusTopic ?: "")
            obj.put("description", s.description)
            obj.put("orderIndex", s.orderIndex)
            routineArray.put(obj)
        }
        root.put("routine", routineArray)

        // 2. Syllabus Topics
        val syllabusArray = JSONArray()
        syllabusTopics.value.forEach { t ->
            val obj = JSONObject()
            obj.put("chapterName", t.chapterName)
            obj.put("subject", t.subject)
            obj.put("standardClass", t.standardClass)
            obj.put("isCompleted", t.isCompleted)
            obj.put("pyqsSolved", t.pyqsSolved)
            obj.put("revisionCount", t.revisionCount)
            syllabusArray.put(obj)
        }
        root.put("syllabus", syllabusArray)

        // 3. Study Reminders
        val remindersArray = JSONArray()
        reminders.value.forEach { r ->
            val obj = JSONObject()
            obj.put("title", r.title)
            obj.put("subject", r.subject)
            obj.put("dueTimeMillis", r.dueTimeMillis)
            obj.put("priority", r.priority)
            obj.put("notes", r.notes)
            remindersArray.put(obj)
        }
        root.put("reminders", remindersArray)

        root.put("studySessionCount", studySessions.value.size)
        return root.toString(2)
    }

    fun restoreFromJson(jsonString: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val root = JSONObject(jsonString)
                var restoredCount = 0

                if (root.has("routine")) {
                    val rArray = root.getJSONArray("routine")
                    val list = mutableListOf<RoutineSession>()
                    for (i in 0 until rArray.length()) {
                        val o = rArray.getJSONObject(i)
                        list.add(
                            RoutineSession(
                                title = o.getString("title"),
                                startTime = o.getString("startTime"),
                                endTime = o.getString("endTime"),
                                displayTime = o.optString("displayTime", "${o.getString("startTime")}–${o.getString("endTime")}"),
                                category = o.getString("category"),
                                emoji = o.optString("emoji", "📚"),
                                focusTopic = o.optString("focusTopic").ifBlank { null },
                                description = o.optString("description", ""),
                                orderIndex = o.optInt("orderIndex", i + 1)
                            )
                        )
                    }
                    if (list.isNotEmpty()) {
                        repository.resetDefaultRoutine(list)
                        scheduleAllSectionAlarms()
                        restoredCount += list.size
                    }
                }

                if (root.has("syllabus")) {
                    val sArray = root.getJSONArray("syllabus")
                    val existing = syllabusTopics.value.associateBy { it.chapterName.lowercase().trim() }
                    for (i in 0 until sArray.length()) {
                        val o = sArray.getJSONObject(i)
                        val name = o.getString("chapterName").lowercase().trim()
                        val topic = existing[name]
                        if (topic != null) {
                            if (o.optBoolean("isCompleted", false)) {
                                repository.setTopicCompleted(topic.id, true)
                            }
                            if (o.optBoolean("pyqsSolved", false)) {
                                repository.setPyqSolved(topic.id, true)
                            }
                            val rev = o.optInt("revisionCount", 0)
                            if (rev > 0) {
                                repeat(rev) { repository.incrementTopicRevision(topic.id) }
                            }
                        }
                    }
                }

                onResult(true, "Successfully restored backup snapshot ($restoredCount timetable slots restored)!")
            } catch (e: Exception) {
                onResult(false, "Invalid JSON backup: ${e.localizedMessage}")
            }
        }
    }

    // -------------------------------------------------------------
    // PARENT DASHBOARD OVERSIGHT & REAL-TIME TELEMETRY
    // -------------------------------------------------------------
    fun getPairingCode(): String = parentTelemetryRepo.getPairingCode()

    fun setPairingCode(code: String) = parentTelemetryRepo.setPairingCode(code)

    fun restartParentObserver() = parentTelemetryRepo.restartParentLinkObserver()

    fun pushTestTelemetry(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = parentTelemetryRepo.pushTestSession()
            if (result.isSuccess) {
                onResult(true, result.getOrDefault("Test telemetry synced to Parent Dashboard!"))
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed pushing test telemetry"
                onResult(false, err)
            }
        }
    }

    fun syncTodayTelemetry(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                val sessions = repository.getAllSessionsSync()
                var sessionCount = 0
                for (s in sessions.take(15)) {
                    parentTelemetryRepo.pushStudySession(
                        subjectName = s.subject,
                        topicTitle = s.topic,
                        sessionMinutes = (s.durationSeconds / 60L).coerceAtLeast(1L),
                        dateStr = todayStr
                    )
                    sessionCount++
                }

                val summary = _todayStudySummary.value
                var appCount = 0
                if (summary != null) {
                    for ((idx, app) in summary.allAppsUsage.take(15).withIndex()) {
                        val minutes = (app.foregroundMillis / 60000L).coerceAtLeast(1L)
                        val cat = if (app.isDistraction) "distraction" else "study"
                        parentTelemetryRepo.pushAppUsage(
                            appName = app.appName,
                            packageName = app.packageName,
                            minutesSpent = minutes,
                            category = cat,
                            index = idx,
                            dateStr = todayStr
                        )
                        appCount++
                    }
                }

                onResult(true, "Synced $sessionCount study sessions and $appCount app usages to Parent Dashboard!")
            } catch (e: Exception) {
                onResult(false, e.localizedMessage ?: "Sync error")
            }
        }
    }
}
