package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.google.firebase.FirebaseApp
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ParentTelemetryRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("jee_parent_pairing_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val databaseId: String = try {
        context.getString(R.string.firestore_database_id)
    } catch (_: Exception) {
        "ai-studio-android-studypul-6e50c8ca-38ff-4712-9a27-72a58cbd0c76"
    }

    // Null when Firebase has not been configured. Local study tracking remains usable.
    val firestore: FirebaseFirestore? = try {
        if (FirebaseApp.getApps(context).isEmpty()) null
        else try {
            FirebaseFirestore.getInstance(databaseId)
        } catch (e: Exception) {
            Log.w(TAG, "Failed obtaining named firestore instance $databaseId, using default", e)
            FirebaseFirestore.getInstance()
        }
    } catch (e: Exception) {
        Log.w(TAG, "Firebase is not configured; parent dashboard sync is disabled", e)
        null
    }

    private fun currentFirebaseUser() = try { Firebase.auth.currentUser } catch (_: Exception) { null }

    private val _parentUids = MutableStateFlow<List<String>>(loadStoredParentUids())
    val parentUids: StateFlow<List<String>> = _parentUids.asStateFlow()

    private val _pairingStatus = MutableStateFlow<String>("Initializing...")
    val pairingStatus: StateFlow<String> = _pairingStatus.asStateFlow()

    private var linkListenerJob: kotlinx.coroutines.Job? = null

    init {
        startParentLinkObserver()
    }

    fun getPairingCode(): String {
        return prefs.getString(KEY_PAIRING_CODE, DEFAULT_PAIRING_CODE) ?: DEFAULT_PAIRING_CODE
    }

    fun setPairingCode(code: String) {
        val clean = code.trim().uppercase(Locale.getDefault()).take(8)
        if (clean.isNotBlank()) {
            prefs.edit().putString(KEY_PAIRING_CODE, clean).apply()
            publishStudentPairingLink()
            restartParentLinkObserver()
        }
    }

    fun getStudentUid(): String {
        return currentFirebaseUser()?.uid ?: "student_${getPairingCode()}"
    }

    fun getEffectiveParentUids(): List<String> {
        return _parentUids.value
    }

    private fun loadStoredParentUids(): List<String> {
        val stored = prefs.getStringSet(KEY_PARENT_UIDS, emptySet()) ?: emptySet()
        return stored.toList()
    }

    private fun saveStoredParentUids(uids: List<String>) {
        prefs.edit().putStringSet(KEY_PARENT_UIDS, uids.toSet()).apply()
    }

    fun restartParentLinkObserver() {
        startParentLinkObserver()
    }

    fun startParentLinkObserver() {
        linkListenerJob?.cancel()
        val pairingCode = getPairingCode()
        val currentUid = currentFirebaseUser()?.uid

        val db = firestore
        if (db == null) {
            _pairingStatus.value = "Offline mode: configure Firebase to enable Parent Dashboard sync"
            return
        }

        val queries = mutableListOf("student_$pairingCode", pairingCode)
        if (currentUid != null) {
            queries.add(currentUid)
        }

        _pairingStatus.value = "Listening for Parent code: $pairingCode"

        linkListenerJob = db.collection("parent_student_links")
            .whereIn("studentId", queries)
            .snapshots()
            .onEach { snapshot ->
                val parents = snapshot.documents.mapNotNull { doc ->
                    doc.getString("parentId") ?: doc.getString("parentUid")
                }.filter { it.isNotBlank() }.distinct()

                _parentUids.value = parents
                saveStoredParentUids(parents)

                if (parents.isNotEmpty()) {
                    _pairingStatus.value = "Connected to ${parents.size} Parent Dashboard(s)"
                    Log.d(TAG, "Parent link active: $parents")
                } else {
                    _pairingStatus.value = "Waiting for parent to enter $pairingCode in Study Dashboard"
                }
            }
            .catch { error ->
                Log.w(TAG, "Parent student link listener error", error)
                _pairingStatus.value = "Link sync: ${error.message}"
            }
            .launchIn(scope)

        // Automatically publish student pairing link so parent app can locate student record
        publishStudentPairingLink()
    }

    fun publishStudentPairingLink() {
        val db = firestore ?: run {
            _pairingStatus.value = "Offline mode: configure Firebase to enable Parent Dashboard sync"
            return
        }
        val pairingCode = getPairingCode()
        val linkDocId = "link_${pairingCode}"
        val user = currentFirebaseUser()

        val linkData = mapOf(
            "studentId" to "student_$pairingCode",
            "studentUid" to (user?.uid ?: "student_$pairingCode"),
            "pairingCode" to pairingCode,
            "studentName" to (user?.displayName ?: "JEE Student"),
            "studentEmail" to (user?.email ?: ""),
            "linkedApp" to "JEE Reminder",
            "updatedAt" to FieldValue.serverTimestamp()
        )

        scope.launch {
            try {
                db.collection("parent_student_links")
                    .document(linkDocId)
                    .set(linkData)
                    .await()
                Log.d(TAG, "Published student pairing code $pairingCode")
            } catch (e: Exception) {
                Log.w(TAG, "Could not publish pairing code doc", e)
            }
        }
    }

    /**
     * A. Push Study Session (/study_sessions)
     * Path: db.collection("study_sessions").document()
     */
    suspend fun pushStudySession(
        subjectName: String,
        topicTitle: String,
        sessionMinutes: Long,
        startTimeFormatted: String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
        dateStr: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    ): Result<String> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.failure(IllegalStateException("Firebase is not configured; parent sync is unavailable"))
        val studentUid = getStudentUid()
        val parentList = getEffectiveParentUids()

        val data = mapOf(
            "userId" to studentUid,
            "subject" to subjectName,
            "topic" to topicTitle,
            "startTime" to startTimeFormatted,
            "durationMinutes" to sessionMinutes.coerceAtLeast(1L),
            "sessionDate" to dateStr,
            "completed" to true,
            "source" to "reminder_app",
            "parentUids" to parentList,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        try {
            val docRef = db.collection("study_sessions").add(data).await()
            Log.d(TAG, "Successfully pushed study session ${docRef.id} to Firestore")
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed pushing study session to Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * B. Daily Screen Time & App Usage (/app_usages)
     * Path: db.collection("app_usages").document("${studentUid}_app_${dateStr}_${index}")
     */
    suspend fun pushAppUsage(
        appName: String,
        packageName: String,
        minutesSpent: Long,
        category: String, // "study" | "distraction"
        index: Int = 0,
        dateStr: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    ): Result<String> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.failure(IllegalStateException("Firebase is not configured; parent sync is unavailable"))
        val studentUid = getStudentUid()
        val parentList = getEffectiveParentUids()
        val docId = "${studentUid}_app_${dateStr}_${index}"

        val data = mapOf(
            "userId" to studentUid,
            "dateStr" to dateStr,
            "appName" to appName,
            "packageName" to packageName,
            "durationMinutes" to minutesSpent.coerceAtLeast(1L),
            "category" to category,
            "parentUids" to parentList,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        try {
            db.collection("app_usages").document(docId).set(data).await()
            Log.d(TAG, "Successfully synced app usage $appName ($minutesSpent min)")
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed pushing app usage", e)
            Result.failure(e)
        }
    }

    /**
     * C. Distraction & Lockout Shield Log (/distraction_logs)
     * Path: db.collection("distraction_logs").document()
     */
    suspend fun pushDistractionLog(
        blockedAppName: String,
        currentSlotName: String,
        isEmergencyUnlock: Boolean = false,
        timeString: String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
        dateStr: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    ): Result<String> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.failure(IllegalStateException("Firebase is not configured; parent sync is unavailable"))
        val studentUid = getStudentUid()
        val parentList = getEffectiveParentUids()

        val data = mapOf(
            "userId" to studentUid,
            "dateStr" to dateStr,
            "appName" to blockedAppName,
            "studySlot" to currentSlotName,
            "timeString" to timeString,
            "isEmergencyBreak" to isEmergencyUnlock,
            "parentUids" to parentList,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        try {
            val docRef = db.collection("distraction_logs").add(data).await()
            Log.d(TAG, "Successfully pushed distraction log: $blockedAppName")
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed pushing distraction log", e)
            Result.failure(e)
        }
    }

    /**
     * Test verification sync: Pushes sample session, app usage, and distraction log
     */
    suspend fun pushTestSession(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            pushStudySession(
                subjectName = "Physics",
                topicTitle = "Rotational Dynamics & Torque",
                sessionMinutes = 120L,
                startTimeFormatted = timeFmt,
                dateStr = dateFmt
            )

            pushAppUsage(
                appName = "Physics Wallah",
                packageName = "xyz.penpencil.physicswala",
                minutesSpent = 90L,
                category = "study",
                index = 1,
                dateStr = dateFmt
            )

            pushDistractionLog(
                blockedAppName = "Instagram",
                currentSlotName = "Rotational Dynamics 2:00 PM - 5:00 PM",
                isEmergencyUnlock = false,
                timeString = timeFmt,
                dateStr = dateFmt
            )

            Result.success("Test study session, screen time, and distraction log synced to Parent Study Dashboard!")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        private const val TAG = "ParentTelemetryRepo"
        const val DEFAULT_PAIRING_CODE = "JEE789"
        private const val KEY_PAIRING_CODE = "key_student_pairing_code"
        private const val KEY_PARENT_UIDS = "key_linked_parent_uids"
    }
}
