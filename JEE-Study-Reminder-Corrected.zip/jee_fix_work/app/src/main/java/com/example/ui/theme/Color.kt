package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val JeeNavy = Color(0xFF0D253F)
val JeePrimary = Color(0xFF1E6091)
val JeePrimaryLight = Color(0xFF2A74AA)
val JeeAccentGold = Color(0xFFFFB703)
val JeeAccentOrange = Color(0xFFFB8500)
val JeeCyan = Color(0xFF00B4D8)

// Subject Specific
val PhysicsBlue = Color(0xFF1976D2)
val PhysicsBlueLight = Color(0xFFBBDEFB)
val ChemistryGreen = Color(0xFF2E7D32)
val ChemistryGreenLight = Color(0xFFC8E6C9)
val MathsRed = Color(0xFFD32F2F)
val MathsRedLight = Color(0xFFFFCDD2)

// Priority Colors
val PriorityHigh = Color(0xFFE53935)
val PriorityMedium = Color(0xFFFB8C00)
val PriorityLow = Color(0xFF43A047)

// Status / Surfaces
val DarkBackground = Color(0xFF0F141C)
val DarkSurface = Color(0xFF1A222D)
val DarkSurfaceElevated = Color(0xFF232D3B)
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEEF2F6)

// Base M3 colors
val PrimaryBlue80 = Color(0xFF90CAF9)
val SecondaryGold80 = Color(0xFFFFE082)
val TertiaryCyan80 = Color(0xFF80DEEA)

val PrimaryBlue40 = Color(0xFF1565C0)
val SecondaryGold40 = Color(0xFFF57F17)
val TertiaryCyan40 = Color(0xFF00838F)

// Apple iOS Design System Colors
val IosBackground = Color(0xFF000000)
val IosCard = Color(0xFF1C1C1E)
val IosCardElevated = Color(0xFF2C2C2E)
val IosCardHover = Color(0xFF3A3A3C)
val IosBorder = Color(0xFF38383A)
val IosBlue = Color(0xFF0A84FF)
val IosGreen = Color(0xFF30D158)
val IosOrange = Color(0xFFFF9F0A)
val IosRed = Color(0xFFFF453A)
val IosYellow = Color(0xFFFFD60A)
val IosPurple = Color(0xFFBF5AF2)
val IosIndigo = Color(0xFF5E5CE6)
val IosTeal = Color(0xFF64D2FF)
val IosGray = Color(0xFF8E8E93)
val IosLightGray = Color(0xFFAEAEC2)
val IosLabelPrimary = Color(0xFFFFFFFF)
val IosLabelSecondary = Color(0x99EBEBF5)
val IosLabelTertiary = Color(0x4DEBEBF5)

