package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.service.FocusShieldManager
import com.example.service.StudyTimeTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StudyTimeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == ACTION_REFRESH_STUDY_TIME_WIDGET ||
            action == Intent.ACTION_TIME_TICK ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == AppWidgetManager.ACTION_APPWIDGET_UPDATE
        ) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, StudyTimeWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId)
            }
        }
    }

    companion object {
        const val ACTION_REFRESH_STUDY_TIME_WIDGET = "com.example.widget.ACTION_REFRESH_STUDY_TIME_WIDGET"

        fun updateAllWidgets(context: Context) {
            try {
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val thisWidget = ComponentName(context, StudyTimeWidgetProvider::class.java)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
                if (appWidgetIds.isNotEmpty()) {
                    for (id in appWidgetIds) {
                        updateAppWidget(context, appWidgetManager, id)
                    }
                }
            } catch (e: Exception) {
                Log.e("StudyTimeWidget", "Failed to update widgets", e)
            }
        }

        private fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val scope = CoroutineScope(Dispatchers.IO)
            scope.launch {
                try {
                    val summary = StudyTimeTracker.getTodayStudySummary(context)
                    val (activeSession, isOngoing) = FocusShieldManager.getCurrentOngoingSession(context)
                    val activeSectionRecord = activeSession?.let { session ->
                        summary.sections.firstOrNull { it.sectionId == session.id }
                    }

                    withContext(Dispatchers.Main) {
                        renderWidget(context, appWidgetManager, appWidgetId, summary, activeSession?.title, activeSession?.emoji, isOngoing, activeSectionRecord)
                    }
                } catch (e: Exception) {
                    Log.w("StudyTimeWidget", "Could not query study summary, fallback rendering", e)
                }
            }
        }

        private fun renderWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            summary: com.example.service.DailyStudySummary,
            activeTitle: String?,
            activeEmoji: String?,
            isOngoing: Boolean,
            sectionRecord: com.example.service.SectionStudyRecord?
        ) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_study_time)

                // Main Study Time
                views.setTextViewText(R.id.widget_st_main_time, summary.getFormattedTotalStudy())

                // Goal Percent
                val goalPercent = summary.getDailyGoalProgressPercent()
                views.setTextViewText(R.id.widget_st_goal_percent, "${goalPercent}% of 8h Goal")

                // Efficiency Badge
                val totalFocusAndDistract = summary.totalStudySeconds + summary.distractionSeconds
                val efficiency = if (totalFocusAndDistract > 0) {
                    ((summary.totalStudySeconds.toFloat() / totalFocusAndDistract.toFloat()) * 100).toInt().coerceIn(0, 100)
                } else {
                    100
                }
                views.setTextViewText(R.id.widget_st_efficiency_badge, "⚡ ${efficiency}% Focus")

                // 3 Metric Chips
                views.setTextViewText(R.id.widget_st_timer_chip, "⏱️ Timer: ${summary.getFormattedTimer()}")
                views.setTextViewText(R.id.widget_st_app_chip, "📱 In-App: ${summary.getFormattedAppOpen()}")
                views.setTextViewText(R.id.widget_st_distract_chip, "🛑 Distract: ${summary.getFormattedDistraction()}")

                // Ongoing Section Block
                if (activeTitle != null) {
                    views.setViewVisibility(R.id.widget_st_section_container, View.VISIBLE)
                    views.setTextViewText(R.id.widget_st_section_emoji, activeEmoji ?: "⚡")

                    val tag = if (isOngoing) "LIVE: " else "UPCOMING: "
                    views.setTextViewText(R.id.widget_st_section_title, "$tag$activeTitle")

                    if (sectionRecord != null) {
                        val secStudy = sectionRecord.getFormattedStudyTime()
                        val targetMin = sectionRecord.targetSeconds / 60
                        val targetFormatted = "${targetMin / 60}h ${targetMin % 60}m"
                        views.setTextViewText(R.id.widget_st_section_time, "$secStudy / $targetFormatted")

                        val detail = "Counted: Timer ${sectionRecord.getFormattedTimerTime()} • App ${sectionRecord.getFormattedAppOpenTime()} • Distraction ${sectionRecord.getFormattedDistractionTime()}"
                        views.setTextViewText(R.id.widget_st_section_details, detail)
                    } else {
                        views.setTextViewText(R.id.widget_st_section_time, "Ready to study")
                        views.setTextViewText(R.id.widget_st_section_details, "Open app or start timer to track this section")
                    }
                } else {
                    views.setViewVisibility(R.id.widget_st_section_container, View.GONE)
                }

                // Click Actions:
                // Start Timer button -> opens Tab 3 (iOS Clock / Timer / Stopwatch)
                val timerIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(MainActivity.EXTRA_NAV_TAB, 3)
                }
                val pendingTimer = PendingIntent.getActivity(
                    context,
                    301,
                    timerIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_st_btn_timer, pendingTimer)

                // Timetable button -> opens Tab 1 (Timetable Routine)
                val routineIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(MainActivity.EXTRA_NAV_TAB, 1)
                }
                val pendingRoutine = PendingIntent.getActivity(
                    context,
                    302,
                    routineIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_st_btn_routine, pendingRoutine)

                // Root opens MainScreen Dashboard (Tab 0)
                val rootIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(MainActivity.EXTRA_NAV_TAB, 0)
                }
                val pendingRoot = PendingIntent.getActivity(
                    context,
                    303,
                    rootIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_study_time_root, pendingRoot)

                // Refresh Button
                val refreshIntent = Intent(context, StudyTimeWidgetProvider::class.java).apply {
                    action = ACTION_REFRESH_STUDY_TIME_WIDGET
                }
                val pendingRefresh = PendingIntent.getBroadcast(
                    context,
                    304,
                    refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_st_btn_refresh, pendingRefresh)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                Log.e("StudyTimeWidget", "Error rendering widget", e)
            }
        }
    }
}
