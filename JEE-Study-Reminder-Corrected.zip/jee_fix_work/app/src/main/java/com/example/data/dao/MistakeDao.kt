package com.example.data.dao

import androidx.room.*
import com.example.data.model.MistakeItem
import kotlinx.coroutines.flow.Flow

@Dao
interface MistakeDao {
    @Query("SELECT * FROM mistake_items ORDER BY createdAt DESC")
    fun getAllMistakes(): Flow<List<MistakeItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMistake(mistake: MistakeItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(mistakes: List<MistakeItem>)

    @Update
    suspend fun updateMistake(mistake: MistakeItem)

    @Delete
    suspend fun deleteMistake(mistake: MistakeItem)

    @Query("UPDATE mistake_items SET isResolved = :resolved WHERE id = :id")
    suspend fun setResolved(id: Long, resolved: Boolean)

    @Query("SELECT COUNT(*) FROM mistake_items WHERE isResolved = 0")
    fun getUnresolvedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM mistake_items")
    suspend fun countMistakes(): Int

    @Query("DELETE FROM mistake_items")
    suspend fun deleteAllMistakes()
}
