package com.example.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import com.example.util.JeeNotificationHelper
import java.util.Calendar

class SectionAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "JeeReminder:SectionAlarmWakeLock"
        )
        wakeLock?.acquire(3000L)

        val title = intent.getStringExtra("title") ?: "JEE Study Session"
        val category = intent.getStringExtra("category") ?: "Routine"
        val timeSpan = intent.getStringExtra("timeSpan") ?: ""
        val emoji = intent.getStringExtra("emoji") ?: "🔔"
        val sessionId = intent.getLongExtra("sessionId", -1L)
        val startTime = intent.getStringExtra("startTime") ?: ""

        // Post notification with sound & heads-up vibration
        JeeNotificationHelper.sendSectionStartNotification(
            context = context,
            title = title,
            category = category,
            timeSpan = timeSpan,
            emoji = emoji
        )

        // Automatically toggle Strict Study Mode:
        // ON during study sessions, OFF during breaks
        if (com.example.service.FocusShieldManager.isAutoTimetableSync(context)) {
            val sessionStub = com.example.data.model.RoutineSession(
                category = category,
                title = title,
                startTime = startTime,
                endTime = "",
                emoji = emoji
            )
            if (sessionStub.isStudySlot()) {
                // Study section began: turn ON strict mode
                com.example.service.FocusShieldManager.startStrictStudyService(context)
            } else {
                // Break section began: StrictStudyService will automatically pause blocking
                // and keep distractions unlocked during this break
            }
        }

        // Update home screen widgets to show this ongoing section
        com.example.widget.OngoingSectionWidgetProvider.updateAllWidgets(context)
        com.example.widget.JeeRoutineWidgetProvider.updateAllWidgets(context)

        // Automatically reschedule for tomorrow so notifications repeat forever even if app is closed
        if (startTime.isNotBlank()) {
            val parts = startTime.split(":")
            if (parts.size >= 2) {
                val hour = parts[0].trim().toIntOrNull() ?: return
                val minute = parts[1].trim().toIntOrNull() ?: return

                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                val nextTarget = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, 1)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }

                val nextIntent = Intent(context, SectionAlarmReceiver::class.java).apply {
                    putExtra("title", title)
                    putExtra("category", category)
                    putExtra("timeSpan", timeSpan)
                    putExtra("emoji", emoji)
                    putExtra("sessionId", sessionId)
                    putExtra("startTime", startTime)
                }

                val requestCode = if (sessionId > 0) (1000 + sessionId).toInt() else (1000 + title.hashCode()).toInt()
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    nextIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                )

                if (alarmManager != null) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            val showIntent = Intent(context, com.example.MainActivity::class.java)
                            val showPendingIntent = PendingIntent.getActivity(
                                context,
                                requestCode,
                                showIntent,
                                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                            )
                            alarmManager.setAlarmClock(
                                AlarmManager.AlarmClockInfo(nextTarget.timeInMillis, showPendingIntent),
                                pendingIntent
                            )
                        } else {
                            alarmManager.setExact(AlarmManager.RTC_WAKEUP, nextTarget.timeInMillis, pendingIntent)
                        }
                    } catch (e: Exception) {
                        try {
                            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTarget.timeInMillis, pendingIntent)
                        } catch (e2: Exception) {
                            alarmManager.set(AlarmManager.RTC_WAKEUP, nextTarget.timeInMillis, pendingIntent)
                        }
                    }
                }
            }
        }
    }
}
