package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.NotificationsOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RoutineSession
import com.example.ui.viewmodel.JeeViewModel

@Composable
fun RoutineScreen(
    viewModel: JeeViewModel,
    onNavigateToReminders: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val routineSessions by viewModel.routineSessions.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedDay by viewModel.selectedDay.collectAsState()
    val completedSessionIds by viewModel.completedSessionIds.collectAsState()
    val dailyResetMessage by viewModel.dailyResetMessage.collectAsState()
    val isSectionNotificationEnabled by viewModel.isSectionNotificationEnabled.collectAsState()
    val activeSession by viewModel.activeRoutineSession.collectAsState()
    val studySummary by viewModel.todayStudySummary.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showBgDialog by remember { mutableStateOf(false) }
    var sessionToEdit by remember { mutableStateOf<RoutineSession?>(null) }
    var sessionToDelete by remember { mutableStateOf<RoutineSession?>(null) }
    var showResetDefaultConfirmDialog by remember { mutableStateOf(false) }

    val bgType by viewModel.backgroundType.collectAsState()
    val bgPreset by viewModel.backgroundPreset.collectAsState()
    val customBgUri by viewModel.customBgUri.collectAsState()
    val blurIntensity by viewModel.blurIntensity.collectAsState()
    val bgDimOpacity by viewModel.bgDimOpacity.collectAsState()

    val categories = listOf(
        "All Categories",
        "Physics",
        "Chemistry",
        "Mathematics",
        "Walking/relaxation",
        "Breaks",
        "Coaching/classes",
        "Revision",
        "Dinner",
        "Sleep"
    )

    val daysOfWeek = listOf("All", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    val filteredSessions = remember(routineSessions, selectedCategory, selectedDay) {
        routineSessions.filter { session ->
            val matchesCategory = selectedCategory == "All Categories" || session.category.equals(selectedCategory, ignoreCase = true)
            val matchesDay = if (selectedDay == "All") true else {
                val dayLetter = when (selectedDay) {
                    "Sun" -> "S"
                    "Mon" -> "M"
                    "Tue" -> "T"
                    "Wed" -> "W"
                    "Thu" -> "T"
                    "Fri" -> "F"
                    "Sat" -> "S"
                    else -> ""
                }
                session.days.contains(dayLetter)
            }
            matchesCategory && matchesDay
        }
    }

    var isTableView by remember { mutableStateOf(true) }

    Box(
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Daily Reset Notification / Toast Banner if triggered
            if (dailyResetMessage != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B382B)),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF34C759))
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(text = "🌅", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = dailyResetMessage ?: "",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            IconButton(
                                onClick = { viewModel.clearDailyResetMessage() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Header Top Card: "Daily JEE Timetable"
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xB810172A)),
                    border = BorderStroke(1.dp, Color(0x2660A5FA))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Daily JEE Timetable",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Auto-Resets Daily at Midnight • ${completedSessionIds.size}/${routineSessions.size} Completed",
                                    fontSize = 12.sp,
                                    color = Color(0xFF34C759),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { viewModel.resetTimetableToday() },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2C2C2E))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.RestartAlt,
                                        contentDescription = "Reset Today",
                                        tint = Color(0xFF34C759),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Restore Default Timetable
                                IconButton(
                                    onClick = { showResetDefaultConfirmDialog = true },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2C2C2E))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Restore,
                                        contentDescription = "Restore Default Timetable",
                                        tint = Color(0xFF60A5FA),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Background & Blur Edit Button
                                IconButton(
                                    onClick = { showBgDialog = true },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2C2C2E))
                                        .testTag("edit_background_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Palette,
                                        contentDescription = "Edit Background & Blur",
                                        tint = Color(0xFFFF9F0A),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Button(
                                    onClick = {
                                        sessionToEdit = null
                                        showAddDialog = true
                                    },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A84FF)),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("add_session_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "+ Section",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }

                        // Daily Completion Progress Bar
                        if (routineSessions.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            val progress = completedSessionIds.size.toFloat() / routineSessions.size.toFloat()
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFF34C759),
                                trackColor = Color(0xFF2C2C2E)
                            )
                        }
                    }
                }
            }


            // View Mode Toggle (Table View vs Card View)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x99131D36))
                        .border(BorderStroke(1.dp, Color(0x3360A5FA)), RoundedCornerShape(16.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isTableView) Color(0xFF2563EB) else Color.Transparent)
                            .clickable { isTableView = true }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.List,
                                contentDescription = null,
                                tint = if (isTableView) Color.White else Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Table View",
                                fontSize = 13.sp,
                                fontWeight = if (isTableView) FontWeight.Bold else FontWeight.Medium,
                                color = if (isTableView) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (!isTableView) Color(0xFF2563EB) else Color.Transparent)
                            .clickable { isTableView = false }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = null,
                                tint = if (!isTableView) Color.White else Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Detailed Cards",
                                fontSize = 13.sp,
                                fontWeight = if (!isTableView) FontWeight.Bold else FontWeight.Medium,
                                color = if (!isTableView) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // Category Filter Pills
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { category ->
                        val isSelected = selectedCategory == category
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) Color(0xFF2563EB) else Color(0x66182236))
                                .border(
                                    BorderStroke(1.dp, if (isSelected) Color(0xFF60A5FA) else Color(0x3360A5FA)),
                                    RoundedCornerShape(20.dp)
                                )
                                .clickable { viewModel.setCategoryFilter(category) }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = category,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // Day Filter Pills (All, Sun, Mon, Tue, Wed, Thu, Fri, Sat)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x99131D36))
                        .border(BorderStroke(1.dp, Color(0x3360A5FA)), RoundedCornerShape(24.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    daysOfWeek.forEach { day ->
                        val isSelected = selectedDay == day
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (isSelected) Color.White else Color.Transparent)
                                .clickable { viewModel.setDayFilter(day) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = day,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF0B132B) else Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // Sessions Display: Table View or Cards View
            if (filteredSessions.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No sessions found for this filter.",
                            color = Color(0xFF94A3B8),
                            fontSize = 14.sp
                        )
                    }
                }
            } else if (isTableView) {
                // Table View matching the screenshots
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xB80D1526)),
                        border = BorderStroke(1.dp, Color(0x3360A5FA))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // Table Header: Time | Activity | Actions
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Time",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8),
                                    modifier = Modifier.width(100.dp).padding(start = 28.dp)
                                )
                                Text(
                                    text = "Activity",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "Actions",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8),
                                    modifier = Modifier.padding(end = 4.dp)
                                )
                            }

                            HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp)

                            // Rows
                            filteredSessions.forEachIndexed { index, session ->
                                val isCompleted = completedSessionIds.contains(session.id)
                                val isLive = activeSession?.id == session.id

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isLive) Color(0xFF1B2B45) else Color.Transparent)
                                        .clickable {
                                            sessionToEdit = session
                                            showAddDialog = true
                                        }
                                        .padding(vertical = 10.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Checkbox for Daily Completion
                                    IconButton(
                                        onClick = { viewModel.toggleSessionCompletion(session.id) },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = "Toggle completion",
                                            tint = if (isCompleted) Color(0xFF34C759) else Color(0xFF64748B),
                                            modifier = Modifier.size(19.dp)
                                        )
                                    }

                                    // Time Column with LIVE badge
                                    Column(modifier = Modifier.width(95.dp)) {
                                        Text(
                                            text = session.getFormattedTime(),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCompleted) Color(0xFF8E8E93) else Color.White
                                        )
                                        if (isLive) {
                                            val isStudy = session.isStudySlot()
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (isStudy) Color(0xFF10B981) else Color(0xFF38BDF8))
                                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = if (isStudy) "🛡️ STRICT" else "☕ BREAK",
                                                    color = Color.Black,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    // Activity Column
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = session.emoji,
                                            fontSize = 18.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = session.title,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (isCompleted) Color(0xFF8E8E93) else Color.White
                                            )
                                            if (!session.focusTopic.isNullOrBlank()) {
                                                Text(
                                                    text = session.focusTopic,
                                                    fontSize = 11.sp,
                                                    color = if (isCompleted) Color(0xFF64748B) else Color(0xFF60A5FA),
                                                    maxLines = 1
                                                )
                                            }

                                            val secRecord = studySummary.sections.firstOrNull { it.sectionId == session.id }
                                            if (secRecord != null && (secRecord.totalStudySeconds > 0 || secRecord.distractionSeconds > 0)) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = "⚡ Study: ${secRecord.getFormattedStudyTime()} (Timer ${secRecord.getFormattedTimerTime()} • App ${secRecord.getFormattedAppOpenTime()})",
                                                        fontSize = 10.sp,
                                                        color = Color(0xFF34D399),
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                    if (secRecord.distractionSeconds > 0) {
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = "• 🛑 ${secRecord.getFormattedDistractionTime()} distract",
                                                            fontSize = 10.sp,
                                                            color = Color(0xFFFCA5A5),
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Action Icons: Bell, Edit, Delete
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        // Quick Bell toggle
                                        IconButton(
                                            onClick = { viewModel.toggleRoutineNotification(session) },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (session.isNotificationEnabled) Icons.Filled.Notifications else Icons.Outlined.NotificationsOff,
                                                contentDescription = "Notification",
                                                tint = if (session.isNotificationEnabled) Color(0xFF3B82F6) else Color(0xFF64748B),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Edit Section
                                        IconButton(
                                            onClick = {
                                                sessionToEdit = session
                                                showAddDialog = true
                                            },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "Edit section",
                                                tint = Color(0xFF60A5FA),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Delete Section
                                        IconButton(
                                            onClick = { sessionToDelete = session },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete section",
                                                tint = Color(0xFFFF453A),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }

                                if (index < filteredSessions.lastIndex) {
                                    HorizontalDivider(color = Color(0xFF1E293B), thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }

                // Subject Rotation Guide Card from Screenshot
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xB810172A)),
                        border = BorderStroke(1.dp, Color(0x3360A5FA))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "🧠",
                                    fontSize = 20.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Subject Rotation Strategy",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            Text(
                                text = "Don't try to give every subject equal time every single day. Use this high-yield pattern:",
                                fontSize = 13.sp,
                                color = Color(0xFFCBD5E1)
                            )

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x660F172A))
                                    .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "• Mon / Wed / Fri: Math heavy (speed problem practice) + Physics concepts",
                                    fontSize = 12.sp,
                                    color = Color(0xFF93C5FD),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "• Tue / Thu / Sat: Physics numericals + Chemistry (Organic/Inorganic memorization)",
                                    fontSize = 12.sp,
                                    color = Color(0xFF6EE7B7),
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "• Sunday: Full 3-Hour Mock CBT Test (9:00 AM - 12:00 PM) + In-depth Test Analysis",
                                    fontSize = 12.sp,
                                    color = Color(0xFFFDE047),
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Text(
                                text = "💡 Non-screen wind-down (10:15 PM) & 7hr 15m deep sleep (10:30 PM - 5:45 AM) are crucial for neural memory consolidation.",
                                fontSize = 12.sp,
                                fontStyle = FontStyle.Italic,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            } else {
                // Detailed Cards View
                items(filteredSessions, key = { it.id }) { session ->
                    val secRecord = studySummary.sections.firstOrNull { it.sectionId == session.id }
                    RoutineCard(
                        session = session,
                        secRecord = secRecord,
                        onToggleNotification = { viewModel.toggleRoutineNotification(session) },
                        onEdit = {
                            sessionToEdit = session
                            showAddDialog = true
                        },
                        onDelete = { sessionToDelete = session }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        SessionDialog(
            initialSession = sessionToEdit,
            onDismiss = { showAddDialog = false },
            onSave = { session ->
                viewModel.saveRoutineSession(session)
                showAddDialog = false
            },
            onDelete = if (sessionToEdit != null) {
                {
                    val toDelete = sessionToEdit
                    showAddDialog = false
                    if (toDelete != null) {
                        sessionToDelete = toDelete
                    }
                }
            } else null
        )
    }

    // Confirmation Dialog for Deleting Section
    if (sessionToDelete != null) {
        val target = sessionToDelete!!
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            containerColor = Color(0xFF1C1C1E),
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = Color(0xFFFF453A),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Delete Timetable Section?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove \"${target.title}\" (${target.getFormattedTime()}) from your JEE timetable? This action cannot be undone.",
                    color = Color(0xFFD1D5DB),
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRoutineSession(target)
                        sessionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF453A))
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDelete = null }) {
                    Text("Cancel", color = Color(0xFF9CA3AF))
                }
            }
        )
    }

    // Confirmation Dialog for Restoring Default JEE Routine
    if (showResetDefaultConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetDefaultConfirmDialog = false },
            containerColor = Color(0xFF1C1C1E),
            icon = {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    tint = Color(0xFF0A84FF),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Restore Default Timetable?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "This will restore the standard full-day JEE timetable (Physics, Chemistry, Maths slots, meals, breaks, revision, and sleep) and overwrite any custom timetable edits.",
                    color = Color(0xFFD1D5DB),
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetDefaultRoutine()
                        showResetDefaultConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A84FF))
                ) {
                    Text("Restore Default", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDefaultConfirmDialog = false }) {
                    Text("Cancel", color = Color(0xFF9CA3AF))
                }
            }
        )
    }

    if (showBgDialog) {
        com.example.ui.components.BackgroundEditDialog(
            currentType = bgType,
            currentPreset = bgPreset,
            currentUri = customBgUri,
            blurIntensity = blurIntensity,
            dimOpacity = bgDimOpacity,
            onSelectPreset = { viewModel.setBackgroundPreset(it) },
            onSelectCustomUri = { viewModel.setCustomBackgroundUri(it) },
            onChangeBlur = { viewModel.setBlurIntensity(it) },
            onChangeDim = { viewModel.setBgDimOpacity(it) },
            onResetDefault = { viewModel.resetBackgroundToDefault() },
            onDismiss = { showBgDialog = false }
        )
    }
}

@Composable
fun RoutineCard(
    session: RoutineSession,
    secRecord: com.example.service.SectionStudyRecord? = null,
    onToggleNotification: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("routine_card_${session.id}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xB80D1526)),
        border = BorderStroke(1.dp, Color(0x3360A5FA))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Row: Category Pill, Time Slot, Notification Bell, Edit, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Category Pill
                CategoryPill(category = session.category)

                // Time Slot Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1A2640))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${session.startTime}  –  ${session.endTime}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Action Icons (Bell, Edit, Delete)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bell icon
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                if (session.isNotificationEnabled) Color(0xFF2563EB) else Color(0xFF1E293B)
                            )
                            .clickable { onToggleNotification() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (session.isNotificationEnabled) Icons.Outlined.Notifications else Icons.Outlined.NotificationsOff,
                            contentDescription = "Notification",
                            tint = if (session.isNotificationEnabled) Color.White else Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Edit
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .clickable { onEdit() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Delete
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .clickable { onDelete() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Title with Emoji
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = session.emoji,
                    fontSize = 18.sp
                )
                Text(
                    text = session.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Focus Topic Box (if present)
            if (!session.focusTopic.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0F172A))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = "Focus Topic: ",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                        Text(
                            text = session.focusTopic,
                            fontSize = 13.sp,
                            color = Color(0xFFE2E8F0)
                        )
                    }
                }
            }

            // Description in quotes / italics
            if (session.description.isNotBlank()) {
                Text(
                    text = "\"${session.description}\"",
                    fontSize = 13.sp,
                    fontStyle = FontStyle.Italic,
                    color = Color(0xFF94A3B8),
                    lineHeight = 18.sp
                )
            }

            // Live Study & Distraction Tracking Badge
            if (secRecord != null && (secRecord.totalStudySeconds > 0 || secRecord.distractionSeconds > 0)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F1D33))
                        .border(BorderStroke(1.dp, Color(0x3338BDF8)), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚡ Counted Study Time",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399)
                            )
                            Text(
                                text = secRecord.getFormattedStudyTime(),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "⏱️ Timer: ${secRecord.getFormattedTimerTime()} • 📱 App: ${secRecord.getFormattedAppOpenTime()}",
                                fontSize = 10.sp,
                                color = Color(0xFF93C5FD)
                            )
                            if (secRecord.distractionSeconds > 0) {
                                Text(
                                    text = "🛑 ${secRecord.getFormattedDistractionTime()} distract",
                                    fontSize = 10.sp,
                                    color = Color(0xFFFCA5A5),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Row: Days pills & Alert time
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Days row: S M T W T F S
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Days: ",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )

                    val allWeekLetters = listOf("S", "M", "T", "W", "T", "F", "S")
                    allWeekLetters.forEach { letter ->
                        val isActive = session.days.contains(letter)
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isActive) Color(0xFF1E3A8A) else Color(0xFF1E293B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = letter,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isActive) Color(0xFF93C5FD) else Color(0xFF64748B)
                            )
                        }
                    }
                }

                // Alert timing (e.g. 🔔 10m before)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "🔔 ${session.alertMinutesBefore}m before",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFFBBF24)
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryPill(category: String) {
    val (bgColor, textColor) = when (category.lowercase()) {
        "physics" -> Pair(Color(0xFFDBEAFE), Color(0xFF1E40AF))
        "chemistry" -> Pair(Color(0xFFDCFCE7), Color(0xFF166534))
        "mathematics" -> Pair(Color(0xFFFEF08A), Color(0xFF854D0E))
        "walking/relaxation" -> Pair(Color(0xFFE2F8C7), Color(0xFF3F6212))
        "breaks" -> Pair(Color(0xFFCCFBF1), Color(0xFF115E59))
        "coaching/classes" -> Pair(Color(0xFFF3E8FF), Color(0xFF6B21A8))
        "revision" -> Pair(Color(0xFFFFE4E6), Color(0xFF9F1239))
        "sleep" -> Pair(Color(0xFFEDE9FE), Color(0xFF5B21B6))
        "dinner" -> Pair(Color(0xFFFEF3C7), Color(0xFF92400E))
        else -> Pair(Color(0xFFE2E8F0), Color(0xFF334155))
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = category,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun SessionDialog(
    initialSession: RoutineSession?,
    onDismiss: () -> Unit,
    onSave: (RoutineSession) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var title by remember { mutableStateOf(initialSession?.title ?: "") }
    var emoji by remember { mutableStateOf(initialSession?.emoji ?: "⚡") }
    var category by remember { mutableStateOf(initialSession?.category ?: "Physics") }
    var startTime by remember { mutableStateOf(initialSession?.startTime ?: "14:00") }
    var endTime by remember { mutableStateOf(initialSession?.endTime ?: "15:30") }
    var focusTopic by remember { mutableStateOf(initialSession?.focusTopic ?: "") }
    var description by remember { mutableStateOf(initialSession?.description ?: "") }
    var alertMinutes by remember { mutableStateOf(initialSession?.alertMinutesBefore ?: 10) }
    var isNotificationEnabled by remember { mutableStateOf(initialSession?.isNotificationEnabled ?: true) }
    var activeDays by remember {
        mutableStateOf(
            if (initialSession != null) initialSession.days.split(",").map { it.trim() }.toSet()
            else setOf("S", "M", "T", "W", "T", "F", "S")
        )
    }

    val presetCategories = listOf(
        Triple("Physics", "⚛️", Color(0xFF1E3A8A)),
        Triple("Chemistry", "🧪", Color(0xFF14532D)),
        Triple("Mathematics", "📐", Color(0xFF713F12)),
        Triple("Revision", "📖", Color(0xFF881337)),
        Triple("Breaks", "☕", Color(0xFF134E4A)),
        Triple("Walking/relaxation", "🚶", Color(0xFF365314)),
        Triple("Coaching/classes", "🏛️", Color(0xFF581C87)),
        Triple("Dinner", "🍱", Color(0xFF78350F)),
        Triple("Sleep", "😴", Color(0xFF3B0764)),
        Triple("Mock Test", "🎯", Color(0xFF7F1D1D))
    )

    val quickEmojis = listOf("⚛️", "🧪", "📐", "📖", "☕", "🚶", "🍱", "😴", "🎯", "⚡", "📝", "💡", "🚿", "🌅", "🌙", "📚", "🧠")
    val allWeekLetters = listOf("S", "M", "T", "W", "T", "F", "S")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (initialSession == null) "Add Routine Section" else "Edit Section",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                if (initialSession != null && onDelete != null) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Section",
                            tint = Color(0xFFFF453A),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        },
        containerColor = Color(0xFF1C1C1E),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Category Selector Chips
                Text(
                    text = "Category",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF94A3B8)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetCategories.forEach { (catName, catEmoji, catColor) ->
                        val isSelected = category.equals(catName, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF0A84FF) else Color(0xFF2C2C2E))
                                .clickable {
                                    category = catName
                                    if (emoji.isBlank() || emoji == "⚡") {
                                        emoji = catEmoji
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "$catEmoji $catName",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Color(0xFFD1D5DB)
                            )
                        }
                    }
                }

                // Section Title & Emoji Picker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = emoji,
                        onValueChange = { emoji = it },
                        label = { Text("Icon") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF0A84FF)
                        ),
                        modifier = Modifier.width(68.dp)
                    )

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Section Title *") },
                        singleLine = true,
                        placeholder = { Text("e.g. Physics Numericals", color = Color(0xFF6B7280)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF0A84FF)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Quick Emoji Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickEmojis.forEach { em ->
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (emoji == em) Color(0xFF0A84FF) else Color(0xFF2C2C2E))
                                .clickable { emoji = em },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = em, fontSize = 15.sp)
                        }
                    }
                }

                // Start & End Time Fields
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("Start (HH:mm)") },
                        singleLine = true,
                        placeholder = { Text("06:00", color = Color(0xFF6B7280)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF0A84FF)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("End (HH:mm)") },
                        singleLine = true,
                        placeholder = { Text("08:00", color = Color(0xFF6B7280)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF0A84FF)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Repeating Days Selector
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Repeat on Days",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF94A3B8)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val dayNames = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                        allWeekLetters.forEachIndexed { i, letter ->
                            val isDayActive = activeDays.contains(letter)
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isDayActive) Color(0xFF0A84FF) else Color(0xFF2C2C2E))
                                    .clickable {
                                        activeDays = if (isDayActive) {
                                            activeDays - letter
                                        } else {
                                            activeDays + letter
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = letter,
                                    color = if (isDayActive) Color.White else Color(0xFF8E8E93),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                // Focus Topic
                OutlinedTextField(
                    value = focusTopic,
                    onValueChange = { focusTopic = it },
                    label = { Text("Focus Topic (Optional)") },
                    placeholder = { Text("e.g. Mechanics / Organic Reactions", color = Color(0xFF6B7280)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF0A84FF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Description / Notes
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notes / Target (Optional)") },
                    placeholder = { Text("e.g. Solve 30 PYQs from 2023-2025", color = Color(0xFF6B7280)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF0A84FF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Reminder Alert Timing
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Start Reminder Alert",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF94A3B8)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            0 to "At Start",
                            5 to "5m before",
                            10 to "10m before",
                            15 to "15m before"
                        ).forEach { (minutes, label) ->
                            val isSelected = alertMinutes == minutes
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0xFFFF9F0A) else Color(0xFF2C2C2E))
                                    .clickable { alertMinutes = minutes }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.Black else Color.White
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (initialSession != null && onDelete != null) {
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFFF453A))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete", fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = {
                        val session = RoutineSession(
                            id = initialSession?.id ?: 0L,
                            category = category,
                            startTime = startTime.ifBlank { "06:00" },
                            endTime = endTime.ifBlank { "07:00" },
                            title = title.ifBlank { "Study Session" },
                            emoji = emoji.ifBlank { "⚡" },
                            focusTopic = focusTopic.ifBlank { null },
                            description = description,
                            days = if (activeDays.isEmpty()) "S,M,T,W,T,F,S" else activeDays.joinToString(","),
                            alertMinutesBefore = alertMinutes,
                            isNotificationEnabled = isNotificationEnabled,
                            displayTime = if (startTime == endTime) startTime else "$startTime–$endTime",
                            orderIndex = initialSession?.orderIndex ?: 0
                        )
                        onSave(session)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A84FF))
                ) {
                    Text("Save Section", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}
