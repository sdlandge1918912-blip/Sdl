package com.example.util

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.model.AlarmItem
import com.example.data.model.RoutineSession
import com.example.receiver.SectionAlarmReceiver
import com.example.receiver.UserAlarmReceiver
import java.util.Calendar

object JeeNotificationHelper {

    const val CHANNEL_SECTIONS = "jee_sections_channel"
    const val CHANNEL_ALARMS = "jee_alarms_channel"
    const val CHANNEL_TIMER = "jee_timer_channel"

    private const val NOTIF_ID_SECTION = 1001
    private const val NOTIF_ID_ALARM = 2001
    private const val NOTIF_ID_TIMER = 3001

    fun initChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val defaultSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: defaultSound

            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            val alarmAudioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            // 1. Routine Sections Channel
            val sectionChannel = NotificationChannel(
                CHANNEL_SECTIONS,
                "JEE Routine Timetable Sections",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when each JEE study and routine section begins"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(defaultSound, audioAttributes)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }

            // 2. Clock Alarms Channel
            val alarmsChannel = NotificationChannel(
                CHANNEL_ALARMS,
                "JEE Study Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High priority alarms for study routine wake up and slots"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 300, 500, 300, 500)
                setSound(alarmSound, alarmAudioAttributes)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }

            // 3. Focus Timer Channel
            val timerChannel = NotificationChannel(
                CHANNEL_TIMER,
                "Study Timers & Stopwatch",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when study sprints and timers complete"
                enableVibration(true)
                setSound(defaultSound, audioAttributes)
            }

            notificationManager.createNotificationChannel(sectionChannel)
            notificationManager.createNotificationChannel(alarmsChannel)
            notificationManager.createNotificationChannel(timerChannel)
        }
    }

    fun sendSectionStartNotification(
        context: Context,
        title: String,
        category: String,
        timeSpan: String,
        emoji: String = "🔔"
    ) {
        initChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_SECTIONS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("$emoji Starting Now: $title")
            .setContentText("$timeSpan • $category slot has begun!")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("🎯 $timeSpan: $title\n$category slot has started. Open your books, put your phone in Study Focus mode, and give your full attention!")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifId = (System.currentTimeMillis() % 10000).toInt() + NOTIF_ID_SECTION
        notificationManager.notify(notifId, notification)
    }

    fun sendAlarmNotification(
        context: Context,
        alarmId: String,
        label: String,
        timeFormatted: String
    ) {
        initChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            alarmId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ALARMS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ Alarm: $label")
            .setContentText("Time is $timeFormatted — Wake up & start your JEE study session!")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("⏰ $timeFormatted — $label\nConsistency is the key to 99+ Percentile. Rise up and conquer today's target!")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 500, 300, 500, 300, 500))
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIF_ID_ALARM, notification)
    }

    fun sendTimerFinishedNotification(context: Context, label: String) {
        initChannels(context)

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_TIMER)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⏱️ Study Timer Completed!")
            .setContentText("Great job on finishing your '$label' sprint.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIF_ID_TIMER, notification)
    }

    fun scheduleSectionAlarms(context: Context, sessions: List<RoutineSession>) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = Calendar.getInstance()

        sessions.forEachIndexed { index, session ->
            if (!session.isNotificationEnabled) return@forEachIndexed

            val parts = session.startTime.split(":")
            if (parts.size >= 2) {
                val hour = parts[0].trim().toIntOrNull() ?: return@forEachIndexed
                val minute = parts[1].trim().toIntOrNull() ?: return@forEachIndexed

                val target = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }

                // If time already passed today, schedule for tomorrow
                if (target.before(now)) {
                    target.add(Calendar.DAY_OF_YEAR, 1)
                }

                val intent = Intent(context, SectionAlarmReceiver::class.java).apply {
                    putExtra("title", session.title)
                    putExtra("category", session.category)
                    putExtra("timeSpan", session.getFormattedTime())
                    putExtra("emoji", session.emoji)
                    putExtra("sessionId", session.id)
                    putExtra("startTime", session.startTime)
                }

                val requestCode = if (session.id > 0) (1000 + session.id).toInt() else (1000 + index)
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                )

                try {
                    val showIntent = Intent(context, MainActivity::class.java)
                    val showPendingIntent = PendingIntent.getActivity(
                        context,
                        requestCode,
                        showIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                    )
                    alarmManager.setAlarmClock(
                        AlarmManager.AlarmClockInfo(target.timeInMillis, showPendingIntent),
                        pendingIntent
                    )
                } catch (e: Exception) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            alarmManager.setExactAndAllowWhileIdle(
                                AlarmManager.RTC_WAKEUP,
                                target.timeInMillis,
                                pendingIntent
                            )
                        } else {
                            alarmManager.setExact(
                                AlarmManager.RTC_WAKEUP,
                                target.timeInMillis,
                                pendingIntent
                            )
                        }
                    } catch (e2: Exception) {
                        alarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            target.timeInMillis,
                            pendingIntent
                        )
                    }
                }
            }
        }
    }

    fun scheduleUserAlarm(context: Context, alarm: AlarmItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = Calendar.getInstance()

        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (target.before(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }

        val intent = Intent(context, UserAlarmReceiver::class.java).apply {
            putExtra("alarmId", alarm.id)
            putExtra("label", alarm.label)
            putExtra("timeFormatted", "${alarm.getFormattedTime()} ${alarm.getAmPm()}")
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                target.timeInMillis,
                pendingIntent
            )
        }
    }

    fun cancelUserAlarm(context: Context, alarmId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, UserAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmId.hashCode(),
            intent,
            PendingIntent.FLAG_NO_CREATE or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }

    /**
     * Schedules the daily 12:00 AM (midnight) exact alarm to trigger the app usage calculation,
     * historical archiving, and fresh new-day cycle setup.
     */
    fun scheduleMidnightRollover(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = Calendar.getInstance()

        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (!target.after(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }

        val intent = Intent(context, com.example.receiver.MidnightResetReceiver::class.java).apply {
            action = com.example.receiver.MidnightResetReceiver.ACTION_MIDNIGHT_RESET
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            1200,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            }
        } catch (_: Exception) {
            try {
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    target.timeInMillis,
                    pendingIntent
                )
            } catch (_: Exception) {}
        }
    }

    fun cancelMidnightRollover(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, com.example.receiver.MidnightResetReceiver::class.java).apply {
            action = com.example.receiver.MidnightResetReceiver.ACTION_MIDNIGHT_RESET
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            1200,
            intent,
            PendingIntent.FLAG_NO_CREATE or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }
}
