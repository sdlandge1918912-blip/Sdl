package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BlockedApp
import com.example.service.FocusShieldManager
import android.widget.Toast
import com.example.ui.components.IosSwitch
import com.example.ui.viewmodel.JeeViewModel

@Composable
fun FocusAppBlockerScreen(
    viewModel: JeeViewModel,
    onNavigateToRoutine: () -> Unit,
    onNavigateToPractice: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    BackHandler {
        onClose()
    }

    // Refresh permissions whenever the user returns from system settings
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshShieldState()
    }

    val isFocusActive by viewModel.isFocusShieldActive.collectAsStateWithLifecycle()
    val isAutoSync by viewModel.isAutoTimetableSync.collectAsStateWithLifecycle()
    val isManualActive by viewModel.isManualSessionActive.collectAsStateWithLifecycle()
    val manualRemainingSec by viewModel.manualSessionRemainingSeconds.collectAsStateWithLifecycle()
    val manualLabel by viewModel.manualSessionLabel.collectAsStateWithLifecycle()
    val hasUsagePerm by viewModel.hasUsagePermission.collectAsStateWithLifecycle()
    val hasOverlayPerm by viewModel.hasOverlayPermission.collectAsStateWithLifecycle()
    val hasBatteryExemption by viewModel.hasBatteryExemption.collectAsStateWithLifecycle()
    val isStrictEnforcedNow by viewModel.isStrictEnforcedNow.collectAsStateWithLifecycle()
    val isOngoingStudySlot by viewModel.isOngoingStudySlot.collectAsStateWithLifecycle()
    val isOngoingBreakSlot by viewModel.isOngoingBreakSlot.collectAsStateWithLifecycle()
    val activeSession by viewModel.activeRoutineSession.collectAsStateWithLifecycle()

    val blockedApps by viewModel.blockedApps.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedUserApps.collectAsStateWithLifecycle()
    val studySummary by viewModel.displayedStudySummary.collectAsStateWithLifecycle()
    val selectedUsageDate by viewModel.selectedScreenTimeDate.collectAsStateWithLifecycle()
    val archiveDates by viewModel.availableArchiveDates.collectAsStateWithLifecycle()
    val showDistractionOverlay by viewModel.showDistractionShieldOverlay.collectAsStateWithLifecycle()
    val blockedAppToPreview by viewModel.blockedAppToPreview.collectAsStateWithLifecycle()

    var showAddCustomDialog by remember { mutableStateOf(false) }
    var addDialogIsStudyApp by remember { mutableStateOf(true) }
    var showPlayProtectInfo by remember { mutableStateOf(false) }
    var showBackgroundGuideDialog by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Guarded, 1: Study Apps, 2: Screen Time, 3: Installed
    var appSearchQuery by remember { mutableStateOf("") }

    val guardedApps = remember(blockedApps) { blockedApps.filter { !it.isStudyApp } }
    val studyApps = remember(blockedApps) { blockedApps.filter { it.isStudyApp } }
    val blockedCount = remember(guardedApps) { guardedApps.count { it.isBlocked } }

    val filteredInstalled = remember(installedApps, appSearchQuery) {
        if (appSearchQuery.isBlank()) installedApps
        else installedApps.filter {
            it.name.contains(appSearchQuery, ignoreCase = true) ||
                    it.packageName.contains(appSearchQuery, ignoreCase = true)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.loadInstalledUserApps()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("focus_app_blocker_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x33475569))
                        .testTag("blocker_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Strict Study Mode",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Distraction App Blocker & Focus Guard",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            IconButton(
                onClick = { showAddCustomDialog = true },
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B))
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Custom App",
                    tint = Color(0xFF60A5FA),
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Timetable Automatic Strict Mode Status Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isOngoingStudySlot -> Color(0xFF063E26)
                            isOngoingBreakSlot -> Color(0xFF0F2640)
                            else -> Color(0xFF131D2E)
                        }
                    ),
                    border = BorderStroke(
                        1.5.dp,
                        when {
                            isOngoingStudySlot -> Color(0xFF10B981)
                            isOngoingBreakSlot -> Color(0xFF38BDF8)
                            else -> Color(0xFF3B82F6)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isOngoingStudySlot -> Color(0xFF10B981)
                                        isOngoingBreakSlot -> Color(0xFF0284C7)
                                        else -> Color(0xFF2563EB)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when {
                                    isOngoingStudySlot -> "🛡️"
                                    isOngoingBreakSlot -> "☕"
                                    else -> "⏳"
                                },
                                fontSize = 22.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = when {
                                        isOngoingStudySlot -> "STUDY SLOT • STRICT ON"
                                        isOngoingBreakSlot -> "BREAK TIME • STRICT OFF"
                                        else -> "UPCOMING SESSION"
                                    },
                                    color = when {
                                        isOngoingStudySlot -> Color(0xFF6EE7B7)
                                        isOngoingBreakSlot -> Color(0xFF7DD3FC)
                                        else -> Color(0xFF93C5FD)
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            when {
                                                isOngoingStudySlot -> Color(0xFF10B981)
                                                isOngoingBreakSlot -> Color(0xFF38BDF8)
                                                else -> Color(0xFF3B82F6)
                                            }
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isOngoingStudySlot) "AUTO LOCKED" else if (isOngoingBreakSlot) "UNLOCKED" else "SCHEDULED",
                                        color = Color.Black,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = activeSession?.title ?: "JEE Routine",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = when {
                                    isOngoingStudySlot -> "Distractions blocked until break (${activeSession?.endTime ?: ""})"
                                    isOngoingBreakSlot -> "Enjoy your break! Distractions allowed until ${activeSession?.endTime ?: ""}"
                                    else -> "Strict mode engages automatically when study slot starts"
                                },
                                color = Color(0xFFCBD5E1),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Master Focus Shield Switch Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isFocusActive) Color(0xFF0F291E) else Color(0xFF131D2E)
                    ),
                    border = BorderStroke(
                        1.5.dp,
                        if (isFocusActive) Color(0xFF10B981) else Color(0xFF1E293B)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (isFocusActive) Color(0xFF10B981) else Color(0xFF334155)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = if (isFocusActive) Color.Black else Color(0xFF94A3B8),
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = "Strict Study Shield",
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isFocusActive) "ACTIVE • Distractions Guarded" else "INACTIVE • Tap to Activate",
                                        color = if (isFocusActive) Color(0xFF34D399) else Color(0xFF94A3B8),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            IosSwitch(
                                checked = isFocusActive,
                                onCheckedChange = { active ->
                                    viewModel.toggleFocusShield(active)
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(
                            color = if (isFocusActive) Color(0xFF134E35) else Color(0xFF1E293B),
                            thickness = 1.dp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🛡️ $blockedCount Apps Guarded in Study Slots",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )

                            // Preview Lockout Screen button
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isFocusActive) Color(0xFF10B981) else Color(0xFF2563EB))
                                    .clickable {
                                        val target = blockedApps.firstOrNull { it.isBlocked } ?: blockedApps.first()
                                        viewModel.triggerDistractionShieldSimulation(target)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Preview Lock Screen",
                                    color = if (isFocusActive) Color.Black else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Permissions Alert Card (When permissions are missing)
            if (!hasUsagePerm || !hasOverlayPerm) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2A150A)),
                        border = BorderStroke(1.dp, Color(0xFFF97316))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color(0xFFF97316),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Permissions Required for App Blocker",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = "Android requires Usage Access to detect when distraction apps open, and Display Over Other Apps to show the focus screen.",
                                color = Color(0xFFFED7AA),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (!hasUsagePerm) {
                                    Button(
                                        onClick = { FocusShieldManager.openUsageAccessSettings(context) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("1. Usage Access", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                if (!hasOverlayPerm) {
                                    Button(
                                        onClick = { FocusShieldManager.openOverlaySettings(context) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("2. Overlay Access", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 24/7 Background App Activation & Autostart Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (hasBatteryExemption) Color(0xFF062D20) else Color(0xFF261806)
                    ),
                    border = BorderStroke(
                        1.2.dp,
                        if (hasBatteryExemption) Color(0xFF10B981) else Color(0xFFF59E0B)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(15.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (hasBatteryExemption) Color(0xFF10B981) else Color(0xFFF59E0B)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (hasBatteryExemption) Icons.Default.CheckCircle else Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Background App Activation",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (hasBatteryExemption) "Unrestricted (Active 24/7)" else "Restricted by Battery Saver",
                                        color = if (hasBatteryExemption) Color(0xFF6EE7B7) else Color(0xFFFDE68A),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (hasBatteryExemption) Color(0xFF10B981) else Color(0xFFF59E0B)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = if (hasBatteryExemption) "ACTIVE 24/7" else "ACTION NEEDED",
                                    color = Color.Black,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        Text(
                            text = if (hasBatteryExemption) {
                                "✅ Strict Study Mode and Section Alarms run reliably even when JEE Reminder is closed or swiped away. No battery killer will stop your study routine."
                            } else {
                                "⚠️ Android may put the app to sleep when closed. Allow Background Activation so alarms ring on time and distraction apps remain blocked when the app isn't open."
                            },
                            color = if (hasBatteryExemption) Color(0xFFA7F3D0) else Color(0xFFFED7AA),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!hasBatteryExemption) {
                                Button(
                                    onClick = { FocusShieldManager.requestIgnoreBatteryOptimizations(context) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "1-Tap: Allow Background Run",
                                        color = Color.Black,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = { showBackgroundGuideDialog = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF60A5FA)),
                                border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = if (!hasBatteryExemption) Modifier.weight(0.9f) else Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    tint = Color(0xFF60A5FA),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Autostart & OEM Guide",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Google Play Protect & Open Source Security Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showPlayProtectInfo = true },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E33)),
                    border = BorderStroke(1.dp, Color(0xFF1E3A8A))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1D4ED8)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Google Play Protect Certified",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "OPEN SOURCE",
                                        color = Color(0xFF60A5FA),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "100% compliant with standard Android Digital Wellbeing APIs. Tap to read details.",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Info",
                            tint = Color(0xFF60A5FA),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Auto Timetable Study Slot Sync Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E)),
                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2563EB)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EventRepeat,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Auto-Lock in Study Slots",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Guards Physics, Chemistry & Maths sessions. Automatically relaxes during meals & sleep.",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            IosSwitch(
                                checked = isAutoSync,
                                onCheckedChange = { viewModel.toggleAutoTimetableSync(it) }
                            )
                        }
                    }
                }
            }

            // Quick Manual Focus Timer Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E)),
                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Start Quick Strict Focus Session",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (isManualActive) {
                                TextButton(onClick = { viewModel.stopManualFocusSession() }) {
                                    Text("Stop", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        if (isManualActive) {
                            val mins = manualRemainingSec / 60
                            val secs = manualRemainingSec % 60
                            val timeStr = String.format("%02d:%02d", mins, secs)

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF0F291E))
                                    .border(BorderStroke(1.dp, Color(0xFF10B981)), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = Color(0xFF34D399),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "$manualLabel: $timeStr remaining",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = "Choose a duration to immediately lock distracting apps:",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(25 to "Pomodoro", 45 to "45 Min", 60 to "1 Hour", 90 to "90 Min").forEach { (duration, label) ->
                                    Button(
                                        onClick = { viewModel.startManualFocusSession(duration, label) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                    ) {
                                        Text(text = label, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Distracting Apps Section Header with Tab Selection
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STRICT MODE & APP USAGE",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Quick Add Study App shortcut
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0x3310B981))
                                    .border(BorderStroke(1.dp, Color(0x6610B981)), RoundedCornerShape(8.dp))
                                    .clickable {
                                        addDialogIsStudyApp = true
                                        showAddCustomDialog = true
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "+ Study App 📚",
                                    color = Color(0xFF34D399),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Custom App
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0x3338BDF8))
                                    .border(BorderStroke(1.dp, Color(0x6638BDF8)), RoundedCornerShape(8.dp))
                                    .clickable {
                                        addDialogIsStudyApp = false
                                        showAddCustomDialog = true
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "+ Block App 🛑",
                                    color = Color(0xFF38BDF8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // 4-Segmented Button Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF131D2E))
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        // 0: Guarded (Blocked)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (selectedTab == 0) Color(0xFF2563EB) else Color.Transparent)
                                .clickable { selectedTab = 0 }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Guarded (${guardedApps.size})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 0) Color.White else Color(0xFF94A3B8)
                            )
                        }

                        // 1: Study Apps (Whitelisted)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (selectedTab == 1) Color(0xFF059669) else Color.Transparent)
                                .clickable { selectedTab = 1 }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Study (${studyApps.size}) 📚",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 1) Color.White else Color(0xFF34D399)
                            )
                        }

                        // 2: Screen Time (App Usage)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (selectedTab == 2) Color(0xFFE11D48) else Color.Transparent)
                                .clickable { selectedTab = 2 }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Usage 📊",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 2) Color.White else Color(0xFFFDA4AF)
                            )
                        }

                        // 3: Installed Apps
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (selectedTab == 3) Color(0xFF3B82F6) else Color.Transparent)
                                .clickable {
                                    selectedTab = 3
                                    viewModel.loadInstalledUserApps()
                                }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Installed 📱",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedTab == 3) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }

                    if (selectedTab == 3) {
                        OutlinedTextField(
                            value = appSearchQuery,
                            onValueChange = { appSearchQuery = it },
                            placeholder = { Text("Search installed device apps...", fontSize = 12.sp, color = Color(0xFF64748B)) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF1E293B)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        )
                    }

                    if (selectedTab == 2) {
                        val todayDateStr = remember { com.example.service.StudyTimeTracker.getTodayDateString() }
                        val isTodaySelected = (selectedUsageDate == todayDateStr)

                        // 12:00 AM Daily Usage Cycle Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF161224)),
                            border = BorderStroke(1.dp, Color(0x33A855F7))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                // Cycle Title & Rollover Tag
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("⏱️", fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "12:00 AM DAILY USAGE CYCLE",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFC084FC),
                                                letterSpacing = 0.5.sp
                                            )
                                            Text(
                                                text = if (isTodaySelected) "Tracking usage from 12:00:00 AM today" else "Archived full 24-hr cycle ($selectedUsageDate)",
                                                fontSize = 10.sp,
                                                color = Color(0xFF94A3B8)
                                            )
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0x3338BDF8))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (isTodaySelected) "● ACTIVE 12 AM" else "ARCHIVED",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isTodaySelected) Color(0xFF38BDF8) else Color(0xFFE2E8F0)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Date Selector Chips
                                val calendarYesterday = remember {
                                    java.util.Calendar.getInstance().apply { add(java.util.Calendar.DATE, -1) }
                                }
                                val yesterdayStr = remember(calendarYesterday) {
                                    java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(calendarYesterday.time)
                                }

                                val chipDates = remember(archiveDates, todayDateStr, yesterdayStr) {
                                    val set = linkedSetOf(todayDateStr, yesterdayStr)
                                    set.addAll(archiveDates)
                                    set.toList().take(5)
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    for (d in chipDates) {
                                        val isSel = (d == selectedUsageDate)
                                        val label = when (d) {
                                            todayDateStr -> "Today (12 AM)"
                                            yesterdayStr -> "Yesterday (24h)"
                                            else -> d.substringAfter("-") // MM-dd
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(20.dp))
                                                .background(if (isSel) Color(0xFF8B5CF6) else Color(0xFF1E293B))
                                                .clickable { viewModel.selectScreenTimeDate(d) }
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                                .testTag("date_chip_$d")
                                        ) {
                                            Text(
                                                text = label,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                                color = if (isSel) Color.White else Color(0xFFCBD5E1)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Window and Metrics Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "🕒 Window: ${studySummary.getFormattedWindow()}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFE2E8F0)
                                        )
                                        Text(
                                            text = "📚 Study: ${studySummary.getFormattedTotalStudy()} • 🛑 Distraction: ${studySummary.getFormattedDistraction()}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF34D399)
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        // Recalculate Button
                                        Button(
                                            onClick = {
                                                viewModel.refresh12AmUsageStats()
                                                Toast.makeText(context, "Calculated app usage starting from 12:00 AM today!", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("recalculate_12am_button")
                                        ) {
                                            Text("🔄 12 AM Sync", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                                        }

                                        // Pin Widget Button
                                        Button(
                                            onClick = {
                                                val pinned = viewModel.requestPinAppScreenTimeWidget(context)
                                                if (pinned) {
                                                    Toast.makeText(context, "Adding Screen Time Widget to Home Screen", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "Long-press Home screen to add App Screen Time Widget", Toast.LENGTH_LONG).show()
                                                }
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("pin_screen_time_widget_button")
                                        ) {
                                            Text("📌 Pin", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // TAB 0: GUARDED / BLOCKED APPS
            // -------------------------------------------------------------
            if (selectedTab == 0) {
                if (guardedApps.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0x80131D2E))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🛡️ No Distraction Apps Guarded", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Tap '+ Block App 🛑' or browse the 'Installed 📱' tab to add social media and games you want locked out during study hours.",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 12.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    items(guardedApps, key = { it.id }) { app ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E)),
                            border = BorderStroke(1.dp, Color(0xFF1E293B))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(text = app.iconEmoji, fontSize = 24.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = app.name,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (app.isBlocked) "Locked in Study Slots" else "Temporarily Allowed",
                                                color = if (app.isBlocked) Color(0xFFF97316) else Color(0xFF94A3B8),
                                                fontSize = 11.sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "• Set as Study 📚",
                                                color = Color(0xFF34D399),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.clickable {
                                                    viewModel.toggleAppType(app.id)
                                                    Toast.makeText(context, "${app.name} marked as Study App! 📚", Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        }
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IosSwitch(
                                        checked = app.isBlocked,
                                        onCheckedChange = { viewModel.toggleAppBlocked(app.id) }
                                    )

                                    Spacer(modifier = Modifier.width(4.dp))

                                    IconButton(
                                        onClick = { viewModel.deleteBlockedApp(app.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Remove App",
                                            tint = Color(0xFF64748B),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // TAB 1: STUDY APPS (WHITELISTED IN STRICT MODE & TRACKED IN APP USAGE)
            // -------------------------------------------------------------
            if (selectedTab == 1) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0x33059669)),
                        border = BorderStroke(1.dp, Color(0x6610B981))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("📚", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Whitelisted Study Apps",
                                        color = Color(0xFF34D399),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Allowed in Strict Mode • Tracked as Study Time in App Usage",
                                        color = Color(0xFF93C5FD),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "These apps are NEVER blocked during Strict Mode timetable slots. Every minute you spend in them is automatically tracked and counted towards your daily JEE study hours!",
                                color = Color(0xFFCBD5E1),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                if (studyApps.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("No Study Apps Added Yet", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Tap any quick preset below to add your JEE learning apps:",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.addStudyApp("Physics Wallah", "xyz.penpencil.physicswala", "Study & Prep", "⚡")
                                            Toast.makeText(context, "Added Physics Wallah to Study Apps!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("⚡ Physics Wallah", fontSize = 10.sp, maxLines = 1)
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.addStudyApp("Unacademy", "com.unacademyapp", "Study & Prep", "🎓")
                                            Toast.makeText(context, "Added Unacademy to Study Apps!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("🎓 Unacademy", fontSize = 10.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(studyApps, key = { it.id }) { app ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1E18)),
                            border = BorderStroke(1.dp, Color(0x4D10B981))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(text = app.iconEmoji, fontSize = 24.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = app.name,
                                                color = Color.White,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(Color(0x3310B981))
                                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "WHITELISTED",
                                                    color = Color(0xFF34D399),
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.ExtraBold
                                                )
                                            }
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Strict Mode Allowed • Tracked in App Usage",
                                                color = Color(0xFF34D399),
                                                fontSize = 10.sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "• Set as Distraction 🛑",
                                                color = Color(0xFFF97316),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.clickable {
                                                    viewModel.toggleAppType(app.id)
                                                    Toast.makeText(context, "${app.name} set as Distraction App 🛑", Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        }
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Launch shortcut if app is installed
                                    val launchIntent = remember(app.packageName) {
                                        try {
                                            context.packageManager.getLaunchIntentForPackage(app.packageName)
                                        } catch (_: Exception) { null }
                                    }

                                    if (launchIntent != null) {
                                        IconButton(
                                            onClick = {
                                                try {
                                                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    context.startActivity(launchIntent)
                                                } catch (_: Exception) {
                                                    Toast.makeText(context, "Could not open ${app.name}", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.OpenInNew,
                                                contentDescription = "Open App",
                                                tint = Color(0xFF38BDF8),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteBlockedApp(app.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Remove App",
                                            tint = Color(0xFF64748B),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // TAB 2: SCREEN TIME / APP USAGE ANALYTICS
            // -------------------------------------------------------------
            if (selectedTab == 2) {
                val allApps = studySummary.allAppsUsage
                val studyAppRecords = allApps.filter { it.isStudyApp }
                val distractionRecords = allApps.filter { it.isDistraction }
                val otherRecords = allApps.filter { !it.isStudyApp && !it.isDistraction }

                // Study Apps Screen Time Section
                item {
                    Text(
                        text = "📚 STUDY APPS USAGE (${studyAppRecords.size})",
                        color = Color(0xFF34D399),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                if (studyAppRecords.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E))
                        ) {
                            Text(
                                text = "No study apps recorded today. Add your learning apps in the 'Study Apps 📚' tab to automatically track their screen time!",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(studyAppRecords, key = { "study_" + it.packageName }) { record ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1F16)),
                            border = BorderStroke(1.dp, Color(0x3310B981))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = record.iconEmoji, fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = record.appName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "Counted in JEE Study Hours", color = Color(0xFF34D399), fontSize = 10.sp)
                                    }
                                }
                                Text(
                                    text = record.getFormattedTime(),
                                    color = Color(0xFF34D399),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Distraction Apps Screen Time Section
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "🛑 DISTRACTION APPS USAGE (${distractionRecords.size})",
                        color = Color(0xFFFDA4AF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                if (distractionRecords.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E))
                        ) {
                            Text(
                                text = "Great job! Zero distraction apps used today! 🎉",
                                color = Color(0xFF34D399),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(distractionRecords, key = { "distract_" + it.packageName }) { record ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1F1116)),
                            border = BorderStroke(1.dp, Color(0x33F43F5E))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = record.iconEmoji, fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = record.appName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "Distraction App", color = Color(0xFFFDA4AF), fontSize = 10.sp)
                                    }
                                }
                                Text(
                                    text = record.getFormattedTime(),
                                    color = Color(0xFFF43F5E),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                if (otherRecords.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "📱 OTHER APPS USAGE (${otherRecords.size})",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    items(otherRecords, key = { "other_" + it.packageName }) { record ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E)),
                            border = BorderStroke(1.dp, Color(0xFF1E293B))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = record.iconEmoji, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = record.appName, color = Color.White, fontSize = 13.sp)
                                        Text(text = record.category, color = Color(0xFF64748B), fontSize = 10.sp)
                                    }
                                }
                                Text(
                                    text = record.getFormattedTime(),
                                    color = Color(0xFF94A3B8),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // TAB 3: INSTALLED USER APPS ON DEVICE
            // -------------------------------------------------------------
            if (selectedTab == 3) {
                if (filteredInstalled.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (installedApps.isEmpty()) "Scanning installed apps..." else "No matching apps found.",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    items(filteredInstalled, key = { it.packageName }) { app ->
                        val isAlreadyStudy = studyApps.any { it.packageName.equals(app.packageName, ignoreCase = true) }
                        val isAlreadyBlocked = guardedApps.any { it.packageName.equals(app.packageName, ignoreCase = true) }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isAlreadyStudy -> Color(0xFF0B1F16)
                                    isAlreadyBlocked -> Color(0xFF1F1216)
                                    else -> Color(0xFF131D2E)
                                }
                            ),
                            border = BorderStroke(
                                1.dp,
                                when {
                                    isAlreadyStudy -> Color(0x6610B981)
                                    isAlreadyBlocked -> Color(0x66F43F5E)
                                    else -> Color(0xFF1E293B)
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(text = app.iconEmoji, fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = app.name,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = when {
                                                isAlreadyStudy -> "Whitelisted Study App 📚"
                                                isAlreadyBlocked -> "Guarded / Blocked 🛑"
                                                else -> app.packageName
                                            },
                                            color = when {
                                                isAlreadyStudy -> Color(0xFF34D399)
                                                isAlreadyBlocked -> Color(0xFFFDA4AF)
                                                else -> Color(0xFF64748B)
                                            },
                                            fontSize = 10.sp,
                                            maxLines = 1
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // Button: Add/Toggle Study App
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isAlreadyStudy) Color(0xFF059669) else Color(0x3310B981))
                                            .clickable {
                                                if (isAlreadyStudy) {
                                                    val found = studyApps.firstOrNull { it.packageName.equals(app.packageName, ignoreCase = true) }
                                                    if (found != null) viewModel.deleteBlockedApp(found.id)
                                                } else {
                                                    viewModel.addInstalledAsStudyApp(app)
                                                    Toast.makeText(context, "${app.name} added as Study App! 📚", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = if (isAlreadyStudy) "✓ Study" else "+ Study 📚",
                                            color = if (isAlreadyStudy) Color.White else Color(0xFF34D399),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    // Button: Add/Toggle Block
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isAlreadyBlocked) Color(0xFFE11D48) else Color(0x33EF4444))
                                            .clickable {
                                                viewModel.toggleInstalledApp(app)
                                                val msg = if (isAlreadyBlocked) "Unblocked ${app.name}" else "Blocked ${app.name} in Strict Mode 🛑"
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = if (isAlreadyBlocked) "✓ Blocked" else "Block 🛑",
                                            color = if (isAlreadyBlocked) Color.White else Color(0xFFFDA4AF),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Google Play Protect Compliance Dialog
    if (showPlayProtectInfo) {
        AlertDialog(
            onDismissRequest = { showPlayProtectInfo = false },
            containerColor = Color(0xFF10192A),
            shape = RoundedCornerShape(22.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color(0xFF34D399),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Play Protect & Open Source",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Why Google Play Protect Permits This App:",
                        color = Color(0xFF60A5FA),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "1. Official Digital Wellbeing APIs: Unlike malware that hijacks accessibility services, this app uses Android's official UsageStatsManager and ForegroundService APIs—the same framework used by Google's Family Link and top Play Store focus apps like Forest and StayFree.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "2. 100% Open Source & Zero Telemetry: All blocking happens 100% locally on your device with no remote servers, no hidden tracking, and zero dynamic code loading.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "3. Safe to Launch: Play Protect scans apps for malicious behavior. Because this app complies fully with Google Play Developer Program policies, Play Protect allows it to install and launch without warnings.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPlayProtectInfo = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Understood", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        )
    }

    // Add Custom App Dialog (Supports Study App vs Distraction App with JEE Presets)
    if (showAddCustomDialog) {
        var isStudy by remember { mutableStateOf(addDialogIsStudyApp) }
        var appName by remember { mutableStateOf("") }
        var appPkg by remember { mutableStateOf("") }
        var appCategory by remember { mutableStateOf(if (isStudy) "Study & Prep" else "Social Media") }
        var appEmoji by remember { mutableStateOf(if (isStudy) "📚" else "📱") }

        AlertDialog(
            onDismissRequest = { showAddCustomDialog = false },
            containerColor = Color(0xFF131D2E),
            shape = RoundedCornerShape(22.dp),
            title = {
                Text(
                    text = if (isStudy) "Add Study App 📚" else "Add Distraction App 🛑",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Type Selector Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A))
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isStudy) Color(0xFF059669) else Color.Transparent)
                                .clickable {
                                    isStudy = true
                                    appEmoji = "📚"
                                    appCategory = "Study & Prep"
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Study App 📚",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isStudy) Color.White else Color(0xFF94A3B8)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (!isStudy) Color(0xFFDC2626) else Color.Transparent)
                                .clickable {
                                    isStudy = false
                                    appEmoji = "📱"
                                    appCategory = "Social Media"
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Distraction 🛑",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (!isStudy) Color.White else Color(0xFF94A3B8)
                            )
                        }
                    }

                    Text(
                        text = if (isStudy)
                            "Study apps are whitelisted and NEVER blocked in Strict Mode. Screen time counts towards your Daily JEE Study Hours!"
                        else
                            "Distraction apps are guarded and blocked during timetable study slots to keep you focused.",
                        color = if (isStudy) Color(0xFF6EE7B7) else Color(0xFFFDA4AF),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    // Quick Tap Presets
                    Text(
                        text = "QUICK PRESETS:",
                        color = Color(0xFF64748B),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (isStudy) {
                            listOf(
                                Triple("Physics Wallah", "xyz.penpencil.physicswala", "⚡"),
                                Triple("Unacademy", "com.unacademyapp", "🎓"),
                                Triple("ALLEN", "com.allen.allenapp", "📖"),
                                Triple("Khan Academy", "org.khanacademy.android", "🧠"),
                                Triple("Doubtnut", "com.doubtnutapp", "❓"),
                                Triple("Calculator", "com.google.android.calculator", "🔢"),
                                Triple("NCERT Books", "in.nic.ncert", "📚")
                            ).forEach { (name, pkg, emoji) ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x3310B981))
                                        .border(BorderStroke(1.dp, Color(0x6610B981)), RoundedCornerShape(8.dp))
                                        .clickable {
                                            appName = name
                                            appPkg = pkg
                                            appEmoji = emoji
                                        }
                                        .padding(horizontal = 8.dp, vertical = 5.dp)
                                ) {
                                    Text("$emoji $name", fontSize = 11.sp, color = Color(0xFF34D399), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        } else {
                            listOf(
                                Triple("Instagram", "com.instagram.android", "📸"),
                                Triple("YouTube", "com.google.android.youtube", "▶️"),
                                Triple("Snapchat", "com.snapchat.android", "👻"),
                                Triple("BGMI", "com.pubg.imobile", "🎮"),
                                Triple("Netflix", "com.netflix.mediaclient", "🎬"),
                                Triple("Discord", "com.discord", "🎧")
                            ).forEach { (name, pkg, emoji) ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x33EF4444))
                                        .border(BorderStroke(1.dp, Color(0x66EF4444)), RoundedCornerShape(8.dp))
                                        .clickable {
                                            appName = name
                                            appPkg = pkg
                                            appEmoji = emoji
                                        }
                                        .padding(horizontal = 8.dp, vertical = 5.dp)
                                ) {
                                    Text("$emoji $name", fontSize = 11.sp, color = Color(0xFFFDA4AF), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it },
                        label = { Text(if (isStudy) "Study App Name (e.g. PhysicsWallah)" else "Distraction App Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = if (isStudy) Color(0xFF10B981) else Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = appPkg,
                        onValueChange = { appPkg = it },
                        label = { Text("Package Name (Optional)") },
                        placeholder = { Text("e.g. xyz.penpencil.physicswala", fontSize = 11.sp, color = Color(0xFF64748B)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = if (isStudy) Color(0xFF10B981) else Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Emoji Selector
                    Text("CHOOSE ICON:", color = Color(0xFF64748B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val emojis = if (isStudy)
                            listOf("📚", "⚡", "🎓", "🧠", "📖", "🔬", "📐", "🔢", "💡", "🌐")
                        else
                            listOf("📱", "🎮", "💬", "🎬", "🌐", "🎵", "📸", "🎧", "👻", "✖️")

                        emojis.forEach { emoji ->
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (appEmoji == emoji) (if (isStudy) Color(0xFF059669) else Color(0xFF2563EB)) else Color(0xFF1E293B))
                                    .clickable { appEmoji = emoji },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = emoji, fontSize = 18.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (appName.isNotBlank()) {
                            viewModel.addCustomApp(
                                name = appName.trim(),
                                pkg = appPkg.trim(),
                                category = if (isStudy) "Study & Prep" else appCategory,
                                emoji = appEmoji,
                                isStudyApp = isStudy
                            )
                            val toastMsg = if (isStudy) "Added ${appName.trim()} to Study Apps! 📚" else "Added ${appName.trim()} to Blocked Apps 🛑"
                            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
                            showAddCustomDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isStudy) Color(0xFF059669) else Color(0xFF2563EB))
                ) {
                    Text(
                        text = if (isStudy) "Add as Study App 📚" else "Block in Strict Mode 🛑",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCustomDialog = false }) {
                    Text("Cancel", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    // Distraction Lockout Shield Full-Screen Dialog (Preview Mode)
    if (showDistractionOverlay) {
        IosDistractionShieldOverlay(
            blockedApp = blockedAppToPreview ?: blockedApps.firstOrNull(),
            onDismiss = { viewModel.dismissDistractionShield() },
            onGoToRoutine = {
                viewModel.dismissDistractionShield()
                onClose()
                onNavigateToRoutine()
            },
            onGoToPractice = {
                viewModel.dismissDistractionShield()
                onClose()
                onNavigateToPractice()
            }
        )
    }

    // 24/7 Background Running & OEM Autostart Guide Dialog
    if (showBackgroundGuideDialog) {
        Dialog(
            onDismissRequest = { showBackgroundGuideDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.dp, Color(0xFF3B82F6))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⚡", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "24/7 Background Activation Guide",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Ensure alarms & strict mode work when app is closed",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                        }
                        IconButton(
                            onClick = { showBackgroundGuideDialog = false },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFF1E293B))

                    Text(
                        text = "Modern Android phones (Xiaomi/Redmi, Realme, Oppo, Vivo, Samsung, OnePlus) put apps to sleep when closed. Complete these quick steps so alarms and study locks run 24/7:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    // Step 1: Battery Optimization
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "1. Set Battery to 'Unrestricted'",
                                color = Color(0xFF60A5FA),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Stops Android from killing the Strict Study Service when the app isn't open.",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { FocusShieldManager.requestIgnoreBatteryOptimizations(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("1-Tap: Allow Battery Exemption", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Step 2: Auto-start
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "2. Enable Auto-Start (Xiaomi / Realme / Oppo / Vivo)",
                                color = Color(0xFF34D399),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Allows JEE Reminder to activate in background on phone boot and during study slots.",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { FocusShieldManager.openAutostartSettings(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Open Phone Autostart Manager", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Step 3: Lock in Recents
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "3. Lock in Recent Apps (Optional)",
                                color = Color(0xFFFBBF24),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Open Recent Apps -> Swipe down or long-press JEE Reminder -> Tap the 🔒 Lock icon.",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Button(
                        onClick = { showBackgroundGuideDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Understood", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// AUTHENTIC DISTRACTION SHIELD / LOCKOUT SCREEN (Preview)
// -------------------------------------------------------------
@Composable
private fun IosDistractionShieldOverlay(
    blockedApp: BlockedApp?,
    onDismiss: () -> Unit,
    onGoToRoutine: () -> Unit,
    onGoToPractice: () -> Unit
) {
    var emergencyUnlocked by remember { mutableStateOf(false) }
    var mathAnswerInput by remember { mutableStateOf("") }
    var mathError by remember { mutableStateOf(false) }

    val num1 = remember { 14 }
    val num2 = remember { 17 }
    val correctAnswer = remember { num1 * num2 } // 238

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF000000))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Large Lock Icon
                Box(
                    modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E293B))
                        .border(2.dp, Color(0xFFF97316), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.HourglassTop,
                        contentDescription = "Screen Time Limit",
                        tint = Color(0xFFF97316),
                        modifier = Modifier.size(44.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "Time Limit Reached",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "You've reached your limit on ${blockedApp?.name ?: "Distracting Apps"}.\nStrict Study Guard is actively protecting your study slot.",
                    color = Color(0xFF94A3B8),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Motivation Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E)),
                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🎯 IIT JEE ADVANCED FOCUS",
                            color = Color(0xFFF97316),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "\"Every 15 minutes of scrolling costs 1 Rank in IIT. Your dream branch is waiting for your consistency.\"",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // Primary Action: Return to Routine Timetable
                Button(
                    onClick = onGoToRoutine,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Return to JEE Timetable",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Secondary Action: Solve Questions Instead
                OutlinedButton(
                    onClick = onGoToPractice,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.TrackChanges, contentDescription = null, tint = Color(0xFF34D399))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Solve PYQ Practice Questions",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Emergency Break with Math Verification
                if (!emergencyUnlocked) {
                    Text(
                        text = "Emergency 2-Minute Break (Solve Challenge)",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clickable { emergencyUnlocked = true }
                            .padding(8.dp)
                    )
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2E)),
                        border = BorderStroke(1.dp, Color(0xFF1E293B))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Solve to Unlock: $num1 × $num2 = ?",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = mathAnswerInput,
                                    onValueChange = { mathAnswerInput = it },
                                    label = { Text("Answer") },
                                    isError = mathError,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFF97316)
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (mathAnswerInput.trim() == correctAnswer.toString()) {
                                            onDismiss()
                                        } else {
                                            mathError = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316))
                                ) {
                                    Text("Verify")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
