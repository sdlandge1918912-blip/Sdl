package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exam_events")
data class ExamEvent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val examDateMillis: Long,
    val category: String, // "EXAM", "REGISTRATION", "MOCK", "CUSTOM"
    val notes: String = "",
    val isTargetExam: Boolean = false,
    val reminderEnabled: Boolean = true
)
