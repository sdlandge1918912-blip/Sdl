package com.example.auth

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

object GoogleAuthManager {
    private const val TAG = "GoogleAuthManager"

    fun getCurrentUser(): FirebaseUser? = try { Firebase.auth.currentUser } catch (_: Exception) { null }

    fun getStudentUid(): String? = getCurrentUser()?.uid

    fun onGoogleSignInClicked(
        context: Context,
        credentialManager: CredentialManager,
        onAuthSuccess: (FirebaseUser) -> Unit,
        onAuthError: (String) -> Unit,
        scope: CoroutineScope,
        onAuthCancelled: () -> Unit = {}
    ) {
        val serverClientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            "477652683303-gih00ap4530enas1hf85m3cvsqds85un.apps.googleusercontent.com"
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(serverClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    credentialManager.getCredential(
                        context = context,
                        request = request
                    )
                }

                val credential = result.credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val googleIdTokenCredential =
                        GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken
                    val authCredential = GoogleAuthProvider.getCredential(idToken, null)
                    val authResult = Firebase.auth.signInWithCredential(authCredential).await()
                    val user = authResult.user
                    if (user != null) {
                        Log.d(TAG, "Google Sign-In successful for user ${user.uid} (${user.email})")
                        onAuthSuccess(user)
                    } else {
                        onAuthError("Firebase authentication returned empty user.")
                    }
                } else {
                    onAuthError("Unexpected credential type received.")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.d(TAG, "Sign-in cancelled by user")
                onAuthCancelled()
            } catch (e: GetCredentialException) {
                Log.w(TAG, "Credential error: ${e.message}")
                onAuthError("Sign-in credential error: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Sign-in exception", e)
                onAuthError("Authentication error: ${e.localizedMessage ?: "Unknown error"}")
            }
        }
    }

    fun attemptAutoSignIn(
        context: Context,
        credentialManager: CredentialManager,
        onAuthSuccess: (FirebaseUser) -> Unit,
        onUnauthenticated: () -> Unit,
        scope: CoroutineScope
    ) {
        val currentUser = getCurrentUser()
        if (currentUser != null) {
            Log.d(TAG, "Auto-sign-in verified for existing user ${currentUser.uid}")
            onAuthSuccess(currentUser)
            return
        }

        val serverClientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            "477652683303-gih00ap4530enas1hf85m3cvsqds85un.apps.googleusercontent.com"
        }

        val autoGoogleOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(serverClientId)
            .setAutoSelectEnabled(true)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(autoGoogleOption)
            .build()

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    credentialManager.getCredential(
                        context = context,
                        request = request
                    )
                }
                val credential = result.credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val tokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val authCredential = GoogleAuthProvider.getCredential(tokenCredential.idToken, null)
                    val authResult = Firebase.auth.signInWithCredential(authCredential).await()
                    authResult.user?.let {
                        Log.d(TAG, "Auto-sign-in success: ${it.uid}")
                        onAuthSuccess(it)
                    } ?: onUnauthenticated()
                } else {
                    onUnauthenticated()
                }
            } catch (_: Exception) {
                onUnauthenticated()
            }
        }
    }

    fun signOut(onSignedOut: () -> Unit = {}) {
        try { Firebase.auth.signOut() } catch (e: Exception) { Log.w(TAG, "Firebase is not configured; nothing to sign out", e) }
        onSignedOut()
    }
}
