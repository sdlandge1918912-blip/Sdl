package com.example.data.dao

import androidx.room.*
import com.example.data.model.MockTestRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface MockTestDao {
    @Query("SELECT * FROM mock_test_records ORDER BY testDateMillis DESC")
    fun getAllMockTests(): Flow<List<MockTestRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockTest(test: MockTestRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tests: List<MockTestRecord>)

    @Delete
    suspend fun deleteMockTest(test: MockTestRecord)

    @Query("SELECT COUNT(*) FROM mock_test_records")
    suspend fun countMockTests(): Int

    @Query("DELETE FROM mock_test_records")
    suspend fun deleteAllMockTests()
}
