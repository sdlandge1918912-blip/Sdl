package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

data class BgPresetItem(
    val key: String,
    val name: String,
    val brush: Brush,
    val description: String
)

val JEE_BG_PRESETS = listOf(
    BgPresetItem(
        key = "COSMIC",
        name = "Cosmic Galaxy",
        brush = Brush.verticalGradient(listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E))),
        description = "Deep violet & dark indigo space aura"
    ),
    BgPresetItem(
        key = "CYBER_NEON",
        name = "Electric Cyber",
        brush = Brush.verticalGradient(listOf(Color(0xFF0A192F), Color(0xFF1E3A8A), Color(0xFF0F172A))),
        description = "High energy deep sapphire & electric blue"
    ),
    BgPresetItem(
        key = "DEEP_FOREST",
        name = "Emerald Forest",
        brush = Brush.verticalGradient(listOf(Color(0xFF062A1F), Color(0xFF064E3B), Color(0xFF022C22))),
        description = "Calming deep green nature tones"
    ),
    BgPresetItem(
        key = "CHILL_AURA",
        name = "Midnight Slate",
        brush = Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0B0F19))),
        description = "Focus-inducing cool dark slate"
    ),
    BgPresetItem(
        key = "SUNSET",
        name = "Evening Study",
        brush = Brush.verticalGradient(listOf(Color(0xFF2E1065), Color(0xFF581C87), Color(0xFF1E1B4B))),
        description = "Warm amber sunset glow"
    ),
    BgPresetItem(
        key = "MINIMAL_DARK",
        name = "OLED Carbon",
        brush = Brush.verticalGradient(listOf(Color(0xFF18181B), Color(0xFF09090B), Color(0xFF000000))),
        description = "Pure pitch AMOLED dark"
    )
)

@Composable
fun AppBackgroundContainer(
    bgType: String,
    bgPreset: String,
    customUri: String?,
    blurIntensity: Float,
    dimOpacity: Float,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val context = LocalContext.current

    Box(modifier = modifier.fillMaxSize()) {
        // Base Wallpaper Layer
        when (bgType) {
            "CUSTOM_IMAGE" -> {
                val imageModifier = if (blurIntensity > 0.5f) {
                    Modifier
                        .fillMaxSize()
                        .blur(blurIntensity.dp)
                } else {
                    Modifier.fillMaxSize()
                }

                // Resolve persistent file or URI with guaranteed fallback to study desk wallpaper
                val imageModel: Any = remember(customUri) {
                    val internalFile = File(context.filesDir, "custom_study_wallpaper.jpg")
                    if (internalFile.exists() && internalFile.length() > 0) {
                        internalFile
                    } else if (!customUri.isNullOrBlank()) {
                        val clean = customUri.removePrefix("file://")
                        val f = File(clean)
                        if (f.exists() && f.length() > 0) f
                        else if (customUri.startsWith("content://")) Uri.parse(customUri)
                        else com.example.R.drawable.study_desk_wallpaper
                    } else {
                        com.example.R.drawable.study_desk_wallpaper
                    }
                }

                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(imageModel)
                        .crossfade(true)
                        .error(com.example.R.drawable.study_desk_wallpaper)
                        .fallback(com.example.R.drawable.study_desk_wallpaper)
                        .build(),
                    contentDescription = "Custom Study Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = imageModifier
                )
            }
            "PRESET" -> {
                val preset = JEE_BG_PRESETS.find { it.key == bgPreset } ?: JEE_BG_PRESETS.first()
                val bgModifier = if (blurIntensity > 0.5f) {
                    Modifier
                        .fillMaxSize()
                        .blur(blurIntensity.dp)
                        .background(preset.brush)
                } else {
                    Modifier
                        .fillMaxSize()
                        .background(preset.brush)
                }
                Box(modifier = bgModifier)
            }
            else -> {
                // Default Cozy Study Room Desk Photo Wallpaper
                val imageModifier = if (blurIntensity > 0.5f) {
                    Modifier
                        .fillMaxSize()
                        .blur(blurIntensity.dp)
                } else {
                    Modifier.fillMaxSize()
                }

                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(com.example.R.drawable.study_desk_wallpaper)
                        .crossfade(true)
                        .build(),
                    contentDescription = "JEE Study Room Wallpaper",
                    contentScale = ContentScale.Crop,
                    modifier = imageModifier
                )
            }
        }

        // Frosted Glass / Dimming Overlay for perfect readability of text & cards
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = dimOpacity.coerceIn(0.20f, 0.90f)))
        )

        // Foreground content (Routine, Hub, Clock, etc.)
        content()
    }
}

@Composable
fun BackgroundEditDialog(
    currentType: String,
    currentPreset: String,
    currentUri: String?,
    blurIntensity: Float,
    dimOpacity: Float,
    onSelectPreset: (String) -> Unit,
    onSelectCustomUri: (String) -> Unit,
    onChangeBlur: (Float) -> Unit,
    onChangeDim: (Float) -> Unit,
    onResetDefault: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isSavingImage by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            isSavingImage = true
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            context.contentResolver.takePersistableUriPermission(
                                uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                    } catch (_: Exception) {}

                    // Copy and safely compress to internal app storage so it NEVER expires and survives app restart / reboot
                    context.filesDir.mkdirs()
                    val internalWallpaper = File(context.filesDir, "custom_study_wallpaper.jpg")
                    var saved = false

                    try {
                        // Decode sample size to prevent OutOfMemory on high-res gallery images
                        context.contentResolver.openInputStream(uri)?.use { stream1 ->
                            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeStream(stream1, null, boundsOptions)

                            var sampleSize = 1
                            val maxDim = 1920
                            while ((boundsOptions.outWidth / sampleSize) > maxDim || (boundsOptions.outHeight / sampleSize) > maxDim) {
                                sampleSize *= 2
                            }

                            context.contentResolver.openInputStream(uri)?.use { stream2 ->
                                val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                                val bitmap = BitmapFactory.decodeStream(stream2, null, decodeOptions)
                                if (bitmap != null) {
                                    FileOutputStream(internalWallpaper).use { out ->
                                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                                        out.flush()
                                    }
                                    bitmap.recycle()
                                    saved = true
                                }
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    if (!saved) {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(internalWallpaper).use { output ->
                                input.copyTo(output)
                                output.flush()
                            }
                        }
                    }

                    val finalPath = if (internalWallpaper.exists() && internalWallpaper.length() > 0) {
                        internalWallpaper.absolutePath
                    } else {
                        uri.toString()
                    }

                    withContext(Dispatchers.Main) {
                        isSavingImage = false
                        onSelectCustomUri(finalPath)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    withContext(Dispatchers.Main) {
                        isSavingImage = false
                        onSelectCustomUri(uri.toString())
                    }
                }
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0A84FF).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = null,
                                tint = Color(0xFF0A84FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Wallpaper & Blur",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Customize background & glass blur",
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF8E8E93)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Custom Image Upload Button (Photo Picker zero-permission)
                Text(
                    text = "CUSTOM PHOTO WALLPAPER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8E8E93),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2E)),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isSavingImage,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isSavingImage) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Saving Photo...",
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = Color(0xFF0A84FF),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentType == "CUSTOM_IMAGE") "Change Photo" else "Pick from Gallery",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    if (currentType != "DEFAULT") {
                        OutlinedButton(
                            onClick = onResetDefault,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF453A))
                        ) {
                            Text("Reset", fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Preset Themes
                Text(
                    text = "OR CHOOSE A COLOR AURA",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8E8E93),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(JEE_BG_PRESETS) { preset ->
                        val isSelected = currentType == "PRESET" && currentPreset == preset.key
                        Box(
                            modifier = Modifier
                                .size(width = 96.dp, height = 72.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(preset.brush)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF0A84FF) else Color(0x33FFFFFF),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { onSelectPreset(preset.key) }
                                .padding(8.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Text(
                                text = preset.name,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Blur Intensity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Glass Blur Effect",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "${blurIntensity.toInt()} dp",
                        color = Color(0xFF0A84FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = blurIntensity,
                    onValueChange = onChangeBlur,
                    valueRange = 0f..28f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF0A84FF),
                        activeTrackColor = Color(0xFF0A84FF),
                        inactiveTrackColor = Color(0xFF3A3A3C)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Dark Dimming Opacity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dimming Overlay (Darkness)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "${(dimOpacity * 100).toInt()}%",
                        color = Color(0xFF0A84FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = dimOpacity,
                    onValueChange = onChangeDim,
                    valueRange = 0.20f..0.85f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF0A84FF),
                        activeTrackColor = Color(0xFF0A84FF),
                        inactiveTrackColor = Color(0xFF3A3A3C)
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A84FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apply & Save Wallpaper", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
