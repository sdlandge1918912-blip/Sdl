package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.service.AppUsageRecord
import com.example.service.StudyTimeTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppScreenTimeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == ACTION_REFRESH_SCREEN_TIME_WIDGET ||
            action == Intent.ACTION_TIME_TICK ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == AppWidgetManager.ACTION_APPWIDGET_UPDATE
        ) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, AppScreenTimeWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId)
            }
        }
    }

    companion object {
        const val ACTION_REFRESH_SCREEN_TIME_WIDGET = "com.example.widget.ACTION_REFRESH_SCREEN_TIME_WIDGET"

        fun updateAllWidgets(context: Context) {
            try {
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val thisWidget = ComponentName(context, AppScreenTimeWidgetProvider::class.java)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
                if (appWidgetIds.isNotEmpty()) {
                    for (id in appWidgetIds) {
                        updateAppWidget(context, appWidgetManager, id)
                    }
                }
            } catch (e: Exception) {
                Log.e("AppScreenTimeWidget", "Failed to update widgets", e)
            }
        }

        private fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val scope = CoroutineScope(Dispatchers.IO)
            scope.launch {
                try {
                    val summary = StudyTimeTracker.getTodayStudySummary(context)
                    withContext(Dispatchers.Main) {
                        renderWidget(context, appWidgetManager, appWidgetId, summary.allAppsUsage, summary.totalStudySeconds, summary.distractionSeconds)
                    }
                } catch (e: Exception) {
                    Log.w("AppScreenTimeWidget", "Could not query usage, fallback rendering", e)
                }
            }
        }

        private fun renderWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            apps: List<AppUsageRecord>,
            studySeconds: Long,
            distractionSeconds: Long
        ) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_app_screen_time)

                val studyFormatted = formatSeconds(studySeconds)
                val distractFormatted = formatSeconds(distractionSeconds)

                views.setTextViewText(R.id.widget_ast_summary_pill, "🛑 $distractFormatted Distraction")
                views.setTextViewText(R.id.widget_ast_study_compare, "📚 Study: $studyFormatted • Distraction: $distractFormatted")

                // Bind Rows
                val rowConfigs = listOf(
                    RowBinding(R.id.widget_ast_row_1, R.id.widget_ast_app1_icon, R.id.widget_ast_app1_name, R.id.widget_ast_app1_time, R.id.widget_ast_app1_badge),
                    RowBinding(R.id.widget_ast_row_2, R.id.widget_ast_app2_icon, R.id.widget_ast_app2_name, R.id.widget_ast_app2_time, R.id.widget_ast_app2_badge),
                    RowBinding(R.id.widget_ast_row_3, R.id.widget_ast_app3_icon, R.id.widget_ast_app3_name, R.id.widget_ast_app3_time, R.id.widget_ast_app3_badge),
                    RowBinding(R.id.widget_ast_row_4, R.id.widget_ast_app4_icon, R.id.widget_ast_app4_name, R.id.widget_ast_app4_time, R.id.widget_ast_app4_badge)
                )

                for (i in rowConfigs.indices) {
                    val config = rowConfigs[i]
                    val app = apps.getOrNull(i)
                    if (app != null) {
                        views.setViewVisibility(config.rowId, View.VISIBLE)
                        views.setTextViewText(config.iconId, app.iconEmoji.ifBlank { "📱" })
                        views.setTextViewText(config.nameId, app.appName)
                        views.setTextViewText(config.timeId, app.getFormattedTime())

                        when {
                            app.isStudyApp -> {
                                views.setTextViewText(config.badgeId, "STUDY")
                                views.setTextColor(config.badgeId, Color.parseColor("#30D158"))
                                views.setTextColor(config.timeId, Color.parseColor("#34D399"))
                                try {
                                    views.setInt(config.badgeId, "setBackgroundResource", R.drawable.widget_badge_study)
                                } catch (_: Exception) {}
                            }
                            app.isDistraction -> {
                                views.setTextViewText(config.badgeId, "DISTRACT")
                                views.setTextColor(config.badgeId, Color.parseColor("#FF453A"))
                                views.setTextColor(config.timeId, Color.parseColor("#FF6B6B"))
                                try {
                                    views.setInt(config.badgeId, "setBackgroundResource", R.drawable.widget_badge_distraction)
                                } catch (_: Exception) {}
                            }
                            else -> {
                                views.setTextViewText(config.badgeId, "APP")
                                views.setTextColor(config.badgeId, Color.parseColor("#94A3B8"))
                                views.setTextColor(config.timeId, Color.parseColor("#93C5FD"))
                                try {
                                    views.setInt(config.badgeId, "setBackgroundResource", R.drawable.widget_inner_card)
                                } catch (_: Exception) {}
                            }
                        }
                    } else {
                        views.setViewVisibility(config.rowId, View.GONE)
                    }
                }

                // Click open Focus App Blocker (Nav Tab 2)
                val blockerIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(MainActivity.EXTRA_NAV_TAB, 2)
                }
                val pendingBlocker = PendingIntent.getActivity(
                    context,
                    201,
                    blockerIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_app_screen_time_root, pendingBlocker)
                views.setOnClickPendingIntent(R.id.widget_ast_btn_blocker, pendingBlocker)
                views.setOnClickPendingIntent(R.id.widget_ast_btn_limits, pendingBlocker)

                // Refresh Button
                val refreshIntent = Intent(context, AppScreenTimeWidgetProvider::class.java).apply {
                    action = ACTION_REFRESH_SCREEN_TIME_WIDGET
                }
                val pendingRefresh = PendingIntent.getBroadcast(
                    context,
                    202,
                    refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_ast_btn_refresh, pendingRefresh)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                Log.e("AppScreenTimeWidget", "Error rendering widget", e)
            }
        }

        private fun formatSeconds(sec: Long): String {
            val hours = sec / 3600
            val minutes = (sec % 3600) / 60
            return when {
                hours > 0 -> "${hours}h ${minutes}m"
                minutes > 0 -> "${minutes}m"
                sec > 0 -> "${sec}s"
                else -> "0m"
            }
        }

        private data class RowBinding(
            val rowId: Int,
            val iconId: Int,
            val nameId: Int,
            val timeId: Int,
            val badgeId: Int
        )
    }
}
