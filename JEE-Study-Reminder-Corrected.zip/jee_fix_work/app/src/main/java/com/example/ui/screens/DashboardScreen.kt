package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamEvent
import com.example.data.model.MockTestRecord
import com.example.data.model.RoutineSession
import com.example.data.model.StudyReminder
import com.example.data.model.SyllabusTopic
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.StudyTimeTracker
import com.example.service.DailyStudySummary
import com.example.service.SectionStudyRecord
import com.example.service.AppUsageRecord
import com.example.ui.viewmodel.JeeViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.JeeExamCountdownCard
import android.widget.Toast
import java.util.Calendar

@Composable
fun DashboardScreen(
    viewModel: JeeViewModel? = null,
    targetExam: ExamEvent?,
    allExams: List<ExamEvent> = emptyList(),
    reminders: List<StudyReminder> = emptyList(),
    routineSessions: List<RoutineSession> = emptyList(),
    syllabusTopics: List<SyllabusTopic> = emptyList(),
    mockTests: List<MockTestRecord> = emptyList(),
    totalStudyMinutes: Int = 120,
    onSelectTargetExam: (Long) -> Unit = {},
    onAddNewExam: (String, Long, String, String) -> Unit = { _, _, _, _ -> },
    onToggleReminder: (StudyReminder) -> Unit = {},
    onSendNotification: (StudyReminder) -> Unit = {},
    onNavigateToTab: (Int) -> Unit = {},
    onOpenRemindersPage: () -> Unit = {},
    onOpenAddReminder: () -> Unit = {},
    onResetRemindersToTimetable: () -> Unit = {},
    completedSessionIds: Set<Long> = emptySet(),
    onToggleSessionCompletion: (Long) -> Unit = {},
    onEditBackground: () -> Unit = {},
    isStrictStudyActive: Boolean = false,
    isOngoingStudySlot: Boolean = false,
    isOngoingBreakSlot: Boolean = false,
    hasBatteryExemption: Boolean = true,
    onOpenStrictStudyMode: () -> Unit = {},
    onOpenRestoreBackup: () -> Unit = {},
    onOpenParentConnect: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val studySummaryState = viewModel?.todayStudySummary?.collectAsStateWithLifecycle()
    val studySummary = studySummaryState?.value ?: remember { StudyTimeTracker.getTodayStudySummary(context) }

    var currentMinutesOfDay by remember {
        val cal = Calendar.getInstance()
        mutableIntStateOf(cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE))
    }
    var currentHour by remember {
        val cal = Calendar.getInstance()
        mutableIntStateOf(cal.get(Calendar.HOUR_OF_DAY))
    }

    LaunchedEffect(Unit) {
        while (true) {
            val cal = Calendar.getInstance()
            currentMinutesOfDay = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            currentHour = cal.get(Calendar.HOUR_OF_DAY)
            delay(2000L)
        }
    }

    val greeting = when (currentHour) {
        in 4..11 -> "Good Morning 👋"
        in 12..16 -> "Good Afternoon ☀️"
        in 17..21 -> "Good Evening 🌆"
        else -> "Good Night 🌙"
    }

    val sessionMatch = remember(routineSessions, currentMinutesOfDay) {
        if (routineSessions.isEmpty()) null
        else {
            var active: RoutineSession? = null
            var remainingMin = 0

            // 1. Look for currently ongoing session
            for (session in routineSessions) {
                val startParts = session.startTime.split(":")
                val endParts = session.endTime.split(":")
                val startMin = (startParts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (startParts.getOrNull(1)?.toIntOrNull() ?: 0)
                val endMin = (endParts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (endParts.getOrNull(1)?.toIntOrNull() ?: 0)

                val isOngoing = if (endMin > startMin) {
                    currentMinutesOfDay in startMin until endMin
                } else if (endMin < startMin) {
                    currentMinutesOfDay >= startMin || currentMinutesOfDay < endMin
                } else {
                    currentMinutesOfDay in startMin until (startMin + 15)
                }

                if (isOngoing) {
                    active = session
                    val actualEnd = if (endMin == startMin) startMin + 15 else endMin
                    remainingMin = if (actualEnd >= currentMinutesOfDay) actualEnd - currentMinutesOfDay else (actualEnd + 1440 - currentMinutesOfDay)
                    break
                }
            }

            if (active != null) {
                Triple(active, true, remainingMin.coerceAtLeast(1))
            } else {
                // 2. Find next upcoming session today
                val next = routineSessions.firstOrNull { session ->
                    val startParts = session.startTime.split(":")
                    val startMin = (startParts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (startParts.getOrNull(1)?.toIntOrNull() ?: 0)
                    startMin > currentMinutesOfDay
                } ?: routineSessions.first()

                val nextStartParts = next.startTime.split(":")
                val nextStartMin = (nextStartParts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (nextStartParts.getOrNull(1)?.toIntOrNull() ?: 0)
                val diff = if (nextStartMin >= currentMinutesOfDay) nextStartMin - currentMinutesOfDay else (nextStartMin + 1440 - currentMinutesOfDay)
                Triple(next, false, diff.coerceAtLeast(1))
            }
        }
    }

    val activeSession = sessionMatch?.first
    val isLiveNow = sessionMatch?.second ?: false
    val remainingMinutesInActive = sessionMatch?.third ?: 30

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Good Morning & 7d Streak Card (Screenshot 3)
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_greeting_streak_card"),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xB810172A),
                    borderColor = Color(0x2660A5FA)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = greeting,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "JEE Aspirant • Target 2028 (Mission IIT)",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }

                        // 7d Streak Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFF261E14))
                                .border(BorderStroke(1.dp, Color(0xFFD97706)), RoundedCornerShape(20.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "🔥", fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "7d Streak",
                                    color = Color(0xFFF59E0B),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Quick Tools Bar: Restore Hub & Strict Study
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Restore Hub Quick Chip
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x99111C30))
                            .border(BorderStroke(1.dp, Color(0x3338BDF8)), RoundedCornerShape(12.dp))
                            .clickable { onOpenRestoreBackup() }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = "Restore Hub",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Restore & Backup",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Strict Study Quick Chip
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isStrictStudyActive) Color(0x99064E3B) else Color(0x99111C30))
                            .border(
                                BorderStroke(
                                    1.dp,
                                    if (isStrictStudyActive) Color(0xFF10B981) else Color(0x3360A5FA)
                                ),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onOpenStrictStudyMode() }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Strict Study",
                                tint = if (isStrictStudyActive) Color(0xFF34D399) else Color(0xFF60A5FA),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isStrictStudyActive) "Study Guard ON" else "Study Blocker",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Parent Sync Quick Chip
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x990C4A6E))
                            .border(BorderStroke(1.dp, Color(0x3338BDF8)), RoundedCornerShape(12.dp))
                            .clickable { onOpenParentConnect() }
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SupervisorAccount,
                                contentDescription = "Parent Sync",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Parent Sync",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // 2. Visual JEE 2028 Countdown Mission Card
            item {
                JeeExamCountdownCard(
                    targetExam = targetExam,
                    allExams = allExams,
                    onSelectTargetExam = onSelectTargetExam,
                    onUpdateExamDate = { exam, newDate ->
                        viewModel?.updateExamDate(exam, newDate)
                    },
                    onAddNewExamClick = {
                        // Switch to reminders or exams
                    },
                    onStartStudyClick = {
                        onNavigateToTab(3) // Jump to Timer / Stopwatch session
                    }
                )
            }

            // 3. Study Target & Today's Progress Cards (Screenshot 3)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Study Target Card
                    GlassCard(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        backgroundColor = Color(0xB810172A),
                        borderColor = Color(0x2660A5FA),
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STUDY TARGET",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF94A3B8),
                                letterSpacing = 0.5.sp
                            )
                            Icon(
                                imageVector = Icons.Default.TrackChanges,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${totalStudyMinutes / 60}h",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = " / 8h goal",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { ((totalStudyMinutes.toFloat() / (8 * 60)).coerceIn(0f, 1f)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Color(0xFF38BDF8),
                            trackColor = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "0% reached", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            Text(text = "8h left", fontSize = 10.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Today's Progress Card
                    GlassCard(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        backgroundColor = Color(0xB810172A),
                        borderColor = Color(0x2660A5FA),
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TODAY'S PROGRESS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF94A3B8),
                                letterSpacing = 0.5.sp
                            )
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF34D399),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "0",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = " / 20 sessions",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { 0.15f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Color(0xFF34D399),
                            trackColor = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "6 Qs Solved", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            Text(text = "67% Acc", fontSize = 10.sp, color = Color(0xFF34D399), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // 3. LIVE NOW Session Card (Screenshot 3)
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xCC0E1626),
                    borderColor = Color(0x3360A5FA)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Live or Next Up badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isLiveNow) Color(0xFF1D4ED8) else Color(0xFF92400E))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = if (isLiveNow) "LIVE NOW" else "NEXT UP",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        Text(
                            text = activeSession?.getFormattedTime() ?: "Today's Schedule",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = activeSession?.emoji ?: "📚",
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = activeSession?.title ?: "Study Session",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            val displaySubtitle = activeSession?.focusTopic?.takeIf { it.isNotBlank() }
                                ?: activeSession?.description?.takeIf { it.isNotBlank() }
                                ?: "Slot: ${activeSession?.category ?: "Routine"}"
                            Text(
                                text = displaySubtitle,
                                fontSize = 12.sp,
                                color = Color(0xFF60A5FA),
                                maxLines = 1
                            )
                        }

                        val isCompleted = activeSession != null && completedSessionIds.contains(activeSession.id)
                        IconButton(onClick = {
                            activeSession?.let { onToggleSessionCompletion(it.id) }
                        }) {
                            Icon(
                                imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = if (isCompleted) "Completed" else "Mark Completed",
                                tint = if (isCompleted) Color(0xFF34D399) else Color(0xFF94A3B8),
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isLiveNow) "$remainingMinutesInActive minutes remaining in block"
                            else "Starts in $remainingMinutesInActive minutes • ${activeSession?.getFormattedTime() ?: ""}",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Strict Study Mode Guard Chip
                    val isStrictEffectivelyOn = isStrictStudyActive && isOngoingStudySlot
                    val isBreakEffectivelyOff = isStrictStudyActive && isOngoingBreakSlot

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                when {
                                    isStrictEffectivelyOn -> Color(0x3310B981)
                                    isBreakEffectivelyOff -> Color(0x3338BDF8)
                                    isStrictStudyActive -> Color(0x3310B981)
                                    else -> Color(0x33334155)
                                }
                            )
                            .border(
                                BorderStroke(
                                    1.dp,
                                    when {
                                        isStrictEffectivelyOn -> Color(0xFF10B981)
                                        isBreakEffectivelyOff -> Color(0xFF38BDF8)
                                        isStrictStudyActive -> Color(0xFF10B981)
                                        else -> Color(0x3360A5FA)
                                    }
                                ),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onOpenStrictStudyMode() }
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = when {
                                        isStrictEffectivelyOn -> "🛡️"
                                        isBreakEffectivelyOff -> "☕"
                                        isStrictStudyActive -> "🛡️"
                                        else -> "🔒"
                                    },
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when {
                                        isStrictEffectivelyOn -> "Strict Mode: ON (Study Slot Locked)"
                                        isBreakEffectivelyOff -> "Break Time: Strict Mode OFF (Unlocked)"
                                        isStrictStudyActive -> "Strict Study Guard: SCHEDULED"
                                        else -> "Strict Study Guard: OFF"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        isStrictEffectivelyOn -> Color(0xFF34D399)
                                        isBreakEffectivelyOff -> Color(0xFF7DD3FC)
                                        isStrictStudyActive -> Color(0xFF34D399)
                                        else -> Color(0xFFCBD5E1)
                                    }
                                )
                            }
                            Text(
                                text = "Settings →",
                                fontSize = 10.sp,
                                color = Color(0xFF60A5FA),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (!hasBatteryExemption) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x33F59E0B))
                                .border(BorderStroke(1.dp, Color(0xFFF59E0B)), RoundedCornerShape(10.dp))
                                .clickable { onOpenStrictStudyMode() }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("⚡", fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Allow background run (so alarms work when closed)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFDE68A)
                                    )
                                }
                                Text(
                                    text = "Enable →",
                                    fontSize = 10.sp,
                                    color = Color(0xFFFBBF24),
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "24/7 Background Activation: Active (Protected when app closed)",
                                fontSize = 10.sp,
                                color = Color(0xFF6EE7B7),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigateToTab(3) }, // Practice / Stopwatch
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A84FF)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Start Focus Stopwatch",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        OutlinedButton(
                            onClick = { onNavigateToTab(1) }, // Routine
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text("Full Schedule", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }

            // 3b. CORRECT STUDY TIME IN EVERY SECTION & DISTRACTION TRACKER CARD
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xCC0E192E),
                    borderColor = Color(0x333B82F6),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⏱️", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "STUDY TIME IN EVERY SECTION",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF60A5FA),
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "Open app OR start timer = Counts as study!",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x3310B981))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "⚡ LIVE COUNT",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Big study time summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = studySummary.getFormattedTotalStudy(),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Total Study Time (Since 12:00 AM)",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${studySummary.getDailyGoalProgressPercent()}% of 8h Goal",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 3 Metric Chips: Timer Time + In-App Time + Distraction Time
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Timer Time
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF172554))
                                .border(BorderStroke(1.dp, Color(0x3360A5FA)), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text("⏱️ Timer Time", fontSize = 9.sp, color = Color(0xFF93C5FD), fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(studySummary.getFormattedTimer(), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        // App Open Time
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF064E3B))
                                .border(BorderStroke(1.dp, Color(0x3334D399)), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text("📱 App In-Use", fontSize = 9.sp, color = Color(0xFFA7F3D0), fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(studySummary.getFormattedAppOpen(), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        // Distraction Time
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF450A0A))
                                .border(BorderStroke(1.dp, Color(0x33F87171)), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text("🛑 Distraction", fontSize = 9.sp, color = Color(0xFFFCA5A5), fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(studySummary.getFormattedDistraction(), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color(0x2660A5FA), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Section Breakdown Subheader
                    Text(
                        text = "TIMETABLE SECTIONS STUDY PROGRESS:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // List of sections with study time and distraction time
                    val sectionRecords = studySummary.sections
                    if (sectionRecords.isEmpty()) {
                        Text(
                            text = "No timetable sections scheduled yet.",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            sectionRecords.take(5).forEach { sec ->
                                val targetMinutes = sec.targetSeconds / 60
                                val targetFormatted = "${targetMinutes / 60}h ${targetMinutes % 60}m"
                                val percent = sec.getCompletionPercentage()

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xFF131F37))
                                        .border(BorderStroke(1.dp, Color(0x2638BDF8)), RoundedCornerShape(14.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Text(sec.emoji, fontSize = 15.sp)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = sec.title,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    maxLines = 1
                                                )
                                            }

                                            Text(
                                                text = "${sec.getFormattedStudyTime()} / $targetFormatted",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (sec.totalStudySeconds > 0) Color(0xFF34D399) else Color(0xFF94A3B8)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "⏱️ Timer: ${sec.getFormattedTimerTime()} • 📱 App: ${sec.getFormattedAppOpenTime()}",
                                                fontSize = 10.sp,
                                                color = Color(0xFF93C5FD)
                                            )

                                            if (sec.distractionSeconds > 0) {
                                                Text(
                                                    text = "🛑 Distraction: ${sec.getFormattedDistractionTime()}",
                                                    fontSize = 10.sp,
                                                    color = Color(0xFFFCA5A5),
                                                    fontWeight = FontWeight.Medium
                                                )
                                            } else {
                                                Text(
                                                    text = "✅ 0 distraction",
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF34D399)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        LinearProgressIndicator(
                                            progress = { (percent / 100f).coerceIn(0f, 1f) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp)
                                                .clip(RoundedCornerShape(2.dp)),
                                            color = if (percent >= 100) Color(0xFF10B981) else Color(0xFF38BDF8),
                                            trackColor = Color(0xFF1E293B)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onNavigateToTab(3) }, // Go to iOS Timer / Stopwatch
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            contentPadding = PaddingValues(vertical = 9.dp)
                        ) {
                            Text("⏱️ Start Timer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel?.refreshStudyTimeStats() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, Color(0x3360A5FA)),
                            contentPadding = PaddingValues(vertical = 9.dp)
                        ) {
                            Text("🔄 Refresh Count", fontSize = 11.sp)
                        }
                    }
                }
            }

            // 3c. APP SCREEN TIME TODAY ("How much time I saw which app")
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xCC1A1320),
                    borderColor = Color(0x33F43F5E),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📱", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "APP SCREEN TIME TODAY",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFFB7185),
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "How much time you saw each app today",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x33F43F5E))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "SCREEN TIME",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFDA4AF)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // App usage breakdown
                    val apps = studySummary.allAppsUsage.take(6)
                    if (apps.isEmpty()) {
                        Text(
                            text = "Grant Usage Access in Focus Blocker to view per-app screen time.",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            apps.forEach { app ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF231828))
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Text(app.iconEmoji, fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = app.appName,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = app.category,
                                                fontSize = 10.sp,
                                                color = Color(0xFF94A3B8)
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = app.getFormattedTime(),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                app.isStudyApp -> Color(0xFF34D399)
                                                app.isDistraction -> Color(0xFFF87171)
                                                else -> Color(0xFF93C5FD)
                                            }
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    when {
                                                        app.isStudyApp -> Color(0x3310B981)
                                                        app.isDistraction -> Color(0x33EF4444)
                                                        else -> Color(0x33334155)
                                                    }
                                                )
                                                .padding(horizontal = 5.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = when {
                                                    app.isStudyApp -> "STUDY"
                                                    app.isDistraction -> "DISTRACT"
                                                    else -> "APP"
                                                },
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when {
                                                    app.isStudyApp -> Color(0xFF34D399)
                                                    app.isDistraction -> Color(0xFFF87171)
                                                    else -> Color(0xFF94A3B8)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { onOpenStrictStudyMode() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                        contentPadding = PaddingValues(vertical = 9.dp)
                    ) {
                        Text("🛡️ Manage & Block Distraction Apps", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 3d. PIN HOME SCREEN WIDGETS CARD
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xCC111827),
                    borderColor = Color(0x33818CF8),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📌", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "HOME SCREEN WIDGETS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFA5B4FC),
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "Add widgets to see study time & screen time without opening app",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Widget 1: App Screen Time Widget
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1E1B4B))
                            .border(BorderStroke(1.dp, Color(0x33A5B4FC)), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "📱 App Screen Time Widget",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Shows which apps you used today and how much time on each app",
                                    fontSize = 10.sp,
                                    color = Color(0xFFC7D2FE)
                                )
                            }
                            Button(
                                onClick = {
                                    val pinned = viewModel?.requestPinAppScreenTimeWidget(context) ?: false
                                    if (pinned) {
                                        Toast.makeText(context, "Adding Screen Time Widget to Home Screen", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Long-press Home screen and choose App Screen Time Widget", Toast.LENGTH_LONG).show()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("+ Add", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Widget 2: Study Time Widget
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF064E3B))
                            .border(BorderStroke(1.dp, Color(0x3334D399)), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "📚 Study Time Widget",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Shows total study time, timer time, app open time & active section",
                                    fontSize = 10.sp,
                                    color = Color(0xFFA7F3D0)
                                )
                            }
                            Button(
                                onClick = {
                                    val pinned = viewModel?.requestPinStudyTimeWidget(context) ?: false
                                    if (pinned) {
                                        Toast.makeText(context, "Adding Study Time Widget to Home Screen", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Long-press Home screen and choose Study Time Widget", Toast.LENGTH_LONG).show()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("+ Add", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Widget 3: Ongoing Section Live Widget
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1E293B))
                            .border(BorderStroke(1.dp, Color(0x3394A3B8)), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚡ Ongoing Section Widget",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Live countdown card for ongoing timetable session",
                                    fontSize = 10.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                            Button(
                                onClick = {
                                    val pinned = viewModel?.requestPinOngoingWidget(context) ?: false
                                    if (pinned) {
                                        Toast.makeText(context, "Adding Ongoing Section Widget to Home Screen", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Long-press Home screen and choose Ongoing Section Widget", Toast.LENGTH_LONG).show()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("+ Add", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 4. 4 Quick Action Gradient Tiles (Screenshot 5)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Tile 1: Smart Practice (Indigo/Purple)
                        ActionTile(
                            title = "Smart\nPractice >",
                            subtitle = "Adaptive Question...",
                            icon = Icons.Default.TrackChanges,
                            gradient = Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFF6366F1))),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToTab(3) }
                        )

                        // Tile 2: YouTube Video Lectures (Crimson/Pink)
                        ActionTile(
                            title = "YouTube\nVideos >",
                            subtitle = "Paste & Watch Now",
                            icon = Icons.Default.PlayCircle,
                            gradient = Brush.linearGradient(listOf(Color(0xFFE11D48), Color(0xFFF43F5E))),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToTab(4) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Tile 3: Progress & Stats (Emerald/Green)
                        ActionTile(
                            title = "Progress &\nStats >",
                            subtitle = "Study Hours & Ac...",
                            icon = Icons.Default.TrendingUp,
                            gradient = Brush.linearGradient(listOf(Color(0xFF059669), Color(0xFF10B981))),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToTab(2) }
                        )

                        // Tile 4: Stopwatch (Slate/Dark)
                        ActionTile(
                            title = "Stopwatch >",
                            subtitle = "Track Study Hours",
                            icon = Icons.Default.Timer,
                            gradient = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF334155))),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToTab(3) }
                        )
                    }
                }
            }

            // 5. Today's Schedule Card (Screenshot 5)
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xB810172A),
                    borderColor = Color(0x2660A5FA)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = Color(0xFF60A5FA),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Today's Schedule",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Text(
                            text = "Edit Timetable >",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF60A5FA),
                            modifier = Modifier.clickable { onNavigateToTab(1) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    routineSessions.take(8).forEach { session ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x66182236))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = session.startTime,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF94A3B8)
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            // Colored Vertical Accent Bar
                            val accentColor = when (session.category.uppercase()) {
                                "MATHEMATICS", "MATHS" -> Color(0xFFF59E0B)
                                "PHYSICS" -> Color(0xFF38BDF8)
                                "CHEMISTRY" -> Color(0xFF34D399)
                                "WAKE", "WALKING" -> Color(0xFF84CC16)
                                else -> Color(0xFF818CF8)
                            }
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(24.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(accentColor)
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "${session.emoji} ${session.title}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )

                            IconButton(
                                onClick = { /* Toggle */ },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { onNavigateToTab(3) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    gradient: Brush,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(gradient)
            .border(BorderStroke(1.dp, Color(0x33FFFFFF)), RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0x33000000)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 10.dp)
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    lineHeight = 15.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = Color(0xCCFFFFFF),
                    maxLines = 1
                )
            }
        }
    }
}
