package com.example.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.data.repository.ParentTelemetryRepository
import com.example.service.FocusShieldManager
import com.example.ui.theme.IosBlue
import com.example.ui.theme.IosGreen
import com.example.ui.theme.IosOrange
import com.example.ui.theme.JeeReminderTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LockoutActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_ONGOING_SESSION = "extra_ongoing_session"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appName = intent.getStringExtra(EXTRA_APP_NAME) ?: "Distracting App"
        val packageName = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
        val ongoingSession = intent.getStringExtra(EXTRA_ONGOING_SESSION) ?: "JEE Study Session"

        setContent {
            JeeReminderTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    LockoutContent(
                        appName = appName,
                        packageName = packageName,
                        ongoingSession = ongoingSession,
                        onGoToTimetable = {
                            val mainIntent = Intent(this, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                                putExtra(MainActivity.EXTRA_NAV_TAB, 0) // Routine timetable
                            }
                            startActivity(mainIntent)
                            finish()
                        },
                        onGoToPractice = {
                            val mainIntent = Intent(this, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                                putExtra(MainActivity.EXTRA_NAV_TAB, 3) // JEE Hub / Practice
                            }
                            startActivity(mainIntent)
                            finish()
                        },
                        onEmergencyUnlock = {
                            FocusShieldManager.grantEmergencyBreak(this, 2)
                            CoroutineScope(Dispatchers.IO).launch {
                                try {
                                    ParentTelemetryRepository(applicationContext).pushDistractionLog(
                                        blockedAppName = appName,
                                        currentSlotName = ongoingSession,
                                        isEmergencyUnlock = true
                                    )
                                } catch (_: Exception) {}
                            }
                            Toast.makeText(this, "Emergency 2-minute break granted", Toast.LENGTH_SHORT).show()
                            finish()
                        }
                    )
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Redirect to Home screen instead of going back to the blocked app
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }
}

@Composable
private fun LockoutContent(
    appName: String,
    packageName: String,
    ongoingSession: String = "JEE Study Session",
    onGoToTimetable: () -> Unit,
    onGoToPractice: () -> Unit,
    onEmergencyUnlock: () -> Unit
) {
    var emergencyUnlocked by remember { mutableStateOf(false) }
    var mathAnswerInput by remember { mutableStateOf("") }
    var mathError by remember { mutableStateOf(false) }

    val num1 = remember { 14 }
    val num2 = remember { 17 }
    val correctAnswer = remember { num1 * num2 } // 238

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Large iOS Lock Icon
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1C1C1E))
                    .border(2.dp, IosOrange, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.HourglassTop,
                    contentDescription = "Screen Time Limit",
                    tint = IosOrange,
                    modifier = Modifier.size(46.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Time Limit Reached",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "$appName is locked during your study session.\n🎯 Ongoing: $ongoingSession\nStrict Mode is actively guarding your focus.",
                color = Color(0xFF8E8E93),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Motivation Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🎯 IIT JEE ADVANCED FOCUS",
                        color = IosOrange,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "\"Every 15 minutes of scrolling costs 1 Rank in IIT. Your dream branch is waiting for your consistency.\"",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Action: Return to Routine Timetable
            Button(
                onClick = onGoToTimetable,
                colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Return to JEE Timetable",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Secondary Action: Solve Questions Instead
            OutlinedButton(
                onClick = onGoToPractice,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(Icons.Default.TrackChanges, contentDescription = null, tint = IosGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Solve PYQ Practice Questions",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Emergency Break with Math Verification
            if (!emergencyUnlocked) {
                Text(
                    text = "Emergency 2-Minute Break (Solve Challenge)",
                    color = Color(0xFF8E8E93),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clickable { emergencyUnlocked = true }
                        .padding(8.dp)
                )
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Solve to Unlock: $num1 × $num2 = ?",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = mathAnswerInput,
                                onValueChange = { mathAnswerInput = it },
                                label = { Text("Answer") },
                                isError = mathError,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = IosOrange
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (mathAnswerInput.trim() == correctAnswer.toString()) {
                                        onEmergencyUnlock()
                                    } else {
                                        mathError = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = IosOrange)
                            ) {
                                Text("Verify")
                            }
                        }
                    }
                }
            }
        }
    }
}
