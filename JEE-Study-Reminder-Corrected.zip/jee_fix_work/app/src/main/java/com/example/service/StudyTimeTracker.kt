package com.example.service

import android.app.usage.UsageEvents
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.example.data.database.DefaultJeeData
import com.example.data.model.BlockedApp
import com.example.data.model.RoutineSession
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AppUsageRecord(
    val packageName: String,
    val appName: String,
    val iconEmoji: String,
    val foregroundMillis: Long,
    val isDistraction: Boolean,
    val isStudyApp: Boolean,
    val category: String
) {
    fun getFormattedTime(): String {
        val totalSec = foregroundMillis / 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            seconds > 0 -> "${seconds}s"
            else -> "0m"
        }
    }
}

data class SectionStudyRecord(
    val sectionId: Long,
    val title: String,
    val category: String,
    val emoji: String,
    val timeSpan: String,
    val isStudySlot: Boolean,
    val timerSeconds: Long,
    val appOpenSeconds: Long,
    val totalStudySeconds: Long,
    val distractionSeconds: Long,
    val targetSeconds: Long
) {
    fun getFormattedStudyTime(): String {
        val hours = totalStudySeconds / 3600
        val minutes = (totalStudySeconds % 3600) / 60
        val seconds = totalStudySeconds % 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            seconds > 0 -> "${seconds}s"
            else -> "0m"
        }
    }

    fun getFormattedTimerTime(): String {
        val hours = timerSeconds / 3600
        val minutes = (timerSeconds % 3600) / 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "${timerSeconds}s"
        }
    }

    fun getFormattedAppOpenTime(): String {
        val hours = appOpenSeconds / 3600
        val minutes = (appOpenSeconds % 3600) / 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "${appOpenSeconds}s"
        }
    }

    fun getFormattedDistractionTime(): String {
        val hours = distractionSeconds / 3600
        val minutes = (distractionSeconds % 3600) / 60
        val seconds = distractionSeconds % 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            seconds > 0 -> "${seconds}s"
            else -> "0m"
        }
    }

    fun getCompletionPercentage(): Int {
        if (targetSeconds <= 0) return 0
        return ((totalStudySeconds.toFloat() / targetSeconds.toFloat()) * 100).toInt().coerceIn(0, 100)
    }
}

data class DailyStudySummary(
    val date: String,
    val totalStudySeconds: Long,
    val timerSeconds: Long,
    val appOpenSeconds: Long,
    val distractionSeconds: Long,
    val topDistractionApps: List<AppUsageRecord>,
    val allAppsUsage: List<AppUsageRecord>,
    val sections: List<SectionStudyRecord>,
    val studyGoalMinutes: Int = 480, // 8 hours default goal
    val windowStartMillis: Long = 0L,
    val windowEndMillis: Long = 0L,
    val calculatedAtMillis: Long = System.currentTimeMillis(),
    val isArchivedDay: Boolean = false
) {
    fun getFormattedWindow(): String {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        val startStr = if (windowStartMillis > 0) sdf.format(Date(windowStartMillis)) else "12:00 AM"
        val endStr = if (isArchivedDay) {
            "11:59 PM (Full Day)"
        } else if (windowEndMillis > 0) {
            sdf.format(Date(windowEndMillis))
        } else {
            "Now"
        }
        return "$startStr – $endStr"
    }

    fun getFormattedCalculationTime(): String {
        val sdf = SimpleDateFormat("h:mm:ss a", Locale.getDefault())
        return sdf.format(Date(calculatedAtMillis))
    }

    fun getFormattedTotalStudy(): String {
        val hours = totalStudySeconds / 3600
        val minutes = (totalStudySeconds % 3600) / 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "${totalStudySeconds}s"
        }
    }

    fun getFormattedTimer(): String {
        val hours = timerSeconds / 3600
        val minutes = (timerSeconds % 3600) / 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "${timerSeconds}s"
        }
    }

    fun getFormattedAppOpen(): String {
        val hours = appOpenSeconds / 3600
        val minutes = (appOpenSeconds % 3600) / 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "${appOpenSeconds}s"
        }
    }

    fun getFormattedDistraction(): String {
        val hours = distractionSeconds / 3600
        val minutes = (distractionSeconds % 3600) / 60
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "${distractionSeconds}s"
        }
    }

    fun getDailyGoalProgressPercent(): Int {
        val goalSec = studyGoalMinutes * 60L
        if (goalSec <= 0) return 0
        return ((totalStudySeconds.toFloat() / goalSec.toFloat()) * 100).toInt().coerceIn(0, 100)
    }
}

object StudyTimeTracker {

    private const val PREFS_NAME = "jee_study_time_tracker_prefs"
    private var lastWidgetUpdateTime = 0L

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    // -------------------------------------------------------------
    // LIVE TICKING FOR APP OPEN & TIMER
    // -------------------------------------------------------------

    /**
     * Called continuously while JEE Reminder app is opened in foreground.
     * Accurately attributes study time to today and to the active section.
     */
    fun recordAppOpenTick(context: Context, deltaSeconds: Int = 1) {
        val today = getTodayDateString()
        val prefs = getPrefs(context)
        val editor = prefs.edit()

        // 1. Increment Today App Open Time
        val currentAppOpen = prefs.getLong("app_open_sec_$today", 0L) + deltaSeconds
        editor.putLong("app_open_sec_$today", currentAppOpen)

        // 2. Increment Today Total Study Time
        val currentTotalStudy = prefs.getLong("total_study_sec_$today", 0L) + deltaSeconds
        editor.putLong("total_study_sec_$today", currentTotalStudy)

        // 3. Increment for Current Active Timetable Section
        val (activeSession, isOngoing) = FocusShieldManager.getCurrentOngoingSession(context)
        if (activeSession != null && isOngoing) {
            val sectionKeyApp = "sec_${activeSession.id}_app_open_$today"
            val sectionKeyTotal = "sec_${activeSession.id}_total_study_$today"

            val secApp = prefs.getLong(sectionKeyApp, 0L) + deltaSeconds
            val secTotal = prefs.getLong(sectionKeyTotal, 0L) + deltaSeconds

            editor.putLong(sectionKeyApp, secApp)
            editor.putLong(sectionKeyTotal, secTotal)
        }

        editor.apply()
        throttleWidgetUpdate(context)
    }

    /**
     * Called continuously while a study timer or stopwatch is running.
     * Counts as study time for today and for the ongoing section.
     */
    fun recordTimerTick(context: Context, deltaSeconds: Int = 1) {
        val today = getTodayDateString()
        val prefs = getPrefs(context)
        val editor = prefs.edit()

        // 1. Increment Today Timer Study Time
        val currentTimer = prefs.getLong("timer_sec_$today", 0L) + deltaSeconds
        editor.putLong("timer_sec_$today", currentTimer)

        // 2. Increment Today Total Study Time
        val currentTotalStudy = prefs.getLong("total_study_sec_$today", 0L) + deltaSeconds
        editor.putLong("total_study_sec_$today", currentTotalStudy)

        // 3. Increment for Current Active Timetable Section
        val (activeSession, isOngoing) = FocusShieldManager.getCurrentOngoingSession(context)
        if (activeSession != null && isOngoing) {
            val sectionKeyTimer = "sec_${activeSession.id}_timer_$today"
            val sectionKeyTotal = "sec_${activeSession.id}_total_study_$today"

            val secTimer = prefs.getLong(sectionKeyTimer, 0L) + deltaSeconds
            val secTotal = prefs.getLong(sectionKeyTotal, 0L) + deltaSeconds

            editor.putLong(sectionKeyTimer, secTimer)
            editor.putLong(sectionKeyTotal, secTotal)
        }

        editor.apply()
        throttleWidgetUpdate(context)
    }

    /**
     * Called when a distraction app is detected in foreground during study.
     */
    fun recordDistractionTick(context: Context, packageName: String, deltaSeconds: Int = 1) {
        val today = getTodayDateString()
        val prefs = getPrefs(context)
        val editor = prefs.edit()

        // 1. Increment Today Total Distraction Time
        val currentDistraction = prefs.getLong("distraction_sec_$today", 0L) + deltaSeconds
        editor.putLong("distraction_sec_$today", currentDistraction)

        // 2. Increment for Active Section
        val (activeSession, isOngoing) = FocusShieldManager.getCurrentOngoingSession(context)
        if (activeSession != null && isOngoing) {
            val sectionKeyDistract = "sec_${activeSession.id}_distract_$today"
            val secDistract = prefs.getLong(sectionKeyDistract, 0L) + deltaSeconds
            editor.putLong(sectionKeyDistract, secDistract)
        }

        editor.apply()
        throttleWidgetUpdate(context)
    }

    // -------------------------------------------------------------
    // DATA RETRIEVAL: TODAY SUMMARY & SECTION BREAKDOWN
    // -------------------------------------------------------------

    fun getTodayStudySummary(context: Context): DailyStudySummary {
        val today = getTodayDateString()
        val prefs = getPrefs(context)

        var totalStudy = prefs.getLong("total_study_sec_$today", 0L)
        val timerSec = prefs.getLong("timer_sec_$today", 0L)
        var appOpenSec = prefs.getLong("app_open_sec_$today", 0L)
        var distractionSec = prefs.getLong("distraction_sec_$today", 0L)

        val startOfDay = getMidnightStartMillis()
        val now = System.currentTimeMillis()

        // Query OS UsageStats strictly from 12:00 AM today to now
        val allApps = getAppUsageStatsForWindow(context, startOfDay, now, today)
        val osStudyAppsSec = allApps.filter { it.isStudyApp }.sumOf { it.foregroundMillis / 1000 }
        if (osStudyAppsSec > 0) {
            val myAppUsage = allApps.firstOrNull { it.packageName == context.packageName }
            if (myAppUsage != null && myAppUsage.foregroundMillis > 0) {
                appOpenSec = myAppUsage.foregroundMillis / 1000
            }
            totalStudy = (timerSec + osStudyAppsSec).coerceAtLeast(totalStudy)
        }

        val osDistractionSec = allApps.filter { it.isDistraction }.sumOf { it.foregroundMillis / 1000 }
        if (osDistractionSec > distractionSec) {
            distractionSec = osDistractionSec
        }

        val topDistractions = allApps.filter { it.isDistraction }.take(6)
        val sections = getAllSectionsStudyRecords(context)

        return DailyStudySummary(
            date = today,
            totalStudySeconds = totalStudy,
            timerSeconds = timerSec,
            appOpenSeconds = appOpenSec,
            distractionSeconds = distractionSec,
            topDistractionApps = topDistractions,
            allAppsUsage = allApps,
            sections = sections,
            windowStartMillis = startOfDay,
            windowEndMillis = now,
            calculatedAtMillis = now,
            isArchivedDay = false
        )
    }

    fun getAllSectionsStudyRecords(context: Context): List<SectionStudyRecord> {
        val sessions = FocusShieldManager.getSyncedRoutineSessions(context)
        val today = getTodayDateString()
        val prefs = getPrefs(context)

        return sessions.map { session ->
            val secApp = prefs.getLong("sec_${session.id}_app_open_$today", 0L)
            val secTimer = prefs.getLong("sec_${session.id}_timer_$today", 0L)
            var secTotal = prefs.getLong("sec_${session.id}_total_study_$today", 0L)
            var secDistract = prefs.getLong("sec_${session.id}_distract_$today", 0L)

            // If timer or app was used, ensure total study reflects union
            if (secTotal < (secApp + secTimer) && (secApp > 0 || secTimer > 0)) {
                secTotal = secApp + secTimer
            }

            // Calculate target duration in seconds from startTime and endTime
            val targetSec = calculateSessionTargetSeconds(session.startTime, session.endTime)

            // Fallback or UsageEvents estimation if section has passed or is ongoing
            if (secDistract == 0L && FocusShieldManager.hasUsageStatsPermission(context)) {
                secDistract = estimateSectionDistractionFromUsage(context, session)
            }

            SectionStudyRecord(
                sectionId = session.id,
                title = session.title,
                category = session.category,
                emoji = session.emoji.ifBlank { "📚" },
                timeSpan = session.getFormattedTime(),
                isStudySlot = session.isStudySlot(),
                timerSeconds = secTimer,
                appOpenSeconds = secApp,
                totalStudySeconds = secTotal,
                distractionSeconds = secDistract,
                targetSeconds = targetSec
            )
        }
    }

    private fun calculateSessionTargetSeconds(start: String, end: String): Long {
        val startParts = start.split(":")
        val endParts = end.split(":")
        if (startParts.size >= 2 && endParts.size >= 2) {
            val startMin = (startParts[0].toIntOrNull() ?: 0) * 60 + (startParts[1].toIntOrNull() ?: 0)
            val endMin = (endParts[0].toIntOrNull() ?: 0) * 60 + (endParts[1].toIntOrNull() ?: 0)
            val diffMin = if (endMin >= startMin) endMin - startMin else (endMin + 1440 - startMin)
            return (diffMin.coerceAtLeast(15)) * 60L
        }
        return 3600L // default 1 hour
    }

    private fun estimateSectionDistractionFromUsage(context: Context, session: RoutineSession): Long {
        try {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return 0L
            val cal = Calendar.getInstance()
            val startParts = session.startTime.split(":")
            val endParts = session.endTime.split(":")
            if (startParts.size < 2 || endParts.size < 2) return 0L

            cal.set(Calendar.HOUR_OF_DAY, startParts[0].toIntOrNull() ?: 0)
            cal.set(Calendar.MINUTE, startParts[1].toIntOrNull() ?: 0)
            cal.set(Calendar.SECOND, 0)
            val sectionStart = cal.timeInMillis

            cal.set(Calendar.HOUR_OF_DAY, endParts[0].toIntOrNull() ?: 0)
            cal.set(Calendar.MINUTE, endParts[1].toIntOrNull() ?: 0)
            val sectionEnd = cal.timeInMillis

            val now = System.currentTimeMillis()
            if (now < sectionStart) return 0L // future session
            val queryEnd = Math.min(now, sectionEnd)

            val events = usageStatsManager.queryEvents(sectionStart, queryEnd) ?: return 0L
            val blockedPkgs = FocusShieldManager.getBlockedApps(context).filter { it.isBlocked }.map { it.packageName.lowercase() }.toSet()

            var totalDistractMillis = 0L
            var currentDistractPkg: String? = null
            var currentStartTime = 0L

            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val pkg = event.packageName?.lowercase() ?: continue
                if (blockedPkgs.contains(pkg)) {
                    if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                        currentDistractPkg = pkg
                        currentStartTime = event.timeStamp
                    } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED && currentDistractPkg == pkg) {
                        totalDistractMillis += (event.timeStamp - currentStartTime)
                        currentDistractPkg = null
                    }
                } else {
                    if (currentDistractPkg != null && event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                        totalDistractMillis += (event.timeStamp - currentStartTime)
                        currentDistractPkg = null
                    }
                }
            }
            if (currentDistractPkg != null) {
                totalDistractMillis += (queryEnd - currentStartTime).coerceAtLeast(0)
            }
            return (totalDistractMillis / 1000).coerceAtLeast(0)
        } catch (_: Exception) {
            return 0L
        }
    }

    // -------------------------------------------------------------
    // 12:00 AM DAILY APP USAGE TRACKER & MIDNIGHT ARCHIVE SYSTEM
    // -------------------------------------------------------------

    fun getMidnightStartMillis(calendar: Calendar = Calendar.getInstance()): Long {
        val cal = calendar.clone() as Calendar
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getMidnightEndMillis(calendar: Calendar = Calendar.getInstance()): Long {
        val cal = calendar.clone() as Calendar
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    /**
     * Queries OS UsageStats strictly for the interval [startTime, endTime].
     * For today: 12:00:00.000 AM to System.currentTimeMillis().
     * For past days: 12:00:00.000 AM to 11:59:59.999 PM.
     */
    fun getAppUsageStatsForWindow(
        context: Context,
        startTime: Long,
        endTime: Long,
        targetDateString: String = getTodayDateString()
    ): List<AppUsageRecord> {
        val pm = context.packageManager
        val blockedApps = FocusShieldManager.getBlockedApps(context)
        val blockedMap = blockedApps.associateBy { it.packageName.lowercase() }

        if (!FocusShieldManager.hasUsageStatsPermission(context)) {
            // Permission not granted yet: Return tracked in-app study time plus common apps guide
            val myAppSec = getPrefs(context).getLong("app_open_sec_$targetDateString", 0L)
            val myTimerSec = getPrefs(context).getLong("timer_sec_$targetDateString", 0L)
            val totalSec = (myAppSec + myTimerSec).coerceAtLeast(60L)

            val fallbackList = mutableListOf<AppUsageRecord>()
            fallbackList.add(
                AppUsageRecord(
                    packageName = context.packageName,
                    appName = "JEE Reminder",
                    iconEmoji = "📚",
                    foregroundMillis = totalSec * 1000L,
                    isDistraction = false,
                    isStudyApp = true,
                    category = "Study & Timetable"
                )
            )

            // Add placeholder guidance entries
            val defaults = FocusShieldManager.getDefaultBlockedApps().take(5)
            for (def in defaults) {
                fallbackList.add(
                    AppUsageRecord(
                        packageName = def.packageName,
                        appName = def.name,
                        iconEmoji = def.iconEmoji,
                        foregroundMillis = 0L,
                        isDistraction = def.isBlocked,
                        isStudyApp = false,
                        category = def.category
                    )
                )
            }
            return fallbackList
        }

        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return emptyList()

        try {
            val statsMap = usageStatsManager.queryAndAggregateUsageStats(startTime, endTime)
            val result = mutableListOf<AppUsageRecord>()

            for ((pkg, stats) in statsMap) {
                val totalTime = stats.totalTimeInForeground
                if (totalTime < 15_000L) continue // ignore under 15 seconds

                val pkgLower = pkg.lowercase()

                // Skip pure system components that users do not interact with as regular apps
                if (pkgLower.startsWith("com.android.systemui") ||
                    pkgLower == "android" ||
                    pkgLower.startsWith("com.google.android.inputmethod") ||
                    pkgLower.contains("system.service")
                ) {
                    continue
                }

                val isMyApp = (pkg == context.packageName)
                val blockedInfo = blockedMap[pkgLower]

                val isStudyApp = isMyApp || (blockedInfo?.isStudyApp == true)
                val isDistraction = if (isStudyApp) false else {
                    blockedInfo?.isBlocked ?: isPackageLikelyDistraction(pkgLower)
                }

                val appName = if (isMyApp) {
                    "JEE Reminder"
                } else {
                    blockedInfo?.name ?: try {
                        val appInfo = pm.getApplicationInfo(pkg, 0)
                        pm.getApplicationLabel(appInfo).toString()
                    } catch (_: Exception) {
                        formatPackageNameToLabel(pkg)
                    }
                }

                val iconEmoji = if (isMyApp) {
                    "📚"
                } else {
                    blockedInfo?.iconEmoji ?: getEmojiForPackage(pkgLower)
                }

                val category = if (isMyApp) {
                    "Study & Preparation"
                } else {
                    blockedInfo?.category ?: getCategoryForPackage(pkgLower)
                }

                result.add(
                    AppUsageRecord(
                        packageName = pkg,
                        appName = appName,
                        iconEmoji = iconEmoji,
                        foregroundMillis = totalTime,
                        isDistraction = isDistraction,
                        isStudyApp = isStudyApp,
                        category = category
                    )
                )
            }

            // Ensure JEE Reminder is always present in list even if UsageStats aggregation lag
            if (result.none { it.isStudyApp }) {
                val myAppSec = getPrefs(context).getLong("app_open_sec_$targetDateString", 0L)
                val myTimerSec = getPrefs(context).getLong("timer_sec_$targetDateString", 0L)
                val totalMillis = (myAppSec + myTimerSec).coerceAtLeast(30L) * 1000L

                result.add(
                    AppUsageRecord(
                        packageName = context.packageName,
                        appName = "JEE Reminder",
                        iconEmoji = "📚",
                        foregroundMillis = totalMillis,
                        isDistraction = false,
                        isStudyApp = true,
                        category = "Study & Timetable"
                    )
                )
            }

            return result.sortedByDescending { it.foregroundMillis }
        } catch (e: Exception) {
            Log.e("StudyTimeTracker", "Failed to query app usage stats for window $startTime -> $endTime", e)
            return emptyList()
        }
    }

    /**
     * Calculates app usage starting strictly from 12:00:00.000 AM today to now.
     */
    fun getAppUsageStatsToday(context: Context): List<AppUsageRecord> {
        val startOfDay = getMidnightStartMillis()
        val now = System.currentTimeMillis()
        return getAppUsageStatsForWindow(context, startOfDay, now, getTodayDateString())
    }

    /**
     * Executed at 12:00 AM (midnight) by AlarmManager via MidnightResetReceiver.
     * Accurately finalizes the previous day's 24-hour cycle (12:00:00 AM to 11:59:59 PM)
     * and archives it into permanent SharedPreferences storage.
     */
    fun performMidnightCalculationAndArchive(context: Context): DailyStudySummary {
        val yesterdayCal = Calendar.getInstance().apply {
            add(Calendar.DATE, -1)
        }
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val yesterdayString = sdf.format(yesterdayCal.time)

        val startOfYesterday = getMidnightStartMillis(yesterdayCal)
        val endOfYesterday = getMidnightEndMillis(yesterdayCal)

        val prefs = getPrefs(context)
        val timerSec = prefs.getLong("timer_sec_$yesterdayString", 0L)
        var appOpenSec = prefs.getLong("app_open_sec_$yesterdayString", 0L)
        var totalStudy = prefs.getLong("total_study_sec_$yesterdayString", 0L)
        var distractionSec = prefs.getLong("distraction_sec_$yesterdayString", 0L)

        val allApps = getAppUsageStatsForWindow(context, startOfYesterday, endOfYesterday, yesterdayString)
        val studyAppsSec = allApps.filter { it.isStudyApp }.sumOf { it.foregroundMillis / 1000 }
        if (studyAppsSec > 0) {
            val myAppUsage = allApps.firstOrNull { it.packageName == context.packageName }
            if (myAppUsage != null && myAppUsage.foregroundMillis > 0) {
                appOpenSec = myAppUsage.foregroundMillis / 1000
            }
            totalStudy = (timerSec + studyAppsSec).coerceAtLeast(totalStudy)
        }

        val osDistractionSec = allApps.filter { it.isDistraction }.sumOf { it.foregroundMillis / 1000 }
        if (osDistractionSec > distractionSec) {
            distractionSec = osDistractionSec
        }

        val summary = DailyStudySummary(
            date = yesterdayString,
            totalStudySeconds = totalStudy,
            timerSeconds = timerSec,
            appOpenSeconds = appOpenSec,
            distractionSeconds = distractionSec,
            topDistractionApps = allApps.filter { it.isDistraction }.take(6),
            allAppsUsage = allApps,
            sections = emptyList(),
            windowStartMillis = startOfYesterday,
            windowEndMillis = endOfYesterday,
            calculatedAtMillis = System.currentTimeMillis(),
            isArchivedDay = true
        )

        saveArchivedSummary(context, summary)
        return summary
    }

    fun saveArchivedSummary(context: Context, summary: DailyStudySummary) {
        try {
            val json = JSONObject().apply {
                put("date", summary.date)
                put("totalStudySeconds", summary.totalStudySeconds)
                put("timerSeconds", summary.timerSeconds)
                put("appOpenSeconds", summary.appOpenSeconds)
                put("distractionSeconds", summary.distractionSeconds)
                put("studyGoalMinutes", summary.studyGoalMinutes)
                put("windowStartMillis", summary.windowStartMillis)
                put("windowEndMillis", summary.windowEndMillis)
                put("calculatedAtMillis", summary.calculatedAtMillis)
                put("isArchivedDay", true)

                val appsArray = JSONArray()
                for (app in summary.allAppsUsage) {
                    val appObj = JSONObject().apply {
                        put("packageName", app.packageName)
                        put("appName", app.appName)
                        put("iconEmoji", app.iconEmoji)
                        put("foregroundMillis", app.foregroundMillis)
                        put("isDistraction", app.isDistraction)
                        put("isStudyApp", app.isStudyApp)
                        put("category", app.category)
                    }
                    appsArray.put(appObj)
                }
                put("allAppsUsage", appsArray)
            }

            val prefs = getPrefs(context)
            val dates = prefs.getStringSet("archived_dates_list", emptySet())?.toMutableSet() ?: mutableSetOf()
            dates.add(summary.date)

            prefs.edit()
                .putString("archive_summary_${summary.date}", json.toString())
                .putStringSet("archived_dates_list", dates)
                .apply()
            Log.d("StudyTimeTracker", "Successfully archived 12:00 AM summary for ${summary.date}")
        } catch (e: Exception) {
            Log.e("StudyTimeTracker", "Failed to archive summary for ${summary.date}", e)
        }
    }

    fun getArchivedSummary(context: Context, dateString: String): DailyStudySummary? {
        val prefs = getPrefs(context)
        val raw = prefs.getString("archive_summary_$dateString", null) ?: return null
        return try {
            val json = JSONObject(raw)
            val appsList = mutableListOf<AppUsageRecord>()
            val appsArray = json.optJSONArray("allAppsUsage")
            if (appsArray != null) {
                for (i in 0 until appsArray.length()) {
                    val o = appsArray.getJSONObject(i)
                    appsList.add(
                        AppUsageRecord(
                            packageName = o.optString("packageName"),
                            appName = o.optString("appName"),
                            iconEmoji = o.optString("iconEmoji", "📱"),
                            foregroundMillis = o.optLong("foregroundMillis"),
                            isDistraction = o.optBoolean("isDistraction"),
                            isStudyApp = o.optBoolean("isStudyApp"),
                            category = o.optString("category")
                        )
                    )
                }
            }
            DailyStudySummary(
                date = json.optString("date", dateString),
                totalStudySeconds = json.optLong("totalStudySeconds"),
                timerSeconds = json.optLong("timerSeconds"),
                appOpenSeconds = json.optLong("appOpenSeconds"),
                distractionSeconds = json.optLong("distractionSeconds"),
                topDistractionApps = appsList.filter { it.isDistraction }.take(6),
                allAppsUsage = appsList,
                sections = emptyList(),
                studyGoalMinutes = json.optInt("studyGoalMinutes", 480),
                windowStartMillis = json.optLong("windowStartMillis"),
                windowEndMillis = json.optLong("windowEndMillis"),
                calculatedAtMillis = json.optLong("calculatedAtMillis"),
                isArchivedDay = true
            )
        } catch (e: Exception) {
            Log.e("StudyTimeTracker", "Error deserializing archive for $dateString", e)
            null
        }
    }

    fun getArchivedDates(context: Context): List<String> {
        val prefs = getPrefs(context)
        val dates = prefs.getStringSet("archived_dates_list", emptySet()) ?: emptySet()
        return dates.toList().sortedDescending()
    }

    /**
     * Returns the 12:00 AM daily summary for any given dateString (format yyyy-MM-dd).
     * If dateString is today, returns live summary calculated from 12:00 AM today.
     * If dateString is in the past, returns the archived record, or retroactively calculates
     * for that 24-hour window (12:00 AM to 11:59:59 PM).
     */
    fun getDailyStudySummaryForDate(context: Context, dateString: String): DailyStudySummary {
        if (dateString == getTodayDateString()) {
            return getTodayStudySummary(context)
        }
        val existing = getArchivedSummary(context, dateString)
        if (existing != null) {
            return existing
        }
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.parse(dateString) ?: Date()
            val cal = Calendar.getInstance().apply { time = date }
            val startOfDay = getMidnightStartMillis(cal)
            val endOfDay = getMidnightEndMillis(cal)

            val prefs = getPrefs(context)
            val timerSec = prefs.getLong("timer_sec_$dateString", 0L)
            var appOpenSec = prefs.getLong("app_open_sec_$dateString", 0L)
            var totalStudy = prefs.getLong("total_study_sec_$dateString", 0L)
            var distractionSec = prefs.getLong("distraction_sec_$dateString", 0L)

            val allApps = getAppUsageStatsForWindow(context, startOfDay, endOfDay, dateString)
            val studyAppsSec = allApps.filter { it.isStudyApp }.sumOf { it.foregroundMillis / 1000 }
            if (studyAppsSec > 0) {
                val myAppUsage = allApps.firstOrNull { it.packageName == context.packageName }
                if (myAppUsage != null && myAppUsage.foregroundMillis > 0) {
                    appOpenSec = myAppUsage.foregroundMillis / 1000
                }
                totalStudy = (timerSec + studyAppsSec).coerceAtLeast(totalStudy)
            }

            val osDistractionSec = allApps.filter { it.isDistraction }.sumOf { it.foregroundMillis / 1000 }
            if (osDistractionSec > distractionSec) {
                distractionSec = osDistractionSec
            }

            val summary = DailyStudySummary(
                date = dateString,
                totalStudySeconds = totalStudy,
                timerSeconds = timerSec,
                appOpenSeconds = appOpenSec,
                distractionSeconds = distractionSec,
                topDistractionApps = allApps.filter { it.isDistraction }.take(6),
                allAppsUsage = allApps,
                sections = emptyList(),
                windowStartMillis = startOfDay,
                windowEndMillis = endOfDay,
                calculatedAtMillis = System.currentTimeMillis(),
                isArchivedDay = true
            )
            saveArchivedSummary(context, summary)
            summary
        } catch (e: Exception) {
            Log.e("StudyTimeTracker", "Failed to compute retroactive summary for $dateString", e)
            getTodayStudySummary(context)
        }
    }

    private fun isPackageLikelyDistraction(pkg: String): Boolean {
        return pkg.contains("youtube") ||
                pkg.contains("instagram") ||
                pkg.contains("facebook") ||
                pkg.contains("twitter") ||
                pkg.contains("tiktok") ||
                pkg.contains("snapchat") ||
                pkg.contains("reddit") ||
                pkg.contains("netflix") ||
                pkg.contains("prime") ||
                pkg.contains("game") ||
                pkg.contains("pubg") ||
                pkg.contains("freefire") ||
                pkg.contains("discord") ||
                pkg.contains("twitch")
    }

    private fun getEmojiForPackage(pkg: String): String {
        return when {
            pkg.contains("youtube") -> "▶️"
            pkg.contains("instagram") -> "📸"
            pkg.contains("snapchat") -> "👻"
            pkg.contains("twitter") -> "✖️"
            pkg.contains("facebook") -> "👤"
            pkg.contains("reddit") -> "🤖"
            pkg.contains("game") || pkg.contains("pubg") || pkg.contains("freefire") -> "🎮"
            pkg.contains("netflix") || pkg.contains("prime") || pkg.contains("video") -> "🎬"
            pkg.contains("chat") || pkg.contains("whatsapp") || pkg.contains("telegram") -> "💬"
            pkg.contains("chrome") || pkg.contains("browser") -> "🌐"
            pkg.contains("music") || pkg.contains("spotify") -> "🎵"
            else -> "📱"
        }
    }

    private fun getCategoryForPackage(pkg: String): String {
        return when {
            pkg.contains("game") || pkg.contains("pubg") || pkg.contains("freefire") -> "Games"
            pkg.contains("youtube") || pkg.contains("netflix") || pkg.contains("prime") || pkg.contains("video") -> "Streaming"
            pkg.contains("instagram") || pkg.contains("snapchat") || pkg.contains("twitter") || pkg.contains("facebook") || pkg.contains("reddit") -> "Social Media"
            pkg.contains("chat") || pkg.contains("whatsapp") || pkg.contains("telegram") -> "Messaging"
            pkg.contains("chrome") || pkg.contains("browser") -> "Browser"
            else -> "Installed App"
        }
    }

    private fun formatPackageNameToLabel(pkg: String): String {
        val parts = pkg.split(".")
        val raw = parts.lastOrNull()?.replaceFirstChar { it.uppercase() } ?: pkg
        return raw.replace("_", " ")
    }

    // -------------------------------------------------------------
    // WIDGET UPDATE PROPAGATION
    // -------------------------------------------------------------

    private fun throttleWidgetUpdate(context: Context) {
        val now = System.currentTimeMillis()
        if (now - lastWidgetUpdateTime > 15_000L) { // max once every 15s
            lastWidgetUpdateTime = now
            triggerWidgetsRefresh(context)
        }
    }

    fun triggerWidgetsRefresh(context: Context) {
        try {
            com.example.widget.OngoingSectionWidgetProvider.updateAllWidgets(context)
            com.example.widget.JeeRoutineWidgetProvider.updateAllWidgets(context)
            com.example.widget.StudyTimeWidgetProvider.updateAllWidgets(context)
            com.example.widget.AppScreenTimeWidgetProvider.updateAllWidgets(context)
        } catch (_: Exception) {}
    }
}
