package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_reminders")
data class StudyReminder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subject: String, // "PHYSICS", "CHEMISTRY", "MATHEMATICS", "FULL_MOCK", "GENERAL"
    val dueTimeMillis: Long,
    val priority: String, // "HIGH", "MEDIUM", "LOW"
    val isCompleted: Boolean = false,
    val reminderMinutesBefore: Int = 15,
    val recurrence: String = "ONCE", // "ONCE", "DAILY", "WEEKLY"
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
