package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FormulaCard
import com.example.data.model.MockTestRecord
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.ChemistryGreen
import com.example.ui.theme.JeeAccentGold
import com.example.ui.theme.JeeNavy
import com.example.ui.theme.JeePrimary
import com.example.ui.theme.MathsRed
import com.example.ui.theme.PhysicsBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MockTestAndFormulasScreen(
    mockTests: List<MockTestRecord>,
    formulas: List<FormulaCard>,
    onAddMockTest: (String, Int, Int, Int, Int, String) -> Unit,
    onDeleteMockTest: (MockTestRecord) -> Unit,
    onToggleBookmarkFormula: (FormulaCard) -> Unit,
    onAddFormula: (String, String, String, String, String) -> Unit,
    onDeleteFormula: (FormulaCard) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Mock Tests, 1 = Formula Sheets
    var showAddMockDialog by remember { mutableStateOf(false) }
    var showAddFormulaDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTab == 0) showAddMockDialog = true else showAddFormulaDialog = true
                },
                containerColor = JeePrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_mock_or_formula")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Item")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = "Mock Tests & High-Yield Formulas",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
            )

            Text(
                text = "Track marks, percentile targets, negative penalties & quick revision cards",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = JeePrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Mock Test Analyzer (${mockTests.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                    modifier = Modifier.testTag("tab_mock_tests")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Formula Deck (${formulas.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                    modifier = Modifier.testTag("tab_formula_deck")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTab == 0) {
                MockTestsTabContent(
                    mockTests = mockTests,
                    onDelete = onDeleteMockTest,
                    modifier = Modifier.weight(1f)
                )
            } else {
                FormulasTabContent(
                    formulas = formulas,
                    onToggleBookmark = onToggleBookmarkFormula,
                    onDelete = onDeleteFormula,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    if (showAddMockDialog) {
        AddMockTestDialog(
            onDismiss = { showAddMockDialog = false },
            onConfirm = { name, phy, chem, maths, neg, weak ->
                onAddMockTest(name, phy, chem, maths, neg, weak)
                showAddMockDialog = false
            }
        )
    }

    if (showAddFormulaDialog) {
        AddFormulaDialog(
            onDismiss = { showAddFormulaDialog = false },
            onConfirm = { subj, chap, title, formula, concept ->
                onAddFormula(subj, chap, title, formula, concept)
                showAddFormulaDialog = false
            }
        )
    }
}

@Composable
private fun MockTestsTabContent(
    mockTests: List<MockTestRecord>,
    onDelete: (MockTestRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    if (mockTests.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = "No mock tests logged yet. Tap '+' to record your score!",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = modifier
        ) {
            items(mockTests, key = { it.id }) { mock ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mock_card_${mock.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = mock.testName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = dateFormat.format(Date(mock.testDateMillis)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(JeeNavy)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${mock.totalScore} / ${mock.maxScore}",
                                        color = JeeAccentGold,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp
                                    )
                                }

                                IconButton(
                                    onClick = { onDelete(mock) },
                                    modifier = Modifier.size(32.dp).testTag("delete_mock_${mock.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Subject score breakdown
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ScoreMiniBadge("Physics", mock.physicsScore, PhysicsBlue, Modifier.weight(1f))
                            ScoreMiniBadge("Chemistry", mock.chemistryScore, ChemistryGreen, Modifier.weight(1f))
                            ScoreMiniBadge("Maths", mock.mathsScore, MathsRed, Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Est. Percentile: ${mock.estimatedPercentile}%ile",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = JeePrimary
                            )

                            if (mock.negativeMarks > 0) {
                                Text(
                                    text = "Negative Loss: -${mock.negativeMarks}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MathsRed
                                )
                            }
                        }

                        if (mock.weakAreas.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Weak Areas: ${mock.weakAreas}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}

@Composable
private fun ScoreMiniBadge(
    subject: String,
    score: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(vertical = 6.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = subject, fontSize = 10.sp, color = color, fontWeight = FontWeight.SemiBold)
            Text(text = "$score", fontSize = 13.sp, color = color, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun FormulasTabContent(
    formulas: List<FormulaCard>,
    onToggleBookmark: (FormulaCard) -> Unit,
    onDelete: (FormulaCard) -> Unit,
    modifier: Modifier = Modifier
) {
    var subjectFilter by remember { mutableStateOf("ALL") }

    val filteredFormulas = remember(formulas, subjectFilter) {
        when (subjectFilter) {
            "PHYSICS" -> formulas.filter { it.subject == "PHYSICS" }
            "CHEMISTRY" -> formulas.filter { it.subject == "CHEMISTRY" }
            "MATHEMATICS" -> formulas.filter { it.subject == "MATHEMATICS" }
            "BOOKMARKED" -> formulas.filter { it.isBookmarked }
            else -> formulas
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL" to "All", "PHYSICS" to "Physics", "CHEMISTRY" to "Chem", "MATHEMATICS" to "Maths", "BOOKMARKED" to "Saved").forEach { (key, label) ->
                FilterChip(
                    selected = subjectFilter == key,
                    onClick = { subjectFilter = key },
                    label = { Text(label, fontSize = 11.sp) }
                )
            }
        }

        if (filteredFormulas.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "No formulas found in this section.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredFormulas, key = { it.id }) { formula ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("formula_card_${formula.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SubjectBadge(subject = formula.subject)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = formula.chapter,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = { onToggleBookmark(formula) },
                                        modifier = Modifier.size(28.dp).testTag("bookmark_formula_${formula.id}")
                                    ) {
                                        Icon(
                                            imageVector = if (formula.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                            contentDescription = "Bookmark",
                                            tint = if (formula.isBookmarked) JeeAccentGold else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    if (formula.isCustom) {
                                        IconButton(
                                            onClick = { onDelete(formula) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "Delete",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = formula.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Formula Box (Monospace / High Contrast)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .border(1.dp, JeePrimary.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = formula.formulaLatex,
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = JeePrimary
                                )
                            }

                            if (formula.keyConcept.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "💡 ${formula.keyConcept}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(72.dp))
                }
            }
        }
    }
}

@Composable
fun AddMockTestDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, Int, Int, Int, Int, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var physicsScore by remember { mutableStateOf("") }
    var chemScore by remember { mutableStateOf("") }
    var mathsScore by remember { mutableStateOf("") }
    var negativeMarks by remember { mutableStateOf("0") }
    var weakAreas by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log JEE Mock Test Score", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Test Name (e.g. Allen CBT 05)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("mock_name_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = physicsScore,
                        onValueChange = { physicsScore = it.filter { c -> c.isDigit() } },
                        label = { Text("Phy (/100)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("mock_phy_input")
                    )
                    OutlinedTextField(
                        value = chemScore,
                        onValueChange = { chemScore = it.filter { c -> c.isDigit() } },
                        label = { Text("Chem (/100)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("mock_chem_input")
                    )
                    OutlinedTextField(
                        value = mathsScore,
                        onValueChange = { mathsScore = it.filter { c -> c.isDigit() } },
                        label = { Text("Maths (/100)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("mock_maths_input")
                    )
                }

                OutlinedTextField(
                    value = negativeMarks,
                    onValueChange = { negativeMarks = it.filter { c -> c.isDigit() } },
                    label = { Text("Negative Marks Penalty (e.g. 12)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = weakAreas,
                    onValueChange = { weakAreas = it },
                    label = { Text("Weak chapters / Mistakes analysis") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val phy = physicsScore.toIntOrNull() ?: 0
                        val chem = chemScore.toIntOrNull() ?: 0
                        val mat = mathsScore.toIntOrNull() ?: 0
                        val neg = negativeMarks.toIntOrNull() ?: 0
                        onConfirm(name.trim(), phy, chem, mat, neg, weakAreas.trim())
                    }
                },
                modifier = Modifier.testTag("save_mock_button")
            ) {
                Text("Save Score")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddFormulaDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String) -> Unit
) {
    var subject by remember { mutableStateOf("PHYSICS") }
    var chapter by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var formulaLatex by remember { mutableStateOf("") }
    var concept by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Quick Formula Card", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Subject:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("PHYSICS", "CHEMISTRY", "MATHEMATICS").forEach { subj ->
                        FilterChip(
                            selected = subject == subj,
                            onClick = { subject = subj },
                            label = { Text(subj.take(4), fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = chapter,
                    onValueChange = { chapter = it },
                    label = { Text("Chapter (e.g. Definite Integrals)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Formula Name / Rule") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("formula_title_input")
                )

                OutlinedTextField(
                    value = formulaLatex,
                    onValueChange = { formulaLatex = it },
                    label = { Text("Formula Text (e.g. ∫ e^x[f(x)+f'(x)]dx)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("formula_text_input")
                )

                OutlinedTextField(
                    value = concept,
                    onValueChange = { concept = it },
                    label = { Text("Key Note / Shortcut tip") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && formulaLatex.isNotBlank()) {
                        onConfirm(subject, chapter.trim(), title.trim(), formulaLatex.trim(), concept.trim())
                    }
                },
                modifier = Modifier.testTag("save_formula_button")
            ) {
                Text("Add Formula")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
