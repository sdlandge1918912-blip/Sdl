package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamEvent
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Visual countdown component that calculates and displays the days remaining
 * until the JEE 2028 exam date, including real-time Days, Hours, Minutes, and Seconds ticker,
 * preparation journey progress, milestone phases, and interactive exam switching.
 */
@Composable
fun JeeExamCountdownCard(
    targetExam: ExamEvent?,
    allExams: List<ExamEvent> = emptyList(),
    onSelectTargetExam: (Long) -> Unit = {},
    onUpdateExamDate: (ExamEvent, Long) -> Unit = { _, _ -> },
    onAddNewExamClick: () -> Unit = {},
    onStartStudyClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentTimeMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showExamMenu by remember { mutableStateOf(false) }

    // Live 1-second ticker for real-time countdown precision
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            currentTimeMillis = System.currentTimeMillis()
        }
    }

    // Default target: JEE Main 2028 (Session 1) on Jan 24, 2028 09:00 AM
    val defaultJee2028Millis = remember {
        Calendar.getInstance().apply {
            set(2028, Calendar.JANUARY, 24, 9, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val examTime = targetExam?.examDateMillis ?: defaultJee2028Millis
    val diffMillis = (examTime - currentTimeMillis).coerceAtLeast(0L)

    val totalDays = diffMillis / (24L * 3600 * 1000)
    val totalHours = (diffMillis % (24L * 3600 * 1000)) / (3600 * 1000)
    val totalMinutes = (diffMillis % (3600 * 1000)) / (60 * 1000)
    val totalSeconds = (diffMillis % (60 * 1000)) / 1000
    val totalWeeks = totalDays / 7

    // 2-Year Preparation Journey Calculation (Assuming April 1, 2026 as standard start of 2-year prep for JEE 2028)
    val journeyStartMillis = remember {
        Calendar.getInstance().apply {
            set(2026, Calendar.APRIL, 1, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val totalJourneyDuration = (examTime - journeyStartMillis).coerceAtLeast(1L)
    val elapsedJourneyDuration = (currentTimeMillis - journeyStartMillis).coerceAtLeast(0L)
    val journeyProgressPercent = ((elapsedJourneyDuration.toFloat() / totalJourneyDuration) * 100f).coerceIn(0f, 100f)

    // Formatted target exam date
    val examDateString = remember(examTime) {
        val sdf = SimpleDateFormat("EEEE, MMMM d, yyyy • hh:mm a", Locale.getDefault())
        sdf.format(Date(examTime))
    }

    val shortExamDateString = remember(examTime) {
        val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        sdf.format(Date(examTime))
    }

    // Dynamic preparation phase based on days remaining
    val prepPhase = when {
        totalDays > 365 -> "Phase 1: Class 11/12 Foundation & Concept Mastery"
        totalDays > 180 -> "Phase 2: Syllabus Completion & Deep Problem Solving"
        totalDays > 60 -> "Phase 3: High-Yield PYQs & Full Mock Series"
        totalDays > 0 -> "Phase 4: Final Sprint, Formula Revision & Speed Tests"
        else -> "Exam Day! Give Your Best! 🏆"
    }

    // Daily motivational quote for JEE 2028
    val motivationalQuotes = listOf(
        "\"Every concept mastered in 2026-2027 compounds into a top AIR rank in JEE 2028!\"",
        "\"Consistency beats brilliance. 6-8 hours of focused effort daily wins the IIT seat.\"",
        "\"Solve PYQs with curiosity. JEE 2028 is won one question at a time.\"",
        "\"Turn your weaknesses into strengths. You have over $totalDays days to build mastery!\""
    )
    val quoteIndex = (totalDays % motivationalQuotes.size).toInt()
    val dailyQuote = motivationalQuotes[quoteIndex]

    // Date picker for customizing target exam date
    val openDatePicker = {
        val cal = Calendar.getInstance().apply { timeInMillis = examTime }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 9, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (targetExam != null) {
                    onUpdateExamDate(targetExam, newCal.timeInMillis)
                }
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("jee_2028_countdown_card"),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F1E3D),
                            Color(0xFF0A1329),
                            Color(0xFF070C1A)
                        )
                    )
                )
                .border(
                    BorderStroke(1.5.dp, Brush.horizontalGradient(
                        listOf(Color(0xFF38BDF8), Color(0xFF6366F1), Color(0xFF38BDF8))
                    )),
                    RoundedCornerShape(26.dp)
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Mission Tag and Switcher Dropdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0x3338BDF8)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🎯", fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "JEE 2028 COUNTDOWN",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF38BDF8),
                                    letterSpacing = 1.2.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0x3310B981))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "LIVE",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF34D399)
                                    )
                                }
                            }
                            Text(
                                text = targetExam?.title ?: "JEE Main 2028 (Session 1)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Target Exam Switcher Button
                    Box {
                        Surface(
                            onClick = { showExamMenu = true },
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0x4D60A5FA)),
                            modifier = Modifier.testTag("switch_target_exam_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Tune,
                                    contentDescription = "Switch Target",
                                    tint = Color(0xFF60A5FA),
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Switch Target ▼",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF93C5FD)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showExamMenu,
                            onDismissRequest = { showExamMenu = false },
                            modifier = Modifier
                                .background(Color(0xFF1E293B))
                                .border(BorderStroke(1.dp, Color(0xFF334155)), RoundedCornerShape(12.dp))
                        ) {
                            allExams.forEach { exam ->
                                val isSelected = exam.id == targetExam?.id
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (isSelected) {
                                                    Icon(
                                                        Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = Color(0xFF38BDF8),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                }
                                                Text(
                                                    text = exam.title,
                                                    color = if (isSelected) Color(0xFF38BDF8) else Color.White,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    fontSize = 13.sp
                                                )
                                            }
                                            Text(
                                                text = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(exam.examDateMillis)),
                                                fontSize = 10.sp,
                                                color = Color(0xFF94A3B8)
                                            )
                                        }
                                    },
                                    onClick = {
                                        onSelectTargetExam(exam.id)
                                        showExamMenu = false
                                    }
                                )
                            }

                            HorizontalDivider(color = Color(0xFF334155))

                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.EditCalendar,
                                            contentDescription = null,
                                            tint = Color(0xFFF59E0B),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Pick Custom Exam Date", color = Color(0xFFF59E0B), fontSize = 12.sp)
                                    }
                                },
                                onClick = {
                                    showExamMenu = false
                                    openDatePicker()
                                }
                            )

                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Add,
                                            contentDescription = null,
                                            tint = Color(0xFF60A5FA),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Add Custom Milestone / Test", color = Color(0xFF60A5FA), fontSize = 12.sp)
                                    }
                                },
                                onClick = {
                                    showExamMenu = false
                                    onAddNewExamClick()
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Hero Countdown: DAYS REMAINING
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF132247), Color(0xFF172B5C))
                            )
                        )
                        .border(BorderStroke(1.dp, Color(0x3338BDF8)), RoundedCornerShape(20.dp))
                        .padding(vertical = 16.dp, horizontal = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "DAYS REMAINING",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8),
                            letterSpacing = 1.5.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Large Animated Hero Day Count
                        AnimatedContent(
                            targetState = totalDays,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "days_count_anim"
                        ) { days ->
                            Text(
                                text = "$days",
                                fontSize = 48.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF38BDF8),
                                letterSpacing = (-1).sp
                            )
                        }

                        Text(
                            text = "until $shortExamDateString ($totalWeeks Weeks Left)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Real-Time Sub-Ticker Units: Hours, Minutes, Seconds
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CountdownTickerBox(
                        value = "%02d".format(totalHours),
                        label = "HOURS",
                        modifier = Modifier.weight(1f)
                    )
                    CountdownTickerBox(
                        value = "%02d".format(totalMinutes),
                        label = "MINUTES",
                        modifier = Modifier.weight(1f)
                    )
                    CountdownTickerBox(
                        value = "%02d".format(totalSeconds),
                        label = "SECONDS",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Preparation Journey Progress Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF111C35))
                        .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🚀", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "2-Year JEE 2028 Roadmap",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Text(
                            text = "${journeyProgressPercent.toInt()}% elapsed",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { (journeyProgressPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF38BDF8),
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Start: Apr 2026",
                            fontSize = 9.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = "Target: $shortExamDateString",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF93C5FD)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Phase Badge
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1A1A2E))
                        .border(BorderStroke(1.dp, Color(0x33A855F7)), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📍", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = prepPhase,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFC084FC),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Motivational Quote
                Text(
                    text = dailyQuote,
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Action Row: Start Session & Edit Target Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onStartStudyClick,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("countdown_start_study_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2563EB)
                        ),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Start Study Session",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = openDatePicker,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("countdown_edit_date_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF93C5FD)),
                        border = BorderStroke(1.dp, Color(0x4D60A5FA)),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Set Custom Date",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CountdownTickerBox(
    value: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0F1A33))
            .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(14.dp))
            .padding(vertical = 10.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 0.5.sp
            )
        }
    }
}
