package com.example.data.dao

import androidx.room.*
import com.example.data.model.StudyReminder
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyReminderDao {
    @Query("SELECT * FROM study_reminders ORDER BY dueTimeMillis ASC")
    fun getAllReminders(): Flow<List<StudyReminder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: StudyReminder): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reminders: List<StudyReminder>)

    @Update
    suspend fun updateReminder(reminder: StudyReminder)

    @Delete
    suspend fun deleteReminder(reminder: StudyReminder)

    @Query("UPDATE study_reminders SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)

    @Query("SELECT COUNT(*) FROM study_reminders")
    suspend fun countReminders(): Int

    @Query("DELETE FROM study_reminders")
    suspend fun deleteAllReminders()
}
