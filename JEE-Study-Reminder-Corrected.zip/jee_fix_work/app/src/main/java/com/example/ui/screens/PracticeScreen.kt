package com.example.ui.screens

import android.graphics.Paint
import android.graphics.Typeface
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.components.GlassCard
import com.example.ui.viewmodel.JeeViewModel
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PracticeScreen(
    viewModel: JeeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val timerMode by viewModel.timerMode.collectAsState()
    val timerSubject by viewModel.selectedTimerSubject.collectAsState()
    val timerTopic by viewModel.timerTopic.collectAsState()
    val timerSeconds by viewModel.timerSeconds.collectAsState()
    val isRunning by viewModel.isTimerRunning.collectAsState()

    // Zen Desk Clock Fullscreen mode toggle
    var showZenDeskMode by remember { mutableStateOf(false) }

    // Smooth milliseconds interpolation while running
    var smoothHundredths by remember { mutableIntStateOf(0) }
    LaunchedEffect(isRunning) {
        if (isRunning) {
            val startMillis = System.currentTimeMillis()
            while (isRunning) {
                delay(30L)
                val elapsed = System.currentTimeMillis() - startMillis
                smoothHundredths = ((elapsed % 1000) / 10).toInt()
            }
        } else {
            smoothHundredths = 0
        }
    }

    // High-tech pulse animation for neon chronograph glow
    val infiniteTransition = rememberInfiniteTransition(label = "stopwatch_pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )

    // Laps state for practice sprints
    var laps by remember { mutableStateOf<List<Long>>(emptyList()) }

    val hours = timerSeconds / 3600
    val minutes = (timerSeconds % 3600) / 60
    val seconds = timerSeconds % 60

    val timeFormatted = if (hours > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    // Dial Progress calculation (cycles every 60s with sub-second precision)
    val dialProgress = remember(timerSeconds, smoothHundredths, isRunning) {
        val totalSecWithFrac = (timerSeconds % 60) + (smoothHundredths / 100f)
        (totalSecWithFrac / 60f).coerceIn(0f, 1f)
    }

    // Presets for quick focus sprints
    val sprintPresets = listOf(
        "Pomodoro (25m)" to 25 * 60,
        "JEE Sprint (45m)" to 45 * 60,
        "Subject Test (60m)" to 60 * 60,
        "Deep Focus (90m)" to 90 * 60,
        "CBT Mock (180m)" to 180 * 60
    )

    // Fastest lap detection
    val fastestLap = remember(laps) {
        if (laps.size >= 2) laps.minOrNull() else null
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Header Card: Sleek Glassmorphic Chronometer Bar with Zen Mode Trigger
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("practice_header_card"),
                shape = RoundedCornerShape(22.dp),
                backgroundColor = Color(0xCC0D1526),
                borderColor = Color(0x4038BDF8)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(if (isRunning) Color(0xFF10B981) else Color(0xFF38BDF8))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isRunning) "CHRONO ACTIVE" else "PRECISION STOPWATCH",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isRunning) Color(0xFF34D399) else Color(0xFF38BDF8),
                                letterSpacing = 0.8.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Tactical Study Chronograph",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Zen Fullscreen Desk Clock Trigger
                    IconButton(
                        onClick = { showZenDeskMode = true },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0x3338BDF8))
                            .border(BorderStroke(1.2.dp, Color(0x6638BDF8)), CircleShape)
                            .testTag("zen_desk_mode_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = "Zen Desk Mode",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // 2. HERO CARD: TACTICAL STUDY CHRONOGRAPH PRECISION STOPWATCH WITH GLASS EFFECT
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("practice_stopwatch_hero_card"),
                shape = RoundedCornerShape(28.dp),
                backgroundColor = Color(0xCC080E1C),
                borderColor = if (isRunning) Color(0x6638BDF8) else Color(0x3360A5FA),
                borderWidth = if (isRunning) 1.5.dp else 1.dp,
                contentPadding = PaddingValues(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Sub-Header row inside hero card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "⏱️", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CIRCULAR CHRONOGRAPH",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF38BDF8),
                                letterSpacing = 0.8.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x3338BDF8))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Glass Edition",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF93C5FD)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // THE CIRCULAR CHRONOGRAPH STOPWATCH WITH GLASS EFFECT
                    CircularChronographGlassStopwatch(
                        timeFormatted = timeFormatted,
                        smoothHundredths = smoothHundredths,
                        dialProgress = dialProgress,
                        isRunning = isRunning,
                        timerSeconds = timerSeconds,
                        timerSubject = timerSubject,
                        timerTopic = timerTopic,
                        pulseGlow = pulseGlow,
                        dialSize = 275.dp,
                        showTopic = true
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Tactical Chronograph Action Buttons (Reset/Lap, Giant Glow Play/Pause, Save)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: Lap / Reset Button
                        val canReset = timerSeconds > 0
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(Color(0x801E293B))
                                .border(BorderStroke(1.2.dp, Color(0x4038BDF8)), CircleShape)
                                .clickable {
                                    if (isRunning) {
                                        // Record Lap
                                        val currentTotal = (timerSeconds * 1000L) + (smoothHundredths * 10L)
                                        laps = listOf(currentTotal) + laps
                                        Toast.makeText(context, "Lap ${laps.size} Recorded! 🏁", Toast.LENGTH_SHORT).show()
                                    } else {
                                        // Reset
                                        viewModel.resetTimer()
                                        laps = emptyList()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Default.Flag else Icons.Default.Refresh,
                                    contentDescription = if (isRunning) "Lap" else "Reset",
                                    tint = if (isRunning || canReset) Color.White else Color(0xFF64748B),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (isRunning) "Lap" else "Reset",
                                    fontSize = 9.sp,
                                    color = Color(0xFF94A3B8),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Center: Giant Glowing Play / Pause Button with Pulsing Neon Shadow
                        Box(
                            modifier = Modifier
                                .size(82.dp)
                                .shadow(
                                    elevation = 24.dp,
                                    shape = CircleShape,
                                    spotColor = if (isRunning) Color(0xFFEF4444) else Color(0xFF38BDF8)
                                )
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        if (isRunning) listOf(Color(0xFFE11D48), Color(0xFFBE123C))
                                        else listOf(Color(0xFF2563EB), Color(0xFF0284C7))
                                    )
                                )
                                .border(BorderStroke(2.dp, Color(0x80FFFFFF)), CircleShape)
                                .clickable { viewModel.toggleTimer() }
                                .testTag("timer_toggle_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Toggle Timer",
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        // Right: Save / Log Session Button
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(Color(0x80064E3B))
                                .border(BorderStroke(1.2.dp, Color(0x6634D399)), CircleShape)
                                .clickable {
                                    viewModel.saveTimerSession()
                                    Toast.makeText(context, "Session Saved to Study Log! 🎯", Toast.LENGTH_SHORT).show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Save Session",
                                    tint = Color(0xFF34D399),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Save",
                                    fontSize = 9.sp,
                                    color = Color(0xFF34D399),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 3. Mode Selector (Stopwatch vs Focus Sprint) in Frosted Glass Capsule
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x800D1526))
                    .border(BorderStroke(1.dp, Color(0x3360A5FA)), RoundedCornerShape(20.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (timerMode == "Stopwatch") Color(0xFF2563EB) else Color.Transparent)
                        .clickable { viewModel.setTimerMode("Stopwatch") }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = if (timerMode == "Stopwatch") Color.White else Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Stopwatch (Chrono)",
                            fontSize = 12.sp,
                            fontWeight = if (timerMode == "Stopwatch") FontWeight.ExtraBold else FontWeight.Medium,
                            color = if (timerMode == "Stopwatch") Color.White else Color(0xFF94A3B8)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (timerMode == "Sprint") Color(0xFF2563EB) else Color.Transparent)
                        .clickable { viewModel.setTimerMode("Sprint") }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = null,
                            tint = if (timerMode == "Sprint") Color.White else Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Sprint Timer (Goal)",
                            fontSize = 12.sp,
                            fontWeight = if (timerMode == "Sprint") FontWeight.ExtraBold else FontWeight.Medium,
                            color = if (timerMode == "Sprint") Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // 4. Subject Selection in Translucent Frosted Glass
            Column {
                Text(
                    text = "TARGET SUBJECT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFA5B4FC),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val subjects = listOf(
                        Triple("Physics", "⚡", Color(0xFF38BDF8)),
                        Triple("Chemistry", "🧪", Color(0xFF34D399)),
                        Triple("Mathematics", "📐", Color(0xFFFBBF24))
                    )

                    subjects.forEach { (name, emoji, accentColor) ->
                        val isSelected = timerSubject.equals(name, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (isSelected) Color(0x4D1E3A8A) else Color(0x660D1526))
                                .border(
                                    BorderStroke(
                                        if (isSelected) 1.5.dp else 1.dp,
                                        if (isSelected) accentColor else Color(0x2660A5FA)
                                    ),
                                    RoundedCornerShape(18.dp)
                                )
                                .clickable { viewModel.setTimerSubject(name) }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(text = emoji, fontSize = 20.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = name,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }

            // 5. Topic / Chapter Input in Translucent Glass
            OutlinedTextField(
                value = timerTopic,
                onValueChange = { viewModel.setTimerTopic(it) },
                placeholder = {
                    Text(
                        text = "Topic / Chapter (e.g. Rotational Dynamics, Chemical Bonding...)",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xB8090E1A),
                    unfocusedContainerColor = Color(0x80090E1A),
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0x3360A5FA),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                },
                trailingIcon = {
                    if (timerTopic.isNotBlank()) {
                        IconButton(onClick = { viewModel.setTimerTopic("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            )

            // 6. Popular Study Sprint Presets (1-Tap Activation)
            Column {
                Text(
                    text = "POPULAR STUDY SPRINTS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFA5B4FC),
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    sprintPresets.take(3).forEach { (presetName, secs) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x660D1526))
                                .border(BorderStroke(1.dp, Color(0x3360A5FA)), RoundedCornerShape(16.dp))
                                .clickable {
                                    viewModel.setTimerMode("Sprint")
                                    Toast.makeText(context, "Selected: $presetName", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = presetName.substringBefore(" ("),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // 7. Laps / Splits Table (if laps recorded) with Best Lap Tag
            if (laps.isNotEmpty()) {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stopwatch_laps_card"),
                    shape = RoundedCornerShape(22.dp),
                    backgroundColor = Color(0xCC0D1526),
                    borderColor = Color(0x3360A5FA)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🏁", fontSize = 15.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "QUESTION & SPEED LAPS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF38BDF8),
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Text(
                                text = "${laps.size} recorded",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        laps.take(8).forEachIndexed { idx, lapMillis ->
                            val lapNum = laps.size - idx
                            val lapMin = (lapMillis / 1000) / 60
                            val lapSec = (lapMillis / 1000) % 60
                            val lapHundredth = (lapMillis % 1000) / 10
                            val isFastest = fastestLap != null && lapMillis == fastestLap

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(if (isFastest) Color(0xFF059669) else Color(0xFF1E293B)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = "$lapNum", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Split #$lapNum",
                                        fontSize = 13.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                    if (isFastest) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0x3310B981))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("⚡ FASTEST", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                                        }
                                    }
                                }

                                Text(
                                    text = "%02d:%02d.%02d".format(lapMin, lapSec, lapHundredth),
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFastest) Color(0xFF34D399) else Color(0xFF93C5FD)
                                )
                            }

                            if (idx < laps.size - 1) {
                                HorizontalDivider(color = Color(0x1AFFFFFF), thickness = 1.dp)
                            }
                        }
                    }
                }
            }

            // 8. Study Time Statistics in Frosted Glass
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                backgroundColor = Color(0xCC0D1526),
                borderColor = Color(0x3360A5FA)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8)
                        )
                        Text(
                            text = "PRACTICE STUDY LOG",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFA5B4FC),
                            letterSpacing = 0.5.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Today's Focus Stat Tile
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x66182236))
                                .border(BorderStroke(1.dp, Color(0x2660A5FA)), RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Column {
                                Text(
                                    text = "CURRENT SESSION",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = "%.1f".format(hours.toFloat() + minutes.toFloat() / 60f),
                                        fontSize = 26.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "hrs",
                                        fontSize = 12.sp,
                                        color = Color(0xFF38BDF8),
                                        modifier = Modifier.padding(bottom = 3.dp)
                                    )
                                }
                            }
                        }

                        // Efficiency Stat Tile
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x66182236))
                                .border(BorderStroke(1.dp, Color(0x2610B981)), RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Column {
                                Text(
                                    text = "ACTIVE SUBJECT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = timerSubject,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF34D399)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }

        // FULLSCREEN ZEN DESK MODE DIALOG (With the full Circular Chronograph Stopwatch Glass Dial!)
        if (showZenDeskMode) {
            Dialog(
                onDismissRequest = { showZenDeskMode = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xEE0B172E),
                                    Color(0xF5060E1E),
                                    Color(0xFA030712)
                                )
                            )
                        )
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val responsiveDial = (maxHeight * 0.44f).coerceIn(240.dp, 310.dp)

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Top Bar in Zen Mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0x550F172A))
                                .border(BorderStroke(1.2.dp, Color(0x4038BDF8)), RoundedCornerShape(18.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(9.dp)
                                        .clip(CircleShape)
                                        .background(if (isRunning) Color(0xFF34D399) else Color(0xFF94A3B8))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ZEN DESK CHRONO • ${timerSubject.uppercase()}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF38BDF8),
                                    letterSpacing = 1.sp
                                )
                            }

                            IconButton(
                                onClick = { showZenDeskMode = false },
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x2BFFFFFF))
                                    .border(BorderStroke(1.dp, Color(0x33FFFFFF)), CircleShape)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Exit Zen Mode", tint = Color.White)
                            }
                        }

                        // Massive Circular Chronograph Stopwatch with Glass Effect (Full Hero Dial with ambient backlight)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            // Ambient cyan backlight halo behind the glass chronograph
                            Box(
                                modifier = Modifier
                                    .size(responsiveDial + 40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(
                                                if (isRunning) Color(0x3310B981) else Color(0x2838BDF8),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            CircularChronographGlassStopwatch(
                                timeFormatted = timeFormatted,
                                smoothHundredths = smoothHundredths,
                                dialProgress = dialProgress,
                                isRunning = isRunning,
                                timerSeconds = timerSeconds,
                                timerSubject = timerSubject,
                                timerTopic = timerTopic,
                                pulseGlow = pulseGlow,
                                dialSize = responsiveDial,
                                showTopic = true
                            )
                        }

                        // Controls at bottom with Frosted Glass Buttons
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Lap / Reset Button
                            IconButton(
                                onClick = {
                                    if (isRunning) {
                                        val currentTotal = (timerSeconds * 1000L) + (smoothHundredths * 10L)
                                        laps = listOf(currentTotal) + laps
                                        Toast.makeText(context, "Lap ${laps.size} Recorded! 🏁", Toast.LENGTH_SHORT).show()
                                    } else {
                                        viewModel.resetTimer()
                                        laps = emptyList()
                                    }
                                },
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x801E293B))
                                    .border(BorderStroke(1.2.dp, Color(0x4038BDF8)), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Default.Flag else Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            // Giant Glowing Play / Pause
                            IconButton(
                                onClick = { viewModel.toggleTimer() },
                                modifier = Modifier
                                    .size(90.dp)
                                    .shadow(
                                        elevation = 28.dp,
                                        shape = CircleShape,
                                        spotColor = if (isRunning) Color(0xFFEF4444) else Color(0xFF38BDF8)
                                    )
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            if (isRunning) listOf(Color(0xFFE11D48), Color(0xFFBE123C))
                                            else listOf(Color(0xFF2563EB), Color(0xFF0284C7))
                                        )
                                    )
                                    .border(BorderStroke(2.dp, Color(0x99FFFFFF)), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(44.dp)
                                )
                            }

                            // Save
                            IconButton(
                                onClick = {
                                    viewModel.saveTimerSession()
                                    Toast.makeText(context, "Session Saved to Study Log! 🎯", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x80064E3B))
                                    .border(BorderStroke(1.2.dp, Color(0x6634D399)), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF34D399),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * High-End Circular Chronograph Stopwatch with Glass Effect
 * Features:
 * - Convex luxury sapphire glass crystal reflection highlight with 3D physical depth
 * - Outer brushed frosted metallic tachymeter ring with precision tick marks (1/5th second & 1-second ticks)
 * - Luminous 60, 15, 30, 45 numeral markers and glowing hour dots
 * - Secondary 30-Minute Elapsed Mini Chronograph Sub-Dial with animated minute hand
 * - High-precision sweep needle with counterweight tail and jeweled multi-ring metallic pivot hub (always visible!)
 * - Multi-stop sweeping neon laser gradient arc with orbital pulsar bead
 * - High-contrast digital monospace chronograph readout with glowing milliseconds
 */
@Composable
fun CircularChronographGlassStopwatch(
    timeFormatted: String,
    smoothHundredths: Int,
    dialProgress: Float,
    isRunning: Boolean,
    timerSeconds: Long,
    timerSubject: String,
    timerTopic: String,
    pulseGlow: Float,
    modifier: Modifier = Modifier,
    dialSize: Dp = 275.dp,
    showTopic: Boolean = true
) {
    Box(
        modifier = modifier
            .size(dialSize)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0x381E3A8A),
                        Color(0x550F172A),
                        Color(0xB3030712)
                    )
                )
            )
            .border(
                BorderStroke(
                    1.8.dp,
                    Brush.sweepGradient(
                        listOf(
                            Color(0x8038BDF8),
                            Color(0x3360A5FA),
                            Color(0xCC38BDF8),
                            Color(0x2694A3B8),
                            Color(0x8038BDF8)
                        )
                    )
                ),
                CircleShape
            )
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 9.dp.toPx()
            val radius = (size.minDimension - strokeWidth) / 2f - 4.dp.toPx()
            val center = Offset(size.width / 2f, size.height / 2f)

            // 1. Frosted Glass Outer Bezel Track
            drawCircle(
                color = Color(0x331E293B),
                radius = radius,
                center = center,
                style = Stroke(width = strokeWidth)
            )

            // 2. Secondary Inner Frosted Track
            drawCircle(
                color = Color(0x1F38BDF8),
                radius = radius - 15.dp.toPx(),
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )

            // 3. Convex Luxury Sapphire Crystal Reflection Highlight
            drawArc(
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0x40FFFFFF),
                        Color(0x12FFFFFF),
                        Color(0x00FFFFFF)
                    )
                ),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = true,
                size = Size(size.width * 0.92f, size.height * 0.46f),
                topLeft = Offset(size.width * 0.04f, size.height * 0.06f)
            )

            // 4. Precision 60-Second Chronograph Tick Marks & Luminous Numbers
            val cardinalPaint = Paint().apply {
                color = android.graphics.Color.argb(255, 56, 189, 248)
                textSize = 9.5.dp.toPx()
                textAlign = Paint.Align.CENTER
                typeface = Typeface.DEFAULT_BOLD
            }

            for (i in 0 until 60) {
                val angle = (i * 6.0 - 90.0) * (PI / 180.0)
                val isQuarter = i % 15 == 0
                val isMajor = i % 5 == 0

                val tickLen = when {
                    isQuarter -> 10.dp.toPx()
                    isMajor -> 7.dp.toPx()
                    else -> 3.5.dp.toPx()
                }
                val tickColor = when {
                    isQuarter -> Color(0xFF38BDF8)
                    isMajor -> Color(0xCC93C5FD)
                    else -> Color(0x3364748B)
                }
                val tickStroke = when {
                    isQuarter -> 2.5.dp.toPx()
                    isMajor -> 1.8.dp.toPx()
                    else -> 1.dp.toPx()
                }

                val innerR = radius - 10.dp.toPx()
                val startP = Offset(
                    x = center.x + innerR * cos(angle).toFloat(),
                    y = center.y + innerR * sin(angle).toFloat()
                )
                val endP = Offset(
                    x = center.x + (innerR - tickLen) * cos(angle).toFloat(),
                    y = center.y + (innerR - tickLen) * sin(angle).toFloat()
                )
                drawLine(
                    color = tickColor,
                    start = startP,
                    end = endP,
                    strokeWidth = tickStroke,
                    cap = StrokeCap.Round
                )

                // Luminous dots at major 5-second marks
                if (isMajor && !isQuarter) {
                    val dotR = innerR - tickLen - 5.dp.toPx()
                    drawCircle(
                        color = Color(0x6638BDF8),
                        radius = 1.8.dp.toPx(),
                        center = Offset(
                            x = center.x + dotR * cos(angle).toFloat(),
                            y = center.y + dotR * sin(angle).toFloat()
                        )
                    )
                }

                // Draw numbers at major 15s marks (60, 15, 30, 45)
                if (isQuarter) {
                    val labelR = innerR - tickLen - 8.dp.toPx()
                    val textX = center.x + labelR * cos(angle).toFloat()
                    val textY = center.y + labelR * sin(angle).toFloat() + 3.5.dp.toPx()
                    val label = if (i == 0) "60" else i.toString()
                    drawContext.canvas.nativeCanvas.drawText(label, textX, textY, cardinalPaint)
                }
            }

            // 5. Secondary 30-Minute Elapsed Chronograph Sub-Dial
            val subDialCenter = Offset(center.x, center.y - radius * 0.44f)
            val subDialRadius = 22.dp.toPx()
            // Sub-dial rim
            drawCircle(
                color = Color(0x2838BDF8),
                radius = subDialRadius,
                center = subDialCenter,
                style = Stroke(width = 1.2.dp.toPx())
            )
            // Sub-dial marks (0, 10, 20, 30 min)
            val subPaint = Paint().apply {
                color = android.graphics.Color.argb(180, 148, 163, 184)
                textSize = 6.dp.toPx()
                textAlign = Paint.Align.CENTER
                typeface = Typeface.DEFAULT_BOLD
            }
            listOf(0 to "30", 15 to "15").forEach { (idx, lbl) ->
                val ang = (idx * 12.0 - 90.0) * (PI / 180.0)
                val tx = subDialCenter.x + (subDialRadius - 6.dp.toPx()) * cos(ang).toFloat()
                val ty = subDialCenter.y + (subDialRadius - 6.dp.toPx()) * sin(ang).toFloat() + 2.dp.toPx()
                drawContext.canvas.nativeCanvas.drawText(lbl, tx, ty, subPaint)
            }
            // Sub-dial elapsed minute needle
            val elapsedMinutes = (timerSeconds / 60) % 30
            val subNeedleDegrees = (elapsedMinutes / 30f) * 360f - 90f
            val subNeedleAngle = subNeedleDegrees * (PI / 180.0)
            val subNeedleTip = Offset(
                x = subDialCenter.x + (subDialRadius - 4.dp.toPx()) * cos(subNeedleAngle).toFloat(),
                y = subDialCenter.y + (subDialRadius - 4.dp.toPx()) * sin(subNeedleAngle).toFloat()
            )
            drawLine(
                color = Color(0xFF38BDF8),
                start = subDialCenter,
                end = subNeedleTip,
                strokeWidth = 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(color = Color.White, radius = 2.dp.toPx(), center = subDialCenter)

            // 6. Sweeping Neon Multi-Stop Gradient Arc (When active or elapsed)
            val sweepAngle = 360f * dialProgress
            if (isRunning || timerSeconds > 0) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color(0xFF00F0FF),
                            Color(0xFF3B82F6),
                            Color(0xFF8B5CF6),
                            Color(0xFFEC4899),
                            Color(0xFF10B981),
                            Color(0xFF00F0FF)
                        )
                    ),
                    startAngle = -90f,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Orbital Pulsar Glowing Bead
                val beadAngle = (sweepAngle - 90.0) * (PI / 180.0)
                val beadCenter = Offset(
                    x = center.x + radius * cos(beadAngle).toFloat(),
                    y = center.y + radius * sin(beadAngle).toFloat()
                )
                // Outer breathing glow
                drawCircle(
                    color = Color(0x6638BDF8),
                    radius = 11.dp.toPx() * if (isRunning) pulseGlow else 1f,
                    center = beadCenter
                )
                // Middle vibrant cyan bead
                drawCircle(
                    color = Color(0xFF00F0FF),
                    radius = 5.5.dp.toPx(),
                    center = beadCenter
                )
                // Core pure white sparkle
                drawCircle(
                    color = Color.White,
                    radius = 2.8.dp.toPx(),
                    center = beadCenter
                )
            } else {
                // Subtle static cyan glow marker at 12 o'clock
                drawCircle(
                    color = Color(0x4038BDF8),
                    radius = 4.dp.toPx(),
                    center = Offset(center.x, center.y - radius)
                )
            }

            // 7. Razor-Sharp Chronograph Sweep Hand (ALWAYS VISIBLE!)
            // When timer is reset/zero, needle points straight at 12 o'clock (-90 degrees)
            val needleDegrees = if (isRunning || timerSeconds > 0) (sweepAngle - 90f) else -90f
            val needleAngle = needleDegrees * (PI / 180.0)

            val needleLength = radius - 14.dp.toPx()
            val needleTip = Offset(
                x = center.x + needleLength * cos(needleAngle).toFloat(),
                y = center.y + needleLength * sin(needleAngle).toFloat()
            )
            // Needle counterweight tail (in opposite direction)
            val tailLength = 16.dp.toPx()
            val tailTip = Offset(
                x = center.x - tailLength * cos(needleAngle).toFloat(),
                y = center.y - tailLength * sin(needleAngle).toFloat()
            )
            // Main needle shaft
            drawLine(
                color = if (isRunning) Color(0xFF38BDF8) else Color(0xCC60A5FA),
                start = tailTip,
                end = needleTip,
                strokeWidth = 1.8.dp.toPx(),
                cap = StrokeCap.Round
            )
            // Center Pivot Cap (multi-ring metallic jewel hub)
            drawCircle(
                color = Color(0xFF0E1A2F),
                radius = 7.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color(0xFF38BDF8),
                radius = 4.5.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = center
            )
        }

        // Inside Dial Hero Digital Readout
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(top = 18.dp)
        ) {
            // Live Status Capsule
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isRunning) Color(0x3310B981) else Color(0x40334155))
                    .border(
                        BorderStroke(1.dp, if (isRunning) Color(0x6610B981) else Color(0x2694A3B8)),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (isRunning) Color(0xFF34D399) else Color(0xFF94A3B8))
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isRunning) "CHRONO ACTIVE" else if (timerSeconds > 0) "PAUSED" else "CHRONO READY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isRunning) Color(0xFF34D399) else Color(0xFF94A3B8),
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Digital Chronograph Display (Monospace high precision)
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = timeFormatted,
                    fontSize = if (dialSize >= 280.dp) 44.sp else 36.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White,
                    letterSpacing = (-1.5).sp
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = ".%02d".format(if (isRunning) smoothHundredths else 0),
                    fontSize = if (dialSize >= 280.dp) 20.sp else 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.padding(bottom = 5.dp)
                )
            }

            if (showTopic) {
                Spacer(modifier = Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x331E3A8A))
                        .border(BorderStroke(0.8.dp, Color(0x3338BDF8)), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (timerTopic.isNotBlank()) "${timerSubject.uppercase()} • $timerTopic" else timerSubject.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF93C5FD),
                        maxLines = 1
                    )
                }
            }
        }
    }
}
