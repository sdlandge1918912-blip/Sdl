package com.example.data.model

data class BlockedApp(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val packageName: String,
    val category: String, // "Social Media", "Video & Streaming", "Games", "Messaging", "Study & Prep", "Other"
    val iconEmoji: String,
    val isBlocked: Boolean = true,
    val isStudyApp: Boolean = false,
    val dailyLimitMinutes: Int = 0 // 0 means fully blocked in study hours
)
