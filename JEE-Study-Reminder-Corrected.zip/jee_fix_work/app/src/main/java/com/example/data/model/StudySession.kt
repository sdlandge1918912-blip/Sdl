package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subject: String, // "PHYSICS", "CHEMISTRY", "MATHEMATICS"
    val topic: String,
    val durationSeconds: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val mode: String = "STOPWATCH" // "STOPWATCH", "SPRINT"
)
