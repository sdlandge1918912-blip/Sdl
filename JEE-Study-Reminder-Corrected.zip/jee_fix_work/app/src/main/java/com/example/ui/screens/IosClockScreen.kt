package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AlarmItem
import com.example.ui.components.IosSegmentedControl
import com.example.ui.components.IosSwitch
import com.example.ui.theme.*
import com.example.ui.viewmodel.JeeViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun IosClockScreen(
    viewModel: JeeViewModel,
    modifier: Modifier = Modifier
) {
    var selectedClockTab by remember { mutableIntStateOf(0) }
    val clockTabs = listOf("World Clock", "Alarm", "Stopwatch", "Timer")

    val alarms by viewModel.alarms.collectAsStateWithLifecycle()
    val stopwatchMillis by viewModel.stopwatchMillis.collectAsStateWithLifecycle()
    val isStopwatchRunning by viewModel.isStopwatchRunning.collectAsStateWithLifecycle()
    val stopwatchLaps by viewModel.stopwatchLaps.collectAsStateWithLifecycle()

    val timerTotalSeconds by viewModel.timerTotalSeconds.collectAsStateWithLifecycle()
    val timerRemainingSeconds by viewModel.timerRemainingSeconds.collectAsStateWithLifecycle()
    val isTimerRunning by viewModel.isTimerRunning.collectAsStateWithLifecycle()
    val timerPresetName by viewModel.timerPresetName.collectAsStateWithLifecycle()

    val targetExam by viewModel.targetExam.collectAsStateWithLifecycle()
    val activeSession by viewModel.activeRoutineSession.collectAsStateWithLifecycle()

    var showAddAlarmDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(top = 8.dp)
    ) {
        // Top iOS Navigation Bar / Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = clockTabs[selectedClockTab],
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            if (selectedClockTab == 1) {
                // Add Alarm Button (+)
                IconButton(
                    onClick = { showAddAlarmDialog = true },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1C1C1E))
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Alarm",
                        tint = IosOrange
                    )
                }
            }
        }

        // iOS Segmented Control
        IosSegmentedControl(
            items = clockTabs,
            selectedIndex = selectedClockTab,
            onItemSelected = { selectedClockTab = it },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Content Area based on Tab
        Box(modifier = Modifier.weight(1f)) {
            when (selectedClockTab) {
                0 -> IosWorldClockTab(
                    targetExamName = targetExam?.title ?: "JEE Main 2028 (Session 1)",
                    targetExamDate = targetExam?.let { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(it.examDateMillis)) } ?: "Jan 24, 2028",
                    targetExamMillis = targetExam?.examDateMillis ?: Calendar.getInstance().apply { set(2028, Calendar.JANUARY, 24, 9, 0, 0) }.timeInMillis,
                    activeSessionTitle = activeSession?.title,
                    activeSessionTime = activeSession?.getFormattedTime()
                )

                1 -> IosAlarmTab(
                    alarms = alarms,
                    onToggleAlarm = { viewModel.toggleAlarm(it) },
                    onDeleteAlarm = { viewModel.deleteAlarm(it) },
                    onTestAlarm = { viewModel.testAlarmSound(it) },
                    onOpenAddDialog = { showAddAlarmDialog = true }
                )

                2 -> IosStopwatchTab(
                    stopwatchMillis = stopwatchMillis,
                    isRunning = isStopwatchRunning,
                    laps = stopwatchLaps,
                    onStart = { viewModel.startStopwatch() },
                    onStop = { viewModel.pauseStopwatch() },
                    onReset = { viewModel.resetStopwatch() },
                    onLap = { viewModel.lapStopwatch() }
                )

                3 -> IosTimerTab(
                    totalSeconds = timerTotalSeconds,
                    remainingSeconds = timerRemainingSeconds,
                    isRunning = isTimerRunning,
                    presetName = timerPresetName,
                    onStartPreset = { seconds, label -> viewModel.startCountdown(seconds, label) },
                    onTogglePause = { viewModel.toggleCountdownPause() },
                    onReset = { viewModel.resetCountdown() }
                )
            }
        }
    }

    // Add Alarm Modal Sheet / Dialog
    if (showAddAlarmDialog) {
        IosAddAlarmDialog(
            onDismiss = { showAddAlarmDialog = false },
            onSaveAlarm = { hour, min, label, days, vibrate, snooze ->
                viewModel.addAlarm(hour, min, label, days, vibrate, snooze)
                showAddAlarmDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// TAB 1: WORLD CLOCK & LIVE TICKING ANALOG + DIGITAL
// -------------------------------------------------------------
@Composable
private fun IosWorldClockTab(
    targetExamName: String,
    targetExamDate: String,
    targetExamMillis: Long = 0L,
    activeSessionTitle: String?,
    activeSessionTime: String?
) {
    var currentTime by remember { mutableStateOf(Calendar.getInstance()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = Calendar.getInstance()
            delay(1000)
        }
    }

    val hour = currentTime.get(Calendar.HOUR)
    val minute = currentTime.get(Calendar.MINUTE)
    val second = currentTime.get(Calendar.SECOND)
    val amPm = if (currentTime.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"

    val dateFormatted = remember(currentTime) {
        val sdf = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
        sdf.format(currentTime.time)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Analog Clock Face (Apple Clock Style)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Analog Dial Canvas
                    Box(
                        modifier = Modifier
                            .size(190.dp)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val radius = size.minDimension / 2f

                            // Dial Background & Rim
                            drawCircle(
                                color = Color(0xFF121214),
                                radius = radius,
                                center = center
                            )
                            drawCircle(
                                color = Color(0xFF2C2C2E),
                                radius = radius,
                                center = center,
                                style = Stroke(width = 3.dp.toPx())
                            )

                            // Hour Ticks
                            for (i in 0 until 12) {
                                val angle = (i * 30.0 - 90.0) * (PI / 180.0)
                                val tickStart = Offset(
                                    x = center.x + (radius - 12.dp.toPx()) * cos(angle).toFloat(),
                                    y = center.y + (radius - 12.dp.toPx()) * sin(angle).toFloat()
                                )
                                val tickEnd = Offset(
                                    x = center.x + (radius - 4.dp.toPx()) * cos(angle).toFloat(),
                                    y = center.y + (radius - 4.dp.toPx()) * sin(angle).toFloat()
                                )
                                drawLine(
                                    color = if (i % 3 == 0) Color.White else Color(0xFF636366),
                                    start = tickStart,
                                    end = tickEnd,
                                    strokeWidth = if (i % 3 == 0) 3.dp.toPx() else 1.5.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            }

                            // Hour Hand
                            val hourAngle = ((hour + minute / 60f) * 30f - 90f) * (PI / 180.0)
                            val hourHandEnd = Offset(
                                x = center.x + (radius * 0.52f) * cos(hourAngle).toFloat(),
                                y = center.y + (radius * 0.52f) * sin(hourAngle).toFloat()
                            )
                            drawLine(
                                color = Color.White,
                                start = center,
                                end = hourHandEnd,
                                strokeWidth = 4.5.dp.toPx(),
                                cap = StrokeCap.Round
                            )

                            // Minute Hand
                            val minAngle = ((minute + second / 60f) * 6f - 90f) * (PI / 180.0)
                            val minHandEnd = Offset(
                                x = center.x + (radius * 0.76f) * cos(minAngle).toFloat(),
                                y = center.y + (radius * 0.76f) * sin(minAngle).toFloat()
                            )
                            drawLine(
                                color = Color.White,
                                start = center,
                                end = minHandEnd,
                                strokeWidth = 3.dp.toPx(),
                                cap = StrokeCap.Round
                            )

                            // Second Hand (Apple Orange #FF9500)
                            val secAngle = (second * 6f - 90f) * (PI / 180.0)
                            val secHandEnd = Offset(
                                x = center.x + (radius * 0.85f) * cos(secAngle).toFloat(),
                                y = center.y + (radius * 0.85f) * sin(secAngle).toFloat()
                            )
                            val secHandTail = Offset(
                                x = center.x - (radius * 0.2f) * cos(secAngle).toFloat(),
                                y = center.y - (radius * 0.2f) * sin(secAngle).toFloat()
                            )
                            drawLine(
                                color = IosOrange,
                                start = secHandTail,
                                end = secHandEnd,
                                strokeWidth = 1.8.dp.toPx(),
                                cap = StrokeCap.Round
                            )

                            // Center Pivot Dots
                            drawCircle(color = IosOrange, radius = 4.dp.toPx(), center = center)
                            drawCircle(color = Color(0xFF121214), radius = 2.dp.toPx(), center = center)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Digital Time Display (Apple Monospaced Digital Look)
                    val displayHour = if (hour == 0) 12 else hour
                    Text(
                        text = "%02d:%02d:%02d %s".format(displayHour, minute, second, amPm),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = dateFormatted,
                        fontSize = 14.sp,
                        color = Color(0xFF8E8E93),
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    // Time Zone Pill
                    Box(
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF2C2C2E))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "India Standard Time (IST) • System Clock",
                            color = Color(0xFF98989D),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Active Section Live Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2C2C2E)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "⚡", fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CURRENT TIMETABLE SECTION",
                            color = IosOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = activeSessionTitle ?: "Break / Self-Study Slot",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = activeSessionTime ?: "Stay disciplined and review formulas",
                            color = Color(0xFF8E8E93),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Target Exam Live Countdown Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🎯", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = targetExamName,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF2C2C2E))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = targetExamDate,
                                color = IosBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Days remaining calculation for JEE 2028 target
                    val daysRemaining = remember(targetExamMillis, currentTime) {
                        val examTime = if (targetExamMillis > 0L) targetExamMillis else {
                            Calendar.getInstance().apply {
                                set(2028, Calendar.JANUARY, 24, 9, 0, 0)
                            }.timeInMillis
                        }
                        val diffMillis = examTime - currentTime.timeInMillis
                        if (diffMillis > 0) (diffMillis / (1000L * 60 * 60 * 24)).toInt() else 0
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        IosCountdownUnit(value = "$daysRemaining", label = "DAYS")
                        IosCountdownUnit(value = "${23 - hour}", label = "HOURS")
                        IosCountdownUnit(value = "${59 - minute}", label = "MINS")
                        IosCountdownUnit(value = "${59 - second}", label = "SECS")
                    }
                }
            }
        }
    }
}

@Composable
private fun IosCountdownUnit(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF2C2C2E))
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF8E8E93),
            letterSpacing = 0.5.sp
        )
    }
}

// -------------------------------------------------------------
// TAB 2: ALARM (AUTHENTIC APPLE CLOCK STYLE)
// -------------------------------------------------------------
@Composable
private fun IosAlarmTab(
    alarms: List<AlarmItem>,
    onToggleAlarm: (String) -> Unit,
    onDeleteAlarm: (String) -> Unit,
    onTestAlarm: (AlarmItem) -> Unit,
    onOpenAddDialog: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Sleep | Wake Up Apple Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🛌", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Sleep | Wake Up",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Every Day • 05:45 AM Alarm",
                                color = Color(0xFF8E8E93),
                                fontSize = 13.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF2C2C2E))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "CHANGE",
                            color = IosOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "OTHER ALARMS",
                color = Color(0xFF8E8E93),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )
        }

        itemsIndexed(alarms, key = { _, alarm -> alarm.id }) { _, alarm ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = alarm.getFormattedTime(),
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Light,
                                color = if (alarm.isEnabled) Color.White else Color(0xFF636366),
                                fontFamily = FontFamily.SansSerif
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = alarm.getAmPm(),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Normal,
                                color = if (alarm.isEnabled) Color.White else Color(0xFF636366),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }

                        Text(
                            text = "${alarm.label} • ${alarm.getRepeatDaysSummary()}",
                            fontSize = 13.sp,
                            color = if (alarm.isEnabled) Color(0xFF8E8E93) else Color(0xFF48484A)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quick Preview Sound Button
                        IconButton(
                            onClick = { onTestAlarm(alarm) },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Test Alarm Sound",
                                tint = if (alarm.isEnabled) IosOrange else Color(0xFF636366),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Apple iOS Toggle Switch
                        IosSwitch(
                            checked = alarm.isEnabled,
                            onCheckedChange = { onToggleAlarm(alarm.id) }
                        )

                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = { onDeleteAlarm(alarm.id) },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete Alarm",
                                tint = Color(0xFF636366),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = onOpenAddDialog,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C1C1E)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = IosOrange
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Add New Alarm",
                    color = IosOrange,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: STOPWATCH (APPLE STOPWATCH & LAP HIGHLIGHTING)
// -------------------------------------------------------------
@Composable
private fun IosStopwatchTab(
    stopwatchMillis: Long,
    isRunning: Boolean,
    laps: List<Long>,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onReset: () -> Unit,
    onLap: () -> Unit
) {
    val minutes = (stopwatchMillis / 60000)
    val seconds = (stopwatchMillis % 60000) / 1000
    val hundredths = (stopwatchMillis % 1000) / 10

    // Fastest and slowest lap calculation for authentic iOS colors (Green = best, Red = worst)
    val lapDifferences = remember(laps) {
        val diffs = mutableListOf<Long>()
        for (i in laps.indices) {
            val totalAtLap = laps[i]
            val totalAtPreviousLap = laps.getOrNull(i + 1) ?: 0L
            diffs.add(totalAtLap - totalAtPreviousLap)
        }
        diffs
    }

    val minLapTime = remember(lapDifferences) {
        if (lapDifferences.size >= 2) lapDifferences.minOrNull() else null
    }
    val maxLapTime = remember(lapDifferences) {
        if (lapDifferences.size >= 2) lapDifferences.maxOrNull() else null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Huge Digital Stopwatch Display
        Text(
            text = "%02d:%02d.%02d".format(minutes, seconds, hundredths),
            fontSize = 72.sp,
            fontWeight = FontWeight.ExtraLight,
            fontFamily = FontFamily.Monospace,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(30.dp))

        // Dual Circular Apple Stopwatch Action Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Button: Lap / Reset
            val canLapOrReset = isRunning || stopwatchMillis > 0
            val leftButtonText = if (isRunning) "Lap" else "Reset"
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(if (canLapOrReset) Color(0xFF333336) else Color(0xFF1C1C1E))
                    .border(2.dp, Color(0xFF000000), CircleShape)
                    .clickable(enabled = canLapOrReset) {
                        if (isRunning) onLap() else onReset()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = leftButtonText,
                    color = if (canLapOrReset) Color.White else Color(0xFF636366),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Right Button: Start / Stop
            val rightButtonText = if (isRunning) "Stop" else "Start"
            val rightButtonBg = if (isRunning) Color(0xFF3A1414) else Color(0xFF14381C)
            val rightButtonTextColor = if (isRunning) IosRed else IosGreen

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(rightButtonBg)
                    .border(2.dp, Color(0xFF000000), CircleShape)
                    .clickable {
                        if (isRunning) onStop() else onStart()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rightButtonText,
                    color = rightButtonTextColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        HorizontalDivider(color = Color(0xFF2C2C2E), thickness = 1.dp)

        // Laps List
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            itemsIndexed(laps) { index, lapTotalMillis ->
                val lapNumber = laps.size - index
                val lapSplit = lapDifferences.getOrNull(index) ?: lapTotalMillis
                val splitMin = lapSplit / 60000
                val splitSec = (lapSplit % 60000) / 1000
                val splitHundredths = (lapSplit % 1000) / 10

                val lapColor = when {
                    lapDifferences.size >= 2 && lapSplit == minLapTime -> IosGreen
                    lapDifferences.size >= 2 && lapSplit == maxLapTime -> IosRed
                    else -> Color.White
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Lap $lapNumber",
                        fontSize = 16.sp,
                        color = lapColor,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "%02d:%02d.%02d".format(splitMin, splitSec, splitHundredths),
                        fontSize = 17.sp,
                        fontFamily = FontFamily.Monospace,
                        color = lapColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                HorizontalDivider(color = Color(0xFF1C1C1E), thickness = 1.dp)
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 4: COUNTDOWN TIMER (APPLE TIMER WITH CIRCULAR RING & PRESETS)
// -------------------------------------------------------------
@Composable
private fun IosTimerTab(
    totalSeconds: Long,
    remainingSeconds: Long,
    isRunning: Boolean,
    presetName: String,
    onStartPreset: (Long, String) -> Unit,
    onTogglePause: () -> Unit,
    onReset: () -> Unit
) {
    val progress = if (totalSeconds > 0) remainingSeconds.toFloat() / totalSeconds.toFloat() else 0f
    val hours = remainingSeconds / 3600
    val minutes = (remainingSeconds % 3600) / 60
    val seconds = remainingSeconds % 60

    val presets = listOf(
        "Pomodoro (25m)" to 25 * 60L,
        "JEE Problem Sprint (45m)" to 45 * 60L,
        "Subject Test (60m)" to 60 * 60L,
        "Deep Focus (90m)" to 90 * 60L,
        "Full JEE Mock (180m)" to 180 * 60L
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Circular Timer Progress Ring
        Box(
            modifier = Modifier
                .size(240.dp)
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 10.dp.toPx()
                val radius = (size.minDimension - strokeWidth) / 2f
                val center = Offset(size.width / 2f, size.height / 2f)

                // Background track
                drawCircle(
                    color = Color(0xFF2C2C2E),
                    radius = radius,
                    center = center,
                    style = Stroke(width = strokeWidth)
                )

                // Progress Arc (Orange Apple Timer Tint)
                drawArc(
                    brush = Brush.sweepGradient(listOf(IosOrange, Color(0xFFFFB703), IosOrange)),
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (hours > 0) {
                        "%02d:%02d:%02d".format(hours, minutes, seconds)
                    } else {
                        "%02d:%02d".format(minutes, seconds)
                    },
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraLight,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White
                )

                Text(
                    text = presetName,
                    fontSize = 12.sp,
                    color = IosOrange,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Dual Circular Action Buttons (Apple Timer Style)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Cancel button
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF333336))
                    .clickable { onReset() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Cancel",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Start / Pause button
            val rightText = if (isRunning) "Pause" else "Start"
            val rightBg = if (isRunning) Color(0xFF3A2412) else Color(0xFF14381C)
            val rightTextColor = if (isRunning) IosOrange else IosGreen

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(rightBg)
                    .clickable { onTogglePause() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rightText,
                    color = rightTextColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Preset Study Sprints Header
        Text(
            text = "JEE STUDY PRESETS",
            color = Color(0xFF8E8E93),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(presets.size) { idx ->
                val (label, secs) = presets[idx]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStartPreset(secs, label) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🎯", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = label,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Start Preset",
                            tint = IosOrange,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// ADD ALARM MODAL DIALOG
// -------------------------------------------------------------
@Composable
private fun IosAddAlarmDialog(
    onDismiss: () -> Unit,
    onSaveAlarm: (hour: Int, minute: Int, label: String, repeatDays: Set<Int>, vibrate: Boolean, snooze: Boolean) -> Unit
) {
    var selectedHour by remember { mutableIntStateOf(6) }
    var selectedMinute by remember { mutableIntStateOf(0) }
    var selectedAmPm by remember { mutableStateOf("AM") }
    var labelText by remember { mutableStateOf("Physics Numerical Session") }
    var isVibrate by remember { mutableStateOf(true) }
    var isSnooze by remember { mutableStateOf(true) }

    val daysOfWeek = listOf(
        Calendar.SUNDAY to "Sun",
        Calendar.MONDAY to "Mon",
        Calendar.TUESDAY to "Tue",
        Calendar.WEDNESDAY to "Wed",
        Calendar.THURSDAY to "Thu",
        Calendar.FRIDAY to "Fri",
        Calendar.SATURDAY to "Sat"
    )
    val selectedDays = remember { mutableStateListOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1C1E),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Cancel",
                    color = IosOrange,
                    fontSize = 15.sp,
                    modifier = Modifier.clickable { onDismiss() }
                )
                Text(
                    text = "Add Alarm",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Save",
                    color = IosOrange,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable {
                        val finalHour = when {
                            selectedAmPm == "PM" && selectedHour < 12 -> selectedHour + 12
                            selectedAmPm == "AM" && selectedHour == 12 -> 0
                            else -> selectedHour
                        }
                        onSaveAlarm(
                            finalHour,
                            selectedMinute,
                            labelText,
                            selectedDays.toSet(),
                            isVibrate,
                            isSnooze
                        )
                    }
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Time Picker Quick Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Hour selector
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Hour", color = Color(0xFF8E8E93), fontSize = 11.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (selectedHour > 1) selectedHour-- else selectedHour = 12 }) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = Color.White)
                            }
                            Text(
                                text = "%02d".format(selectedHour),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            IconButton(onClick = { if (selectedHour < 12) selectedHour++ else selectedHour = 1 }) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                            }
                        }
                    }

                    Text(
                        text = ":",
                        fontSize = 28.sp,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    // Minute selector
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "Minute", color = Color(0xFF8E8E93), fontSize = 11.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { selectedMinute = (selectedMinute - 5 + 60) % 60 }) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = Color.White)
                            }
                            Text(
                                text = "%02d".format(selectedMinute),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            IconButton(onClick = { selectedMinute = (selectedMinute + 5) % 60 }) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // AM / PM Switch
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF2C2C2E))
                            .clickable { selectedAmPm = if (selectedAmPm == "AM") "PM" else "AM" }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = selectedAmPm,
                            color = IosOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }

                // Label field
                OutlinedTextField(
                    value = labelText,
                    onValueChange = { labelText = it },
                    label = { Text("Alarm Label", color = Color(0xFF8E8E93)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = IosOrange,
                        unfocusedBorderColor = Color(0xFF38383A)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Repeat Days Selection
                Text(
                    text = "REPEAT DAYS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8E8E93)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    daysOfWeek.forEach { (calDay, dayName) ->
                        val isDaySelected = selectedDays.contains(calDay)
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(if (isDaySelected) IosOrange else Color(0xFF2C2C2E))
                                .clickable {
                                    if (isDaySelected) selectedDays.remove(calDay) else selectedDays.add(calDay)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = dayName.take(1),
                                color = if (isDaySelected) Color.White else Color(0xFF8E8E93),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Vibration & Snooze Options
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Vibrate on Alarm", color = Color.White, fontSize = 14.sp)
                    IosSwitch(checked = isVibrate, onCheckedChange = { isVibrate = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Snooze (9 min)", color = Color.White, fontSize = 14.sp)
                    IosSwitch(checked = isSnooze, onCheckedChange = { isSnooze = it })
                }
            }
        },
        confirmButton = {}
    )
}
