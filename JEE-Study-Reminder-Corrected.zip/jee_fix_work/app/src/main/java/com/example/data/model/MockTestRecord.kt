package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mock_test_records")
data class MockTestRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val testName: String,
    val testDateMillis: Long = System.currentTimeMillis(),
    val physicsScore: Int,
    val chemistryScore: Int,
    val mathsScore: Int,
    val totalScore: Int = physicsScore + chemistryScore + mathsScore,
    val maxScore: Int = 300,
    val estimatedPercentile: Double = 0.0,
    val negativeMarks: Int = 0,
    val weakAreas: String = ""
)
