package com.example.data.dao

import androidx.room.*
import com.example.data.model.ExamEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDao {
    @Query("SELECT * FROM exam_events ORDER BY examDateMillis ASC")
    fun getAllExams(): Flow<List<ExamEvent>>

    @Query("SELECT * FROM exam_events WHERE isTargetExam = 1 LIMIT 1")
    fun getTargetExam(): Flow<ExamEvent?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamEvent): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(exams: List<ExamEvent>)

    @Update
    suspend fun updateExam(exam: ExamEvent)

    @Delete
    suspend fun deleteExam(exam: ExamEvent)

    @Query("UPDATE exam_events SET isTargetExam = (CASE WHEN id = :examId THEN 1 ELSE 0 END)")
    suspend fun setTargetExam(examId: Long)

    @Query("SELECT COUNT(*) FROM exam_events")
    suspend fun countExams(): Int

    @Query("SELECT * FROM exam_events WHERE isTargetExam = 1 LIMIT 1")
    suspend fun getTargetExamSync(): ExamEvent?

    @Query("SELECT * FROM exam_events WHERE title LIKE '%2028%' LIMIT 1")
    suspend fun getJee2028Exam(): ExamEvent?

    @Query("SELECT * FROM exam_events")
    suspend fun getAllExamsSync(): List<ExamEvent>

    @Query("DELETE FROM exam_events")
    suspend fun deleteAllExams()
}
