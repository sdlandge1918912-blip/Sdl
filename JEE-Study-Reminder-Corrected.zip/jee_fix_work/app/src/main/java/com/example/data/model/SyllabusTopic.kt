package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "syllabus_topics")
data class SyllabusTopic(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subject: String, // "PHYSICS", "CHEMISTRY", "MATHEMATICS"
    val standardClass: String = "11TH", // "11TH", "12TH"
    val chapterName: String,
    val unit: String = "Core Syllabus",
    val isCompleted: Boolean = false,
    val pyqsSolved: Boolean = false,
    val revisionCount: Int = 0,
    val highYield: Boolean = true,
    val totalWeightagePercent: Float = 4.0f,
    val difficultyRating: Int = 3
)
