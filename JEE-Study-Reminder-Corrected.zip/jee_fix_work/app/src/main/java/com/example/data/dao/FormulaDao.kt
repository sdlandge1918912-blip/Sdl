package com.example.data.dao

import androidx.room.*
import com.example.data.model.FormulaCard
import kotlinx.coroutines.flow.Flow

@Dao
interface FormulaDao {
    @Query("SELECT * FROM formula_cards ORDER BY subject, chapter ASC")
    fun getAllFormulas(): Flow<List<FormulaCard>>

    @Query("SELECT * FROM formula_cards WHERE subject = :subject ORDER BY chapter ASC")
    fun getFormulasBySubject(subject: String): Flow<List<FormulaCard>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFormula(formula: FormulaCard): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(formulas: List<FormulaCard>)

    @Query("UPDATE formula_cards SET isBookmarked = :bookmarked WHERE id = :id")
    suspend fun toggleBookmark(id: Long, bookmarked: Boolean)

    @Query("SELECT COUNT(*) FROM formula_cards")
    suspend fun countFormulas(): Int

    @Query("DELETE FROM formula_cards")
    suspend fun deleteAllFormulas()
}
