package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.ui.LockoutActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.example.data.repository.ParentTelemetryRepository

class StrictStudyService : Service() {

    companion object {
        const val ACTION_START = "action_start_strict_study"
        const val ACTION_STOP = "action_stop_strict_study"
        const val ACTION_EMERGENCY_BREAK = "action_emergency_break"

        private const val NOTIFICATION_ID = 9102
        private const val CHANNEL_ID = "jee_strict_study_guard_channel"
        private const val CHANNEL_NAME = "JEE Strict Study Focus Guard"
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var isMonitoring = false
    private var lastBlockedPackage: String? = null
    private var lastBlockedTimestamp: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_EMERGENCY_BREAK -> {
                FocusShieldManager.grantEmergencyBreak(this, 2)
                updateNotification("⏳ Emergency 2-Minute Break Active", "Distractions temporarily unlocked.")
            }
            else -> {
                startForegroundWithNotification()
                startMonitoringLoop()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifies when JEE Strict Study Mode is guarding your study slot"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification(
            title = "🛡️ Strict Study Mode Active",
            content = "Guarding study focus • Distracting apps locked"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val emergencyIntent = Intent(this, StrictStudyService::class.java).apply {
            action = ACTION_EMERGENCY_BREAK
        }
        val emergencyPendingIntent = PendingIntent.getService(
            this,
            1,
            emergencyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openPendingIntent)
            .addAction(
                R.mipmap.ic_launcher,
                "Emergency 2m Break",
                emergencyPendingIntent
            )
            .build()
    }

    private fun updateNotification(title: String, content: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        nm?.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    private fun startMonitoringLoop() {
        if (isMonitoring) return
        isMonitoring = true

        serviceScope.launch {
            while (isActive) {
                try {
                    // Check every 1.2 seconds
                    delay(1200L)

                    // Verify if shield service should keep running
                    val isMasterActive = FocusShieldManager.isFocusShieldActive(this@StrictStudyService)
                    val isAutoSync = FocusShieldManager.isAutoTimetableSync(this@StrictStudyService)
                    val isManualActive = FocusShieldManager.isManualSessionActive(this@StrictStudyService)

                    if (!isMasterActive && !isAutoSync && !isManualActive) {
                        stopSelf()
                        break
                    }

                    // Check if emergency break is ongoing
                    if (FocusShieldManager.isEmergencyUnlocked(this@StrictStudyService)) {
                        val remainingSec = FocusShieldManager.getEmergencyRemainingSeconds(this@StrictStudyService)
                        updateNotification(
                            "⏳ Emergency Break Active (${remainingSec}s)",
                            "Distraction apps temporarily allowed. Returning to strict study mode soon."
                        )
                        continue
                    }

                    // Check current timetable section status
                    val (currentSession, isOngoing) = FocusShieldManager.getCurrentOngoingSession(this@StrictStudyService)
                    val isStrictEnforced = FocusShieldManager.isStrictStudyCurrentlyEnforced(this@StrictStudyService)

                    // Update dynamic foreground notification reflecting study vs break
                    if (isManualActive) {
                        val remainingSec = FocusShieldManager.getManualSessionRemainingSeconds(this@StrictStudyService)
                        val mins = remainingSec / 60
                        val secs = remainingSec % 60
                        val label = FocusShieldManager.getManualSessionLabel(this@StrictStudyService)
                        updateNotification(
                            "⚡ Manual Focus Active (${String.format("%02d:%02d", mins, secs)})",
                            "Guarding $label • Distracting apps locked"
                        )
                    } else if (isOngoing) {
                        if (currentSession?.isStudySlot() == true) {
                            updateNotification(
                                "🛡️ Strict Mode ON: ${currentSession.title}",
                                "Studying ${currentSession.category} (${currentSession.getFormattedTime()}) • Distractions locked"
                            )
                        } else {
                            updateNotification(
                                "☕ Break Time: ${currentSession?.title ?: "Break"}",
                                "Strict Mode OFF • Distractions allowed until ${currentSession?.endTime}"
                            )
                        }
                    } else {
                        updateNotification(
                            "⏳ Upcoming: ${currentSession?.title ?: "Study Slot"}",
                            "Strict Mode paused until study starts (${currentSession?.startTime ?: ""})"
                        )
                    }

                    // CRITICAL: If not strictly enforced (i.e. break time, meals, sleep, relaxation):
                    // DO NOT BLOCK ANY APPS!
                    if (!isStrictEnforced) {
                        continue
                    }

                    // Check if usage stats permission is granted
                    if (!FocusShieldManager.hasUsageStatsPermission(this@StrictStudyService)) {
                        updateNotification(
                            "⚠️ Usage Access Required",
                            "Tap to grant Usage Access in Settings to enable app blocker."
                        )
                        continue
                    }

                    val foregroundPkg = FocusShieldManager.getForegroundAppPackage(this@StrictStudyService)
                    if (foregroundPkg != null &&
                        foregroundPkg != packageName &&
                        !isSafeSystemPackage(foregroundPkg)
                    ) {
                        // Check if this package is blocked
                        if (FocusShieldManager.isAppBlocked(this@StrictStudyService, foregroundPkg)) {
                            // Record distraction tick for ongoing section and today
                            StudyTimeTracker.recordDistractionTick(this@StrictStudyService, foregroundPkg, 1)

                            val now = System.currentTimeMillis()
                            // Rate-limit trigger to prevent spamming if already launching
                            if (foregroundPkg != lastBlockedPackage || (now - lastBlockedTimestamp) > 3000L) {
                                lastBlockedPackage = foregroundPkg
                                lastBlockedTimestamp = now

                                triggerLockout(foregroundPkg, currentSession?.title)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun isSafeSystemPackage(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.startsWith("com.android.systemui") ||
                lower.startsWith("com.android.dialer") ||
                lower.startsWith("com.google.android.dialer") ||
                lower.contains("launcher") ||
                lower == "android"
    }

    private fun triggerLockout(blockedPackage: String, ongoingSessionTitle: String? = null) {
        val blockedApp = FocusShieldManager.getBlockedApp(this, blockedPackage)
        val appName = blockedApp?.name ?: try {
            val pm = packageManager
            val info = pm.getApplicationInfo(blockedPackage, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            "Distracting App"
        }

        // Tactile vibration
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(120)
                }
            }
        } catch (_: Exception) {}

        // Launch LockoutActivity immediately
        try {
            val lockIntent = Intent(this, LockoutActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(LockoutActivity.EXTRA_PACKAGE_NAME, blockedPackage)
                putExtra(LockoutActivity.EXTRA_APP_NAME, appName)
                putExtra(LockoutActivity.EXTRA_ONGOING_SESSION, ongoingSessionTitle ?: "JEE Study Session")
            }
            startActivity(lockIntent)
        } catch (_: Exception) {}

        updateNotification(
            "🛑 Distraction Guarded: $appName",
            "Blocked during study slot. Return to JEE Timetable to resume."
        )

        // Telemetry to Parent Dashboard
        serviceScope.launch(Dispatchers.IO) {
            try {
                ParentTelemetryRepository(applicationContext).pushDistractionLog(
                    blockedAppName = appName,
                    currentSlotName = ongoingSessionTitle ?: "Active JEE Study Slot",
                    isEmergencyUnlock = false
                )
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isMonitoring = false
        serviceScope.cancel()
    }
}
