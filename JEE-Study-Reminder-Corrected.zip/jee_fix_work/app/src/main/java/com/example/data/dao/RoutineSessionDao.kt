package com.example.data.dao

import androidx.room.*
import com.example.data.model.RoutineSession
import kotlinx.coroutines.flow.Flow

@Dao
interface RoutineSessionDao {
    @Query("SELECT * FROM routine_sessions ORDER BY orderIndex ASC")
    fun getAllRoutineSessions(): Flow<List<RoutineSession>>

    @Query("SELECT * FROM routine_sessions ORDER BY orderIndex ASC")
    suspend fun getAllRoutineSessionsSync(): List<RoutineSession>

    @Query("SELECT * FROM routine_sessions WHERE category = :category ORDER BY orderIndex ASC")
    fun getSessionsByCategory(category: String): Flow<List<RoutineSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: RoutineSession): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(sessions: List<RoutineSession>)

    @Update
    suspend fun updateSession(session: RoutineSession)

    @Delete
    suspend fun deleteSession(session: RoutineSession)

    @Query("UPDATE routine_sessions SET isNotificationEnabled = :enabled WHERE id = :id")
    suspend fun toggleNotification(id: Long, enabled: Boolean)

    @Query("SELECT COUNT(*) FROM routine_sessions")
    suspend fun countSessions(): Int

    @Query("DELETE FROM routine_sessions")
    suspend fun deleteAll()
}
