package com.example.service

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.database.DefaultJeeData
import com.example.data.model.BlockedApp
import com.example.data.model.RoutineSession
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

object FocusShieldManager {

    private const val PREFS_NAME = "jee_focus_shield_prefs"
    private const val KEY_SHIELD_ACTIVE = "key_focus_shield_active"
    private const val KEY_AUTO_TIMETABLE_SYNC = "key_auto_timetable_sync"
    private const val KEY_BLOCKED_APPS_JSON = "key_blocked_apps_json"
    private const val KEY_EMERGENCY_UNLOCK_UNTIL = "key_emergency_unlock_until"
    private const val KEY_MANUAL_END_TIME = "key_manual_session_end_time"
    private const val KEY_MANUAL_LABEL = "key_manual_session_label"
    private const val KEY_STRICT_LEVEL = "key_strict_level" // "STRICT", "ULTRA_STRICT"

    fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // -------------------------------------------------------------
    // STRICT SHIELD MASTER TOGGLES
    // -------------------------------------------------------------
    fun isFocusShieldActive(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_SHIELD_ACTIVE, false)
    }

    fun setFocusShieldActive(context: Context, active: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SHIELD_ACTIVE, active).apply()
        if (active) {
            startStrictStudyService(context)
        } else {
            // Also stop manual session if stopping shield
            stopManualFocusSession(context)
            stopStrictStudyService(context)
        }
    }

    fun isAutoTimetableSync(context: Context): Boolean {
        // Defaults to true: automatically blocks apps during study timetable slots
        return getPrefs(context).getBoolean(KEY_AUTO_TIMETABLE_SYNC, true)
    }

    fun setAutoTimetableSync(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_AUTO_TIMETABLE_SYNC, enabled).apply()
        if (isFocusShieldActive(context)) {
            startStrictStudyService(context)
        }
    }

    fun getStrictLevel(context: Context): String {
        return getPrefs(context).getString(KEY_STRICT_LEVEL, "STRICT") ?: "STRICT"
    }

    fun setStrictLevel(context: Context, level: String) {
        getPrefs(context).edit().putString(KEY_STRICT_LEVEL, level).apply()
    }

    // -------------------------------------------------------------
    // MANUAL FOCUS SESSION (POMODORO / QUICK SLOTS)
    // -------------------------------------------------------------
    fun startManualFocusSession(context: Context, durationMinutes: Int, label: String = "Manual Focus Session") {
        val until = System.currentTimeMillis() + (durationMinutes * 60 * 1000L)
        getPrefs(context).edit()
            .putLong(KEY_MANUAL_END_TIME, until)
            .putString(KEY_MANUAL_LABEL, label)
            .putBoolean(KEY_SHIELD_ACTIVE, true)
            .apply()
        startStrictStudyService(context)
    }

    fun stopManualFocusSession(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_MANUAL_END_TIME)
            .remove(KEY_MANUAL_LABEL)
            .apply()
    }

    fun isManualSessionActive(context: Context): Boolean {
        val until = getPrefs(context).getLong(KEY_MANUAL_END_TIME, 0L)
        return System.currentTimeMillis() < until
    }

    fun getManualSessionRemainingSeconds(context: Context): Long {
        val until = getPrefs(context).getLong(KEY_MANUAL_END_TIME, 0L)
        val diff = until - System.currentTimeMillis()
        return if (diff > 0) diff / 1000 else 0L
    }

    fun getManualSessionLabel(context: Context): String {
        return getPrefs(context).getString(KEY_MANUAL_LABEL, "Manual Focus") ?: "Manual Focus"
    }

    // -------------------------------------------------------------
    // AUTOMATIC TIMETABLE SYNC & ONGOING SECTION TRACKING
    // -------------------------------------------------------------
    private const val KEY_CACHED_ROUTINE_SESSIONS_JSON = "key_cached_routine_sessions_json"

    fun syncRoutineSessions(context: Context, sessions: List<RoutineSession>) {
        if (sessions.isEmpty()) return
        try {
            val array = JSONArray()
            for (s in sessions) {
                val obj = JSONObject().apply {
                    put("id", s.id)
                    put("category", s.category)
                    put("startTime", s.startTime)
                    put("endTime", s.endTime)
                    put("title", s.title)
                    put("emoji", s.emoji)
                    put("focusTopic", s.focusTopic ?: "")
                    put("description", s.description)
                    put("displayTime", s.displayTime)
                    put("orderIndex", s.orderIndex)
                }
                array.put(obj)
            }
            getPrefs(context).edit().putString(KEY_CACHED_ROUTINE_SESSIONS_JSON, array.toString()).apply()
        } catch (_: Exception) {}
    }

    fun getSyncedRoutineSessions(context: Context): List<RoutineSession> {
        val json = getPrefs(context).getString(KEY_CACHED_ROUTINE_SESSIONS_JSON, null)
        if (json.isNullOrBlank()) {
            return DefaultJeeData.getDefaultRoutineSessions()
        }
        return try {
            val array = JSONArray(json)
            val list = mutableListOf<RoutineSession>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    RoutineSession(
                        id = obj.optLong("id", (i + 1).toLong()),
                        category = obj.optString("category", "Routine"),
                        startTime = obj.optString("startTime", "00:00"),
                        endTime = obj.optString("endTime", "00:00"),
                        title = obj.optString("title", "Session"),
                        emoji = obj.optString("emoji", "📚"),
                        focusTopic = obj.optString("focusTopic").takeIf { it.isNotBlank() },
                        description = obj.optString("description", ""),
                        displayTime = obj.optString("displayTime", ""),
                        orderIndex = obj.optInt("orderIndex", i)
                    )
                )
            }
            if (list.isEmpty()) DefaultJeeData.getDefaultRoutineSessions() else list
        } catch (_: Exception) {
            DefaultJeeData.getDefaultRoutineSessions()
        }
    }

    /**
     * Calculates the currently ongoing routine section or the next upcoming section.
     * Returns Pair(session, isOngoingNow).
     */
    fun getCurrentOngoingSession(context: Context): Pair<RoutineSession?, Boolean> {
        val sessions = getSyncedRoutineSessions(context)
        if (sessions.isEmpty()) return Pair(null, false)

        val now = Calendar.getInstance()
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

        var matched: RoutineSession? = null
        for (session in sessions) {
            val startParts = session.startTime.split(":")
            val endParts = session.endTime.split(":")
            if (startParts.size >= 2 && endParts.size >= 2) {
                val startM = (startParts[0].toIntOrNull() ?: 0) * 60 + (startParts[1].toIntOrNull() ?: 0)
                val endM = (endParts[0].toIntOrNull() ?: 0) * 60 + (endParts[1].toIntOrNull() ?: 0)

                val isOngoing = if (endM > startM) {
                    currentMinutes in startM until endM
                } else if (endM < startM) {
                    currentMinutes >= startM || currentMinutes < endM
                } else {
                    currentMinutes in startM until (startM + 15)
                }

                if (isOngoing) {
                    matched = session
                    break
                }
            }
        }

        if (matched != null) {
            return Pair(matched, true)
        }

        // Between sections - find next upcoming
        val next = sessions.firstOrNull { s ->
            val startParts = s.startTime.split(":")
            val startM = (startParts.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (startParts.getOrNull(1)?.toIntOrNull() ?: 0)
            startM > currentMinutes
        } ?: sessions.firstOrNull()

        return Pair(next, false)
    }

    fun isCurrentlyInStudySection(context: Context): Boolean {
        val (session, isOngoing) = getCurrentOngoingSession(context)
        return isOngoing && (session?.isStudySlot() == true)
    }

    fun isCurrentlyInBreak(context: Context): Boolean {
        val (session, isOngoing) = getCurrentOngoingSession(context)
        return isOngoing && (session?.isStudySlot() == false)
    }

    /**
     * Determines whether Strict Study Mode is actively guarding right now.
     * - AUTOMATICALLY ON when an ongoing section is a study section (Physics, Chemistry, Maths, Revision)
     *   or when a manual focus sprint is running.
     * - AUTOMATICALLY OFF during breaks (Lunch, walking, breakfast, dinner, sleep, etc.).
     */
    fun isStrictStudyCurrentlyEnforced(context: Context, isCurrentSectionStudy: Boolean? = null): Boolean {
        if (isEmergencyUnlocked(context)) return false
        if (isManualSessionActive(context)) return true

        val isMasterOn = isFocusShieldActive(context)
        val isAutoSync = isAutoTimetableSync(context)

        // If both are toggled off by user, strict mode does not enforce
        if (!isMasterOn && !isAutoSync) return false

        // When auto timetable sync is enabled:
        // Automatically turns ON during study sections and OFF during breaks!
        if (isAutoSync) {
            val studyActive = isCurrentSectionStudy ?: isCurrentlyInStudySection(context)
            return studyActive
        }

        return isMasterOn
    }

    // -------------------------------------------------------------
    // PERMISSIONS MANAGEMENT (Play Protect Approved Standard APIs)
    // -------------------------------------------------------------
    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun openUsageAccessSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    fun openOverlaySettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        }
    }

    // -------------------------------------------------------------
    // BACKGROUND APP ACTIVATION & BATTERY OPTIMIZATION
    // -------------------------------------------------------------
    fun isBatteryOptimizationIgnored(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
        } else {
            true
        }
    }

    fun requestIgnoreBatteryOptimizations(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                // Direct system dialog to allow background activity without restrictions
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                try {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {
                    openAppBatterySettings(context)
                }
            }
        }
    }

    fun openAppBatterySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (_: Exception) {}
        }
    }

    fun openAutostartSettings(context: Context) {
        val oemIntents = listOf(
            // Xiaomi / MIUI / HyperOS
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            // Oppo / Realme
            Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
            Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
            // Vivo
            Intent().setComponent(ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
            Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
            // Samsung
            Intent().setComponent(ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
            Intent().setComponent(ComponentName("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity")),
            // OnePlus
            Intent().setComponent(ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")),
            // Huawei
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"))
        )

        for (intent in oemIntents) {
            try {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return
            } catch (_: Exception) {}
        }

        // Fallback to app details
        openAppBatterySettings(context)
    }

    fun hasAllBackgroundPermissions(context: Context): Boolean {
        return hasUsageStatsPermission(context) && hasOverlayPermission(context) && isBatteryOptimizationIgnored(context)
    }

    // -------------------------------------------------------------
    // FOREGROUND APP DETECTION
    // -------------------------------------------------------------
    fun getForegroundAppPackage(context: Context): String? {
        if (!hasUsageStatsPermission(context)) return null
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 12_000 // Last 12 seconds
        try {
            val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
            var lastForeground: String? = null
            val event = UsageEvents.Event()
            while (usageEvents != null && usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                    lastForeground = event.packageName
                }
            }
            if (!lastForeground.isNullOrBlank()) {
                return lastForeground
            }
        } catch (_: Exception) {}

        // Fallback to queryUsageStats
        return try {
            val stats = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, startTime, endTime)
            stats.filter { it.packageName != null && it.lastTimeUsed > 0 }
                .maxByOrNull { it.lastTimeUsed }?.packageName
        } catch (_: Exception) {
            null
        }
    }

    // -------------------------------------------------------------
    // SERVICE LIFECYCLE
    // -------------------------------------------------------------
    fun startStrictStudyService(context: Context) {
        try {
            val intent = Intent(context, StrictStudyService::class.java).apply {
                action = StrictStudyService.ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Exception) {}
    }

    fun stopStrictStudyService(context: Context) {
        try {
            val intent = Intent(context, StrictStudyService::class.java).apply {
                action = StrictStudyService.ACTION_STOP
            }
            context.startService(intent)
        } catch (_: Exception) {}
    }

    // -------------------------------------------------------------
    // BLOCKED APPS CONFIGURATION
    // -------------------------------------------------------------
    fun isAppBlocked(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val apps = getBlockedApps(context)
        val app = apps.firstOrNull { it.packageName.equals(packageName, ignoreCase = true) }
        // Study apps are strictly whitelisted and never blocked in strict mode
        if (app?.isStudyApp == true) return false
        return app?.isBlocked ?: false
    }

    fun getBlockedApp(context: Context, packageName: String): BlockedApp? {
        val apps = getBlockedApps(context)
        return apps.firstOrNull { it.packageName.equals(packageName, ignoreCase = true) }
    }

    fun getBlockedApps(context: Context): List<BlockedApp> {
        val jsonStr = getPrefs(context).getString(KEY_BLOCKED_APPS_JSON, null)
        if (jsonStr.isNullOrBlank()) {
            val defaults = getDefaultBlockedApps()
            saveBlockedApps(context, defaults)
            return defaults
        }

        return try {
            val jsonArray = JSONArray(jsonStr)
            val list = mutableListOf<BlockedApp>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    BlockedApp(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "App"),
                        packageName = obj.optString("packageName", ""),
                        category = obj.optString("category", "Distraction"),
                        iconEmoji = obj.optString("iconEmoji", "📱"),
                        isBlocked = obj.optBoolean("isBlocked", true),
                        isStudyApp = obj.optBoolean("isStudyApp", false),
                        dailyLimitMinutes = obj.optInt("dailyLimitMinutes", 0)
                    )
                )
            }
            if (list.isEmpty()) getDefaultBlockedApps() else list
        } catch (_: Exception) {
            getDefaultBlockedApps()
        }
    }

    fun saveBlockedApps(context: Context, apps: List<BlockedApp>) {
        try {
            val jsonArray = JSONArray()
            for (app in apps) {
                val obj = JSONObject().apply {
                    put("id", app.id)
                    put("name", app.name)
                    put("packageName", app.packageName)
                    put("category", app.category)
                    put("iconEmoji", app.iconEmoji)
                    put("isBlocked", app.isBlocked)
                    put("isStudyApp", app.isStudyApp)
                    put("dailyLimitMinutes", app.dailyLimitMinutes)
                }
                jsonArray.put(obj)
            }
            getPrefs(context).edit().putString(KEY_BLOCKED_APPS_JSON, jsonArray.toString()).apply()
        } catch (_: Exception) {}
    }

    fun getDefaultBlockedApps(): List<BlockedApp> {
        return listOf(
            // JEE Study Apps (Whitelisted in Strict Mode & tracked as Study in App Usage)
            BlockedApp(name = "Physics Wallah", packageName = "xyz.penpencil.physicswala", category = "Study & Prep", iconEmoji = "⚡", isBlocked = false, isStudyApp = true),
            BlockedApp(name = "Unacademy", packageName = "com.unacademyapp", category = "Study & Prep", iconEmoji = "🎓", isBlocked = false, isStudyApp = true),
            BlockedApp(name = "ALLEN", packageName = "com.allen.allenapp", category = "Study & Prep", iconEmoji = "📖", isBlocked = false, isStudyApp = true),
            BlockedApp(name = "Khan Academy", packageName = "org.khanacademy.android", category = "Study & Prep", iconEmoji = "🧠", isBlocked = false, isStudyApp = true),
            BlockedApp(name = "Doubtnut", packageName = "com.doubtnutapp", category = "Study & Prep", iconEmoji = "❓", isBlocked = false, isStudyApp = true),

            // Distraction Apps (Guarded & Blocked during Strict Study timetable slots)
            BlockedApp(name = "Instagram", packageName = "com.instagram.android", category = "Social Media", iconEmoji = "📸", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "YouTube", packageName = "com.google.android.youtube", category = "Video & Shorts", iconEmoji = "▶️", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Snapchat", packageName = "com.snapchat.android", category = "Social Media", iconEmoji = "👻", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Facebook", packageName = "com.facebook.katana", category = "Social Media", iconEmoji = "👤", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "X / Twitter", packageName = "com.twitter.android", category = "Social Media", iconEmoji = "✖️", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Reddit", packageName = "com.reddit.frontpage", category = "Social Media", iconEmoji = "🤖", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "TikTok", packageName = "com.zhiliaoapp.musically", category = "Shorts", iconEmoji = "🎵", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "BGMI / PUBG", packageName = "com.pubg.imobile", category = "Games", iconEmoji = "🎮", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Free Fire", packageName = "com.dts.freefireth", category = "Games", iconEmoji = "🔥", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Netflix", packageName = "com.netflix.mediaclient", category = "Streaming", iconEmoji = "🎬", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Prime Video", packageName = "com.amazon.avod.thirdpartyclient", category = "Streaming", iconEmoji = "🍿", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "Discord", packageName = "com.discord", category = "Social", iconEmoji = "🎧", isBlocked = true, isStudyApp = false),
            BlockedApp(name = "WhatsApp", packageName = "com.whatsapp", category = "Messaging", iconEmoji = "💬", isBlocked = false, isStudyApp = false),
            BlockedApp(name = "Chrome / Browser", packageName = "com.android.chrome", category = "Browser", iconEmoji = "🌐", isBlocked = false, isStudyApp = false)
        )
    }

    /**
     * Scans user apps installed on the device so the user can easily pick from installed apps.
     */
    fun getInstalledUserApps(context: Context): List<BlockedApp> {
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val result = mutableListOf<BlockedApp>()
        val currentBlocked = getBlockedApps(context)
        val currentPkgSet = currentBlocked.map { it.packageName.lowercase() }.toSet()

        for (info in installed) {
            // Exclude our own app
            if (info.packageName == context.packageName) continue

            // Only consider apps that have a launcher activity or are non-system apps
            val launchIntent = pm.getLaunchIntentForPackage(info.packageName)
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0

            // Skip system apps that don't have launcher intents
            if (isSystem && launchIntent == null) continue

            val appName = try {
                pm.getApplicationLabel(info).toString()
            } catch (_: Exception) {
                info.packageName
            }

            // Exclude key system components (like Android System, System UI, Settings)
            val pkg = info.packageName.lowercase()
            if (pkg.startsWith("com.android.systemui") ||
                pkg.startsWith("android") ||
                pkg.startsWith("com.google.android.inputmethod") ||
                pkg.startsWith("com.google.android.dialer") ||
                pkg.startsWith("com.android.dialer") ||
                pkg.contains("launcher")
            ) {
                continue
            }

            val category = when {
                pkg.contains("game") || pkg.contains("pubg") || pkg.contains("freefire") -> "Games"
                pkg.contains("video") || pkg.contains("youtube") || pkg.contains("netflix") || pkg.contains("prime") -> "Streaming"
                pkg.contains("insta") || pkg.contains("snap") || pkg.contains("face") || pkg.contains("twitter") || pkg.contains("reddit") -> "Social Media"
                pkg.contains("chat") || pkg.contains("message") || pkg.contains("whats") || pkg.contains("telegram") -> "Messaging"
                else -> "Installed App"
            }

            val emoji = when (category) {
                "Games" -> "🎮"
                "Streaming" -> "🎬"
                "Social Media" -> "📸"
                "Messaging" -> "💬"
                else -> "📱"
            }

            val isAlreadyBlocked = currentBlocked.firstOrNull { it.packageName.equals(info.packageName, ignoreCase = true) }?.isBlocked ?: false

            result.add(
                BlockedApp(
                    name = appName,
                    packageName = info.packageName,
                    category = category,
                    iconEmoji = emoji,
                    isBlocked = isAlreadyBlocked
                )
            )
        }

        return result.sortedBy { it.name }
    }

    // -------------------------------------------------------------
    // EMERGENCY BREAK & CHALLENGE
    // -------------------------------------------------------------
    fun grantEmergencyBreak(context: Context, durationMinutes: Int = 2) {
        val until = System.currentTimeMillis() + (durationMinutes * 60 * 1000L)
        getPrefs(context).edit().putLong(KEY_EMERGENCY_UNLOCK_UNTIL, until).apply()
    }

    fun isEmergencyUnlocked(context: Context): Boolean {
        val until = getPrefs(context).getLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L)
        return System.currentTimeMillis() < until
    }

    fun getEmergencyRemainingSeconds(context: Context): Long {
        val until = getPrefs(context).getLong(KEY_EMERGENCY_UNLOCK_UNTIL, 0L)
        val diff = until - System.currentTimeMillis()
        return if (diff > 0) diff / 1000 else 0L
    }

    fun openDigitalWellbeingSettings(context: Context) {
        val intents = listOf(
            Intent("android.settings.DIGITAL_WELLBEING"),
            Intent("android.settings.ZEN_MODE_AUTOMATION_SETTINGS"),
            Intent(Settings.ACTION_SOUND_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in intents) {
            try {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return
            } catch (_: Exception) {}
        }
    }
}
