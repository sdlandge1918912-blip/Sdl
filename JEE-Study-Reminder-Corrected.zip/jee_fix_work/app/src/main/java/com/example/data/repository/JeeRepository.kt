package com.example.data.repository

import com.example.data.dao.ExamDao
import com.example.data.dao.FormulaDao
import com.example.data.dao.MistakeDao
import com.example.data.dao.MockTestDao
import com.example.data.dao.RoutineSessionDao
import com.example.data.dao.StudyReminderDao
import com.example.data.dao.StudySessionDao
import com.example.data.dao.SyllabusDao
import com.example.data.model.ExamEvent
import com.example.data.model.FormulaCard
import com.example.data.model.MistakeItem
import com.example.data.model.MockTestRecord
import com.example.data.model.RoutineSession
import com.example.data.model.StudyReminder
import com.example.data.model.StudySession
import com.example.data.model.SyllabusTopic
import kotlinx.coroutines.flow.Flow

class JeeRepository(
    private val examDao: ExamDao,
    private val routineSessionDao: RoutineSessionDao,
    private val reminderDao: StudyReminderDao,
    private val syllabusDao: SyllabusDao,
    private val mockTestDao: MockTestDao,
    private val formulaDao: FormulaDao,
    private val sessionDao: StudySessionDao,
    private val mistakeDao: MistakeDao
) {
    // Routine Sessions
    val allRoutineSessions: Flow<List<RoutineSession>> = routineSessionDao.getAllRoutineSessions()
    suspend fun getAllRoutineSessionsSync(): List<RoutineSession> = routineSessionDao.getAllRoutineSessionsSync()
    suspend fun insertRoutineSession(session: RoutineSession) = routineSessionDao.insertSession(session)
    suspend fun updateRoutineSession(session: RoutineSession) = routineSessionDao.updateSession(session)
    suspend fun deleteRoutineSession(session: RoutineSession) = routineSessionDao.deleteSession(session)
    suspend fun toggleRoutineNotification(id: Long, enabled: Boolean) = routineSessionDao.toggleNotification(id, enabled)
    suspend fun resetDefaultRoutine(defaultSessions: List<RoutineSession>) {
        routineSessionDao.deleteAll()
        routineSessionDao.insertAll(defaultSessions)
    }

    // Exams
    val allExams: Flow<List<ExamEvent>> = examDao.getAllExams()
    val targetExam: Flow<ExamEvent?> = examDao.getTargetExam()
    suspend fun insertExam(exam: ExamEvent) = examDao.insertExam(exam)
    suspend fun updateExam(exam: ExamEvent) = examDao.updateExam(exam)
    suspend fun deleteExam(exam: ExamEvent) = examDao.deleteExam(exam)
    suspend fun setTargetExam(id: Long) = examDao.setTargetExam(id)

    // Reminders
    val allReminders: Flow<List<StudyReminder>> = reminderDao.getAllReminders()
    suspend fun insertReminder(reminder: StudyReminder) = reminderDao.insertReminder(reminder)
    suspend fun updateReminder(reminder: StudyReminder) = reminderDao.updateReminder(reminder)
    suspend fun deleteReminder(reminder: StudyReminder) = reminderDao.deleteReminder(reminder)
    suspend fun setReminderCompleted(id: Long, completed: Boolean) = reminderDao.setCompleted(id, completed)
    suspend fun resetReminders(reminders: List<StudyReminder>) {
        reminderDao.deleteAllReminders()
        reminderDao.insertAll(reminders)
    }

    // Syllabus
    val allTopics: Flow<List<SyllabusTopic>> = syllabusDao.getAllTopics()
    fun getTopicsBySubject(subject: String): Flow<List<SyllabusTopic>> = syllabusDao.getTopicsBySubject(subject)
    suspend fun setTopicCompleted(id: Long, completed: Boolean) = syllabusDao.setCompleted(id, completed)
    suspend fun setPyqSolved(id: Long, solved: Boolean) = syllabusDao.setPyqSolved(id, solved)
    suspend fun incrementTopicRevision(id: Long) = syllabusDao.incrementRevision(id)
    suspend fun resetDefaultSyllabus(topics: List<SyllabusTopic>) {
        syllabusDao.deleteAll()
        syllabusDao.insertAll(topics)
    }
    suspend fun resetSyllabusProgress() = syllabusDao.resetAllProgress()

    // Mock Tests
    val allMockTests: Flow<List<MockTestRecord>> = mockTestDao.getAllMockTests()
    suspend fun insertMockTest(test: MockTestRecord) = mockTestDao.insertMockTest(test)
    suspend fun deleteMockTest(test: MockTestRecord) = mockTestDao.deleteMockTest(test)
    suspend fun resetDefaultMockTests(mockTests: List<MockTestRecord>) {
        mockTestDao.deleteAllMockTests()
        mockTestDao.insertAll(mockTests)
    }

    // Formulas
    val allFormulas: Flow<List<FormulaCard>> = formulaDao.getAllFormulas()
    suspend fun toggleFormulaBookmark(id: Long, bookmarked: Boolean) = formulaDao.toggleBookmark(id, bookmarked)
    suspend fun insertFormula(formula: FormulaCard) = formulaDao.insertFormula(formula)
    suspend fun resetDefaultFormulas(formulas: List<FormulaCard>) {
        formulaDao.deleteAllFormulas()
        formulaDao.insertAll(formulas)
    }

    // Study Sessions
    val allSessions: Flow<List<StudySession>> = sessionDao.getAllSessions()
    suspend fun getAllSessionsSync(): List<StudySession> = sessionDao.getAllSessionsSync()
    fun getSessionsBySubject(subject: String): Flow<List<StudySession>> = sessionDao.getSessionsBySubject(subject)
    fun getFocusSecondsSince(timestamp: Long): Flow<Long?> = sessionDao.getTotalFocusSecondsSince(timestamp)
    suspend fun logSession(session: StudySession) = sessionDao.insertSession(session)
    suspend fun insertAllStudySessions(sessions: List<StudySession>) = sessionDao.insertAll(sessions)
    suspend fun deleteSession(session: StudySession) = sessionDao.deleteSession(session)
    suspend fun deleteSessionById(id: Long) = sessionDao.deleteSessionById(id)

    // Mistakes
    val allMistakes: Flow<List<MistakeItem>> = mistakeDao.getAllMistakes()
    val unresolvedMistakeCount: Flow<Int> = mistakeDao.getUnresolvedCount()
    suspend fun insertMistake(mistake: MistakeItem) = mistakeDao.insertMistake(mistake)
    suspend fun updateMistake(mistake: MistakeItem) = mistakeDao.updateMistake(mistake)
    suspend fun deleteMistake(mistake: MistakeItem) = mistakeDao.deleteMistake(mistake)
    suspend fun setMistakeResolved(id: Long, resolved: Boolean) = mistakeDao.setResolved(id, resolved)
    suspend fun resetDefaultMistakes(mistakes: List<MistakeItem>) {
        mistakeDao.deleteAllMistakes()
        mistakeDao.insertAll(mistakes)
    }

    // Exams restore
    suspend fun resetDefaultExams(exams: List<ExamEvent>) {
        examDao.deleteAllExams()
        examDao.insertAll(exams)
        val target = examDao.getJee2028Exam()
        if (target != null) {
            examDao.setTargetExam(target.id)
        }
    }
}
