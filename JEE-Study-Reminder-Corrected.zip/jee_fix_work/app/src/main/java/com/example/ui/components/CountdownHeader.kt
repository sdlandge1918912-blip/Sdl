package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamEvent
import kotlinx.coroutines.delay

@Composable
fun CountdownHeader(
    targetExam: ExamEvent?,
    allExams: List<ExamEvent> = emptyList(),
    onSelectTargetExam: (Long) -> Unit = {},
    onAddNewExamClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showDropdown by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            currentTime = System.currentTimeMillis()
        }
    }

    val defaultJee2028 = remember {
        java.util.Calendar.getInstance().apply {
            set(2028, java.util.Calendar.JANUARY, 24, 9, 0, 0)
        }.timeInMillis
    }
    val examTime = targetExam?.examDateMillis ?: defaultJee2028
    val diff = (examTime - currentTime).coerceAtLeast(0)

    val days = diff / (24 * 3600 * 1000)
    val hours = (diff % (24 * 3600 * 1000)) / (3600 * 1000)
    val minutes = (diff % (3600 * 1000)) / (60 * 1000)
    val seconds = (diff % (60 * 1000)) / 1000

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { showDropdown = true },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131D36))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = targetExam?.title ?: "JEE Main 2028 (Session 1)",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E3A8A))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "SWITCH EXAM ▼",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF93C5FD)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CountdownTimeBlock(value = "%02d".format(days), label = "DAYS")
                CountdownTimeBlock(value = "%02d".format(hours), label = "HOURS")
                CountdownTimeBlock(value = "%02d".format(minutes), label = "MINS")
                CountdownTimeBlock(value = "%02d".format(seconds), label = "SECS")
            }

            DropdownMenu(
                expanded = showDropdown,
                onDismissRequest = { showDropdown = false },
                modifier = Modifier.background(Color(0xFF1E293B))
            ) {
                allExams.forEach { exam ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = exam.title,
                                color = if (exam.id == targetExam?.id) Color(0xFF60A5FA) else Color.White,
                                fontWeight = if (exam.id == targetExam?.id) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        onClick = {
                            onSelectTargetExam(exam.id)
                            showDropdown = false
                        }
                    )
                }
                HorizontalDivider(color = Color(0xFF334155))
                DropdownMenuItem(
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Custom Exam Target", color = Color(0xFF60A5FA))
                        }
                    },
                    onClick = {
                        showDropdown = false
                        onAddNewExamClick()
                    }
                )
            }
        }
    }
}

@Composable
fun CountdownTimeBlock(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0F172A))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF94A3B8)
        )
    }
}
