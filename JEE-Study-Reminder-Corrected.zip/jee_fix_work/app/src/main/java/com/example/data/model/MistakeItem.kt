package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mistake_items")
data class MistakeItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subject: String, // "Physics", "Chemistry", "Mathematics"
    val chapter: String,
    val questionSummary: String,
    val mistakeType: String, // "Calculation Error", "Conceptual Flaw", "Misread Question", "Formula Forgotten"
    val correctiveAction: String,
    val isResolved: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
