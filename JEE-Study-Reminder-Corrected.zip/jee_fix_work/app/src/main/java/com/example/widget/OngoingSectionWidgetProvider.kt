package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.database.AppDatabase
import com.example.data.database.DefaultJeeData
import com.example.data.model.RoutineSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class OngoingSectionWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == ACTION_REFRESH_ONGOING_WIDGET ||
            action == Intent.ACTION_TIME_TICK ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == AppWidgetManager.ACTION_APPWIDGET_UPDATE
        ) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, OngoingSectionWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId)
            }
        }
    }

    companion object {
        const val ACTION_REFRESH_ONGOING_WIDGET = "com.example.widget.ACTION_REFRESH_ONGOING_WIDGET"

        fun updateAllWidgets(context: Context) {
            try {
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val thisWidget = ComponentName(context, OngoingSectionWidgetProvider::class.java)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
                if (appWidgetIds.isNotEmpty()) {
                    for (id in appWidgetIds) {
                        updateAppWidget(context, appWidgetManager, id)
                    }
                }
            } catch (e: Exception) {
                Log.e("OngoingSectionWidget", "Failed to update ongoing widgets", e)
            }
        }

        private fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            // Immediate synchronous render for instantaneous launcher responsiveness
            val initialList = DefaultJeeData.getDefaultRoutineSessions()
            renderWidget(context, appWidgetManager, appWidgetId, initialList)

            // Async sync with database
            val scope = CoroutineScope(Dispatchers.IO)
            scope.launch {
                try {
                    val db = AppDatabase.getDatabase(context, scope)
                    val dbList = db.routineSessionDao().getAllRoutineSessionsSync()
                    val finalList = if (dbList.isNotEmpty()) dbList else initialList
                    withContext(Dispatchers.Main) {
                        renderWidget(context, appWidgetManager, appWidgetId, finalList)
                    }
                } catch (e: Exception) {
                    Log.w("OngoingSectionWidget", "Could not fetch DB sessions, fallback rendered", e)
                }
            }
        }

        private fun renderWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            sessions: List<RoutineSession>
        ) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_ongoing_section)

                val now = Calendar.getInstance()
                val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

                var activeSession: RoutineSession? = null
                var activeRemainingMin = 0
                var activeElapsedPercent = 0

                for (session in sessions) {
                    val startM = parseTimeToMinutes(session.startTime)
                    val endM = parseTimeToMinutes(session.endTime)
                    if (startM != null && endM != null) {
                        val isOngoing = if (endM > startM) {
                            currentMinutes in startM until endM
                        } else if (endM < startM) {
                            currentMinutes >= startM || currentMinutes < endM
                        } else {
                            currentMinutes in startM until (startM + 15)
                        }

                        if (isOngoing) {
                            activeSession = session
                            val actualEnd = if (endM == startM) startM + 15 else endM
                            activeRemainingMin = if (actualEnd >= currentMinutes) actualEnd - currentMinutes else (actualEnd + 1440 - currentMinutes)
                            val totalDuration = if (endM >= startM) (endM - startM).coerceAtLeast(1) else (endM + 1440 - startM)
                            val elapsed = (totalDuration - activeRemainingMin).coerceAtLeast(0)
                            activeElapsedPercent = ((elapsed.toFloat() / totalDuration.toFloat()) * 100).toInt().coerceIn(0, 100)
                            break
                        }
                    }
                }

                // If no active session, find upcoming
                var nextSession: RoutineSession? = null
                var nextStartsInMin = 0
                for (session in sessions) {
                    val startM = parseTimeToMinutes(session.startTime)
                    if (startM != null) {
                        val wait = if (startM >= currentMinutes) (startM - currentMinutes) else (startM + 1440 - currentMinutes)
                        if (nextSession == null || wait < nextStartsInMin) {
                            nextSession = session
                            nextStartsInMin = wait
                        }
                    }
                }
                if (nextSession == null && sessions.isNotEmpty()) {
                    nextSession = sessions.first()
                }

                if (activeSession != null) {
                    views.setTextViewText(R.id.widget_ongoing_badge, "⚡ ONGOING NOW")
                    try {
                        views.setInt(
                            R.id.widget_ongoing_badge,
                            "setBackgroundResource",
                            R.drawable.widget_badge_active
                        )
                    } catch (_: Exception) {}
                    views.setTextColor(R.id.widget_ongoing_badge, android.graphics.Color.parseColor("#30D158"))

                    views.setTextViewText(R.id.widget_ongoing_time_window, activeSession.getFormattedTime())
                    views.setTextViewText(R.id.widget_ongoing_emoji, activeSession.emoji.ifBlank { "⚡" })
                    views.setTextViewText(R.id.widget_ongoing_title, activeSession.title)

                    val sub = if (!activeSession.focusTopic.isNullOrBlank()) {
                        "${activeSession.category} • ${activeSession.focusTopic}"
                    } else {
                        "${activeSession.category} Routine Slot"
                    }
                    views.setTextViewText(R.id.widget_ongoing_category, sub)

                    val remText = if (activeRemainingMin > 0) "⏳ Still ${activeRemainingMin}m remaining" else "⏳ Ending now"
                    views.setTextViewText(R.id.widget_ongoing_countdown, remText)
                    views.setTextColor(R.id.widget_ongoing_countdown, android.graphics.Color.parseColor("#38BDF8"))

                    views.setTextViewText(R.id.widget_ongoing_progress_text, "${activeElapsedPercent}% elapsed")
                    views.setTextViewText(R.id.widget_ongoing_btn_focus, "🎯 Focus Mode")
                    views.setTextViewText(R.id.widget_ongoing_btn_open, "📋 Timetable")
                } else if (nextSession != null) {
                    views.setTextViewText(R.id.widget_ongoing_badge, "⏰ UPCOMING NEXT")
                    try {
                        views.setInt(
                            R.id.widget_ongoing_badge,
                            "setBackgroundResource",
                            R.drawable.widget_badge_next
                        )
                    } catch (_: Exception) {}
                    views.setTextColor(R.id.widget_ongoing_badge, android.graphics.Color.parseColor("#FF9F0A"))

                    views.setTextViewText(R.id.widget_ongoing_time_window, "At ${nextSession.getFormattedTime()}")
                    views.setTextViewText(R.id.widget_ongoing_emoji, nextSession.emoji.ifBlank { "☕" })
                    views.setTextViewText(R.id.widget_ongoing_title, nextSession.title)
                    views.setTextViewText(R.id.widget_ongoing_category, "${nextSession.category} • Break/Preparation")

                    val waitText = if (nextStartsInMin > 0) "⏳ Starts in ${nextStartsInMin}m" else "⏳ Starting soon"
                    views.setTextViewText(R.id.widget_ongoing_countdown, waitText)
                    views.setTextColor(R.id.widget_ongoing_countdown, android.graphics.Color.parseColor("#FF9F0A"))

                    views.setTextViewText(R.id.widget_ongoing_progress_text, "Prep window")
                    views.setTextViewText(R.id.widget_ongoing_btn_focus, "⏱️ Quick Timer")
                    views.setTextViewText(R.id.widget_ongoing_btn_open, "📋 Timetable")
                } else {
                    views.setTextViewText(R.id.widget_ongoing_badge, "✨ FREE TIME")
                    views.setTextViewText(R.id.widget_ongoing_time_window, "")
                    views.setTextViewText(R.id.widget_ongoing_emoji, "☕")
                    views.setTextViewText(R.id.widget_ongoing_title, "Daily Routine Complete")
                    views.setTextViewText(R.id.widget_ongoing_category, "Relax, review formulas & rest well")
                    views.setTextViewText(R.id.widget_ongoing_countdown, "Rest Period")
                    views.setTextColor(R.id.widget_ongoing_countdown, android.graphics.Color.parseColor("#94A3B8"))
                    views.setTextViewText(R.id.widget_ongoing_progress_text, "100% complete")
                    views.setTextViewText(R.id.widget_ongoing_btn_focus, "🎯 Open App")
                    views.setTextViewText(R.id.widget_ongoing_btn_open, "📋 Timetable")
                }

                // Click root or Timetable button -> opens app
                val openIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingOpen = PendingIntent.getActivity(
                    context,
                    101,
                    openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_ongoing_root, pendingOpen)
                views.setOnClickPendingIntent(R.id.widget_ongoing_btn_open, pendingOpen)

                // Click Focus button -> opens app to Focus screen
                val focusIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("START_FOCUS_SESSION", true)
                }
                val pendingFocus = PendingIntent.getActivity(
                    context,
                    102,
                    focusIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_ongoing_btn_focus, pendingFocus)

                // Refresh button
                val refreshIntent = Intent(context, OngoingSectionWidgetProvider::class.java).apply {
                    action = ACTION_REFRESH_ONGOING_WIDGET
                }
                val pendingRefresh = PendingIntent.getBroadcast(
                    context,
                    appWidgetId,
                    refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_ongoing_btn_refresh, pendingRefresh)

                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (e: Exception) {
                Log.e("OngoingSectionWidget", "Error rendering widget", e)
            }
        }

        private fun parseTimeToMinutes(timeStr: String): Int? {
            val parts = timeStr.trim().split(":")
            if (parts.size >= 2) {
                val h = parts[0].toIntOrNull() ?: return null
                val m = parts[1].toIntOrNull() ?: return null
                return h * 60 + m
            }
            return null
        }
    }
}
