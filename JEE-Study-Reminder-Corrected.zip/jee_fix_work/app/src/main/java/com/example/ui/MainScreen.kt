package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppBackgroundContainer
import com.example.ui.components.BackgroundEditDialog
import com.example.ui.components.JeeGlassBottomNav
import com.example.ui.components.JeeRestoreDialog
import com.example.ui.components.JeeSettingsDialog
import com.example.ui.components.ParentConnectDialog
import com.example.ui.components.JeeTopAppBar
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FocusAppBlockerScreen
import com.example.ui.screens.PracticeScreen
import com.example.ui.screens.RemindersScreen
import com.example.ui.screens.RoutineScreen
import com.example.ui.screens.SyllabusScreen
import com.example.ui.screens.VideosScreen
import com.example.ui.viewmodel.JeeViewModel

@Composable
fun MainScreen(
    viewModel: JeeViewModel,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(initialTab) }
    var showRemindersPage by remember { mutableStateOf(false) }
    var showStrictStudyScreen by remember { mutableStateOf(false) }
    var showBgDialog by remember { mutableStateOf(false) }
    var showWhatsNewDialog by remember { mutableStateOf(true) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showParentConnectDialog by remember { mutableStateOf(false) }

    val parentPairingStatus by viewModel.parentPairingStatus.collectAsStateWithLifecycle()

    LaunchedEffect(initialTab) {
        selectedTab = initialTab
    }

    val routineSessions by viewModel.routineSessions.collectAsStateWithLifecycle()
    val allExams by viewModel.exams.collectAsStateWithLifecycle()
    val targetExam by viewModel.targetExam.collectAsStateWithLifecycle()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()
    val syllabusTopics by viewModel.syllabusTopics.collectAsStateWithLifecycle()
    val mockTests by viewModel.mockTests.collectAsStateWithLifecycle()
    val unresolvedCount by viewModel.unresolvedMistakeCount.collectAsStateWithLifecycle()
    val isSectionNotificationEnabled by viewModel.isSectionNotificationEnabled.collectAsStateWithLifecycle()
    val completedSessionIds by viewModel.completedSessionIds.collectAsStateWithLifecycle()
    val isFocusShieldActive by viewModel.isFocusShieldActive.collectAsStateWithLifecycle()
    val isOngoingStudySlot by viewModel.isOngoingStudySlot.collectAsStateWithLifecycle()
    val isOngoingBreakSlot by viewModel.isOngoingBreakSlot.collectAsStateWithLifecycle()
    val hasBatteryExemption by viewModel.hasBatteryExemption.collectAsStateWithLifecycle()

    BackHandler(enabled = showStrictStudyScreen) {
        showStrictStudyScreen = false
    }

    BackHandler(enabled = !showStrictStudyScreen && showRemindersPage) {
        showRemindersPage = false
    }

    BackHandler(enabled = !showStrictStudyScreen && !showRemindersPage && selectedTab != 0) {
        selectedTab = 0
    }

    val bgType by viewModel.backgroundType.collectAsStateWithLifecycle()
    val bgPreset by viewModel.backgroundPreset.collectAsStateWithLifecycle()
    val customBgUri by viewModel.customBgUri.collectAsStateWithLifecycle()
    val blurIntensity by viewModel.blurIntensity.collectAsStateWithLifecycle()
    val bgDimOpacity by viewModel.bgDimOpacity.collectAsStateWithLifecycle()

    AppBackgroundContainer(
        bgType = bgType,
        bgPreset = bgPreset,
        customUri = customBgUri,
        blurIntensity = blurIntensity,
        dimOpacity = bgDimOpacity,
        modifier = modifier.fillMaxSize()
    ) {
        if (showStrictStudyScreen) {
            FocusAppBlockerScreen(
                viewModel = viewModel,
                onNavigateToRoutine = {
                    showStrictStudyScreen = false
                    selectedTab = 1
                },
                onNavigateToPractice = {
                    showStrictStudyScreen = false
                    selectedTab = 3
                },
                onClose = { showStrictStudyScreen = false }
            )
        } else if (showRemindersPage) {
            RemindersScreen(
                reminders = reminders,
                onToggleReminder = { viewModel.toggleReminder(it) },
                onDeleteReminder = { viewModel.deleteReminder(it) },
                onSendNotification = { /* alert feedback */ },
                onAddReminder = { title, subj, due, prio, notes, rec ->
                    viewModel.addReminder(title, subj, due, prio, notes, rec)
                },
                onResetToTimetable = { viewModel.resetRemindersToTimetable() },
                onBack = { showRemindersPage = false },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Scaffold(
                topBar = {
                    JeeTopAppBar(
                        onOpenSettings = { showSettingsDialog = true },
                        onOpenStrictStudy = { showStrictStudyScreen = true },
                        isStrictStudyActive = isFocusShieldActive,
                        unreadNotificationsCount = 10
                    )
                },
                bottomBar = {
                    JeeGlassBottomNav(
                        selectedTab = selectedTab,
                        onSelectTab = { selectedTab = it }
                    )
                },
                containerColor = Color.Transparent,
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedTab) {
                        0 -> DashboardScreen(
                            viewModel = viewModel,
                            targetExam = targetExam,
                            allExams = allExams,
                            reminders = reminders,
                            routineSessions = routineSessions,
                            syllabusTopics = syllabusTopics,
                            mockTests = mockTests,
                            onSelectTargetExam = { examId -> viewModel.setTargetExam(examId) },
                            onAddNewExam = { title, dateMillis, category, notes ->
                                viewModel.addCustomExam(title, dateMillis, category, notes, setAsTarget = true)
                            },
                            onToggleReminder = { viewModel.toggleReminder(it) },
                            onSendNotification = { },
                            onNavigateToTab = { targetIndex ->
                                selectedTab = targetIndex
                            },
                            onOpenRemindersPage = { showRemindersPage = true },
                            onOpenAddReminder = { showRemindersPage = true },
                            onResetRemindersToTimetable = { viewModel.resetRemindersToTimetable() },
                            completedSessionIds = completedSessionIds,
                            onToggleSessionCompletion = { viewModel.toggleSessionCompletion(it) },
                            onEditBackground = { showBgDialog = true },
                            isStrictStudyActive = isFocusShieldActive,
                            isOngoingStudySlot = isOngoingStudySlot,
                            isOngoingBreakSlot = isOngoingBreakSlot,
                            hasBatteryExemption = hasBatteryExemption,
                            onOpenStrictStudyMode = { showStrictStudyScreen = true },
                            onOpenRestoreBackup = { showRestoreDialog = true },
                            onOpenParentConnect = { showParentConnectDialog = true }
                        )

                        1 -> RoutineScreen(
                            viewModel = viewModel,
                            onNavigateToReminders = { showRemindersPage = true },
                            modifier = Modifier.fillMaxSize()
                        )

                        2 -> SyllabusScreen(
                            topics = syllabusTopics,
                            onToggleTopicCompleted = { viewModel.toggleTopicCompleted(it) },
                            onTogglePyqSolved = { viewModel.togglePyqSolved(it) },
                            onIncrementRevision = { viewModel.incrementTopicRevision(it) },
                            onRestoreSyllabus = { resetProgressOnly ->
                                viewModel.restoreDefaultSyllabus(resetProgressOnly)
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        3 -> PracticeScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )

                        4 -> VideosScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Wallpaper Customization Modal
            if (showBgDialog) {
                BackgroundEditDialog(
                    currentType = bgType,
                    currentPreset = bgPreset,
                    currentUri = customBgUri,
                    blurIntensity = blurIntensity,
                    dimOpacity = bgDimOpacity,
                    onSelectPreset = { viewModel.setBackgroundPreset(it) },
                    onSelectCustomUri = { viewModel.setCustomBackgroundUri(it) },
                    onChangeBlur = { viewModel.setBlurIntensity(it) },
                    onChangeDim = { viewModel.setBgDimOpacity(it) },
                    onResetDefault = { viewModel.resetBackgroundToDefault() },
                    onDismiss = { showBgDialog = false }
                )
            }

            // Unified Settings Dialog containing Wallpaper, APK, and Notifications
            if (showSettingsDialog) {
                JeeSettingsDialog(
                    onDismiss = { showSettingsDialog = false },
                    onOpenWallpaper = { showBgDialog = true },
                    onApkClick = {
                        Toast.makeText(
                            context,
                            "JEE Reminder v2.2 APK updated at /JEE_Reminder_v2.2.apk in project root",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    onOpenNotifications = { showRemindersPage = true },
                    onOpenWhatsNew = { showWhatsNewDialog = true },
                    isSectionAlarmsEnabled = isSectionNotificationEnabled,
                    onToggleSectionAlarms = { viewModel.toggleSectionNotifications(it) },
                    onTestSectionAlarm = { viewModel.testSectionNotification() },
                    unreadNotificationsCount = 10,
                    isStrictStudyEnabled = isFocusShieldActive,
                    onToggleStrictStudy = { viewModel.toggleFocusShield(it) },
                    onOpenStrictStudyMode = { showStrictStudyScreen = true },
                    onOpenRestoreBackup = { showRestoreDialog = true },
                    onOpenParentConnect = { showParentConnectDialog = true },
                    parentPairingStatus = parentPairingStatus
                )
            }

            // Parent Oversight & Connect Dialog
            if (showParentConnectDialog) {
                ParentConnectDialog(
                    viewModel = viewModel,
                    onDismiss = { showParentConnectDialog = false }
                )
            }

            // Restore & Backup Dialog
            if (showRestoreDialog) {
                JeeRestoreDialog(
                    viewModel = viewModel,
                    onDismiss = { showRestoreDialog = false }
                )
            }

            // What's New Dialog (Version 2.2)
            if (showWhatsNewDialog) {
                AlertDialog(
                    onDismissRequest = { showWhatsNewDialog = false },
                    containerColor = Color(0xFF131929),
                    shape = RoundedCornerShape(24.dp),
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF2563EB)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "🚀", fontSize = 18.sp)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "What's New in v2.2",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Version 2.2 • Parent Oversight Live Sync",
                                    color = Color(0xFF60A5FA),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            WhatsNewFeatureItem(
                                emoji = "👨‍👩‍👧‍👦",
                                title = "Parent Oversight Dashboard Sync",
                                desc = "Real-time live syncing of study sessions, daily screen time, and distraction shield logs to Parent Study Dashboard with pairing code JEE789."
                            )
                            WhatsNewFeatureItem(
                                emoji = "🛡️",
                                title = "Strict Study Guard & App Lock",
                                desc = "Blocks Instagram, YouTube, and games during active study slots, automatically notifying parent dashboard on unauthorized attempts."
                            )
                            WhatsNewFeatureItem(
                                emoji = "🔄",
                                title = "Restore Hub & Factory Reset",
                                desc = "1-tap restore for 24-hr daily routine, full Class 11 & 12 NCERT syllabus, and system alarms."
                            )
                            WhatsNewFeatureItem(
                                emoji = "⚡",
                                title = "Real-time Telemetry & Fast Sync",
                                desc = "Firestore telemetry stream to database ai-studio-android-studypul-6e50c8ca-38ff-4712-9a27-72a58cbd0c76 with zero lag."
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showWhatsNewDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Open Version 2.2", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun WhatsNewFeatureItem(
    emoji: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x4D1E293B))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = emoji, fontSize = 20.sp)
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(text = desc, fontSize = 11.sp, color = Color(0xFF94A3B8))
        }
    }
}
