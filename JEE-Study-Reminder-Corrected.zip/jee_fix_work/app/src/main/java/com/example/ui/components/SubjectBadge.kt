package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChemistryGreen
import com.example.ui.theme.MathsRed
import com.example.ui.theme.PhysicsBlue

@Composable
fun SubjectBadge(
    subject: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (subject.uppercase()) {
        "PHYSICS" -> Triple(PhysicsBlue.copy(alpha = 0.15f), PhysicsBlue, "Physics")
        "CHEMISTRY" -> Triple(ChemistryGreen.copy(alpha = 0.15f), ChemistryGreen, "Chemistry")
        "MATHEMATICS" -> Triple(MathsRed.copy(alpha = 0.15f), MathsRed, "Maths")
        "FULL_MOCK" -> Triple(Color(0xFF673AB7).copy(alpha = 0.15f), Color(0xFF673AB7), "Full Mock")
        else -> Triple(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f), MaterialTheme.colorScheme.secondary, "General")
    }

    Text(
        text = label,
        color = textColor,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .background(color = bgColor, shape = RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}
