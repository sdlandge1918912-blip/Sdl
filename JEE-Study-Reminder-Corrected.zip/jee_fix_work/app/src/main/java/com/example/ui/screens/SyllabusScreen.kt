package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SyllabusTopic
import com.example.ui.components.GlassCard

@Composable
fun SyllabusScreen(
    topics: List<SyllabusTopic>,
    onToggleTopicCompleted: (SyllabusTopic) -> Unit,
    onTogglePyqSolved: (SyllabusTopic) -> Unit,
    onIncrementRevision: (SyllabusTopic) -> Unit,
    onRestoreSyllabus: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedSubject by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var showRestoreDialog by remember { mutableStateOf(false) }

    val physicsTopics = remember(topics) { topics.filter { it.subject.equals("PHYSICS", ignoreCase = true) } }
    val chemistryTopics = remember(topics) { topics.filter { it.subject.equals("CHEMISTRY", ignoreCase = true) } }
    val mathsTopics = remember(topics) { topics.filter { it.subject.equals("MATHEMATICS", ignoreCase = true) } }

    val totalCount = topics.size.coerceAtLeast(1)
    val completedCount = topics.count { it.isCompleted }
    val coveragePercent = ((completedCount.toFloat() / totalCount.toFloat()) * 100).toInt()

    val filteredTopics = remember(topics, selectedSubject, searchQuery) {
        topics.filter { topic ->
            val matchSubject = when (selectedSubject) {
                "Physics" -> topic.subject.equals("PHYSICS", ignoreCase = true)
                "Chemistry" -> topic.subject.equals("CHEMISTRY", ignoreCase = true)
                "Maths" -> topic.subject.equals("MATHEMATICS", ignoreCase = true)
                else -> true
            }
            val matchSearch = searchQuery.isBlank() ||
                    topic.chapterName.contains(searchQuery, ignoreCase = true) ||
                    topic.unit.contains(searchQuery, ignoreCase = true)
            matchSubject && matchSearch
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero Card: Official Class 11 NCERT Syllabus
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("syllabus_hero_card"),
                    shape = RoundedCornerShape(24.dp),
                    backgroundColor = Color(0xCC111827),
                    borderColor = Color(0x4038BDF8)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF1E3A8A), Color(0xFF2563EB))
                                        )
                                    )
                                    .border(BorderStroke(1.dp, Color(0x6660A5FA)), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "OFFICIAL SYLLABUS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF38BDF8),
                                    letterSpacing = 0.8.sp
                                )
                                Text(
                                    text = "Class 11 NCERT & JEE",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }
                        }

                        // Syllabi badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x3338BDF8))
                                .border(BorderStroke(1.dp, Color(0x6638BDF8)), RoundedCornerShape(14.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "2028 Blueprint",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Complete JEE Main & Advanced chapter mapping with PYQs tracker and revision logging for high retention.",
                        fontSize = 12.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Overall 11th Syllabus Coverage",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = "$completedCount / $totalCount Ch ($coveragePercent%)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { completedCount.toFloat() / totalCount.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF38BDF8),
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Mini Stat Pills: Physics, Chemistry, Maths
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SubjectMiniStat(
                            name = "Physics",
                            percent = if (physicsTopics.isNotEmpty()) "${((physicsTopics.count { it.isCompleted }.toFloat() / physicsTopics.size) * 100).toInt()}%" else "0%",
                            ratio = "${physicsTopics.count { it.isCompleted }}/${physicsTopics.size} done",
                            color = Color(0xFF38BDF8),
                            modifier = Modifier.weight(1f)
                        )
                        SubjectMiniStat(
                            name = "Chemistry",
                            percent = if (chemistryTopics.isNotEmpty()) "${((chemistryTopics.count { it.isCompleted }.toFloat() / chemistryTopics.size) * 100).toInt()}%" else "0%",
                            ratio = "${chemistryTopics.count { it.isCompleted }}/${chemistryTopics.size} done",
                            color = Color(0xFF34D399),
                            modifier = Modifier.weight(1f)
                        )
                        SubjectMiniStat(
                            name = "Maths",
                            percent = if (mathsTopics.isNotEmpty()) "${((mathsTopics.count { it.isCompleted }.toFloat() / mathsTopics.size) * 100).toInt()}%" else "0%",
                            ratio = "${mathsTopics.count { it.isCompleted }}/${mathsTopics.size} done",
                            color = Color(0xFFFBBF24),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { showRestoreDialog = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Restore / Reset Syllabus",
                                fontSize = 11.sp,
                                color = Color(0xFF38BDF8),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // 2. Translucent Glassy Subject Filter Capsule Tabs
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x990D1526))
                        .border(BorderStroke(1.dp, Color(0x3360A5FA)), RoundedCornerShape(18.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabs = listOf(
                        "All" to "All (${topics.size})",
                        "Physics" to "⚡ Physics (${physicsTopics.size})",
                        "Chemistry" to "🧪 Chem (${chemistryTopics.size})",
                        "Maths" to "📐 Math (${mathsTopics.size})"
                    )

                    tabs.forEach { (key, label) ->
                        val isSelected = selectedSubject == key
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isSelected) Color(0xFF2563EB)
                                    else Color.Transparent
                                )
                                .clickable { selectedSubject = key }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (isSelected) Color.White else Color(0xFF94A3B8),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // 3. Chapter Search Bar in Frosted Glass
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            "Search chapters (e.g. Kinematics, Thermodynamics, Circles...)",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xB8090E1A),
                        unfocusedContainerColor = Color(0x80090E1A),
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0x3360A5FA),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 4. Chapter Count Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CHAPTERS (${filteredTopics.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFA5B4FC),
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Tap circle to complete • Solved PYQs • Log Revisions",
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // 5. Topics list in Frosted Glass Cards
            if (filteredTopics.isEmpty()) {
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        backgroundColor = Color(0x9910172A),
                        borderColor = Color(0x26475569)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🔍", fontSize = 28.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No chapters found matching \"$searchQuery\"",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else {
                items(filteredTopics, key = { it.id }) { topic ->
                    val subjColor = when (topic.subject.uppercase()) {
                        "PHYSICS" -> Color(0xFF38BDF8)
                        "CHEMISTRY" -> Color(0xFF34D399)
                        "MATHEMATICS" -> Color(0xFFFBBF24)
                        else -> Color(0xFF60A5FA)
                    }

                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("topic_card_${topic.id}"),
                        shape = RoundedCornerShape(18.dp),
                        backgroundColor = if (topic.isCompleted) Color(0x800A1220) else Color(0xCC0D1526),
                        borderColor = if (topic.isCompleted) Color(0x4D10B981) else Color(0x3360A5FA),
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Completion Toggle Button
                            IconButton(
                                onClick = { onToggleTopicCompleted(topic) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (topic.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = "Toggle Complete",
                                    tint = if (topic.isCompleted) Color(0xFF10B981) else Color(0xFF64748B),
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                // Subject & Unit Pill
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(subjColor.copy(alpha = 0.2f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = topic.subject.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = subjColor
                                        )
                                    }

                                    Text(
                                        text = topic.unit,
                                        fontSize = 10.sp,
                                        color = Color(0xFF94A3B8)
                                    )

                                    if (topic.isCompleted) {
                                        Text(
                                            text = "• Done ✔",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF34D399)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(3.dp))

                                Text(
                                    text = topic.chapterName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (topic.isCompleted) Color(0xFF94A3B8) else Color.White,
                                    textDecoration = if (topic.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Action Badges Row (PYQ & Revision)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // PYQ Solved Pill Toggle
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (topic.pyqsSolved) Color(0x4010B981) else Color(0x331E293B))
                                            .border(
                                                BorderStroke(1.dp, if (topic.pyqsSolved) Color(0xFF10B981) else Color(0x2660A5FA)),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .clickable { onTogglePyqSolved(topic) }
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (topic.pyqsSolved) Icons.Default.Check else Icons.Default.HistoryEdu,
                                                contentDescription = null,
                                                tint = if (topic.pyqsSolved) Color(0xFF34D399) else Color(0xFF94A3B8),
                                                modifier = Modifier.size(11.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = if (topic.pyqsSolved) "PYQs Solved" else "PYQs Pending",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (topic.pyqsSolved) Color(0xFF34D399) else Color(0xFF94A3B8)
                                            )
                                        }
                                    }

                                    // Revision Count Pill
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (topic.revisionCount > 0) Color(0x338B5CF6) else Color(0x331E293B))
                                            .border(
                                                BorderStroke(1.dp, if (topic.revisionCount > 0) Color(0xFF8B5CF6) else Color(0x2660A5FA)),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .clickable {
                                                onIncrementRevision(topic)
                                                Toast.makeText(context, "${topic.chapterName}: Rev #${topic.revisionCount + 1} logged!", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Autorenew,
                                                contentDescription = null,
                                                tint = if (topic.revisionCount > 0) Color(0xFFA78BFA) else Color(0xFF94A3B8),
                                                modifier = Modifier.size(11.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = if (topic.revisionCount > 0) "${topic.revisionCount}x Rev" else "+1 Rev",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (topic.revisionCount > 0) Color(0xFFA78BFA) else Color(0xFF94A3B8)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showRestoreDialog) {
            AlertDialog(
                onDismissRequest = { showRestoreDialog = false },
                containerColor = Color(0xFF131929),
                shape = RoundedCornerShape(22.dp),
                icon = {
                    Icon(
                        imageVector = Icons.Default.Restore,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(32.dp)
                    )
                },
                title = {
                    Text(
                        text = "Restore Syllabus Tracker",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Choose how you want to restore your syllabus tracker:",
                            color = Color(0xFFCBD5E1),
                            fontSize = 13.sp
                        )

                        Button(
                            onClick = {
                                onRestoreSyllabus(true) // Reset progress only
                                showRestoreDialog = false
                                Toast.makeText(context, "Syllabus progress reset to 0%", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0C4A6E)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Reset All Checkmarks to 0%", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF38BDF8))
                        }

                        Button(
                            onClick = {
                                onRestoreSyllabus(false) // Full restore
                                showRestoreDialog = false
                                Toast.makeText(context, "Official Class 11 & 12 NCERT Syllabus restored", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Restore Full NCERT Chapter List", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showRestoreDialog = false }) {
                        Text("Cancel", color = Color(0xFF94A3B8))
                    }
                }
            )
        }
    }
}

@Composable
private fun SubjectMiniStat(
    name: String,
    percent: String,
    ratio: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x66182236))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.4f)), RoundedCornerShape(14.dp))
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = name, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                Text(text = percent, fontSize = 11.sp, color = color, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = ratio, fontSize = 9.sp, color = Color(0xFF94A3B8))
        }
    }
}
