package com.example.data.dao

import androidx.room.*
import com.example.data.model.SyllabusTopic
import kotlinx.coroutines.flow.Flow

@Dao
interface SyllabusDao {
    @Query("SELECT * FROM syllabus_topics ORDER BY subject, standardClass, id ASC")
    fun getAllTopics(): Flow<List<SyllabusTopic>>

    @Query("SELECT * FROM syllabus_topics WHERE subject = :subject ORDER BY standardClass, id ASC")
    fun getTopicsBySubject(subject: String): Flow<List<SyllabusTopic>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: SyllabusTopic): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(topics: List<SyllabusTopic>)

    @Update
    suspend fun updateTopic(topic: SyllabusTopic)

    @Query("UPDATE syllabus_topics SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)

    @Query("UPDATE syllabus_topics SET pyqsSolved = :solved WHERE id = :id")
    suspend fun setPyqSolved(id: Long, solved: Boolean)

    @Query("UPDATE syllabus_topics SET revisionCount = revisionCount + 1 WHERE id = :id")
    suspend fun incrementRevision(id: Long)

    @Query("SELECT COUNT(*) FROM syllabus_topics")
    suspend fun countTopics(): Int

    @Query("DELETE FROM syllabus_topics")
    suspend fun deleteAll()

    @Query("UPDATE syllabus_topics SET isCompleted = 0, pyqsSolved = 0, revisionCount = 0")
    suspend fun resetAllProgress()
}
