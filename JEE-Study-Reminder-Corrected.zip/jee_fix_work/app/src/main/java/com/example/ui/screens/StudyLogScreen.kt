package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.StudySession
import com.example.ui.theme.*
import com.example.ui.viewmodel.JeeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun StudyLogScreen(
    viewModel: JeeViewModel,
    modifier: Modifier = Modifier
) {
    val studySessions by viewModel.studySessions.collectAsStateWithLifecycle()
    var selectedSubjectFilter by remember { mutableStateOf("ALL") }
    var showLogDialog by remember { mutableStateOf(false) }
    var sessionToDelete by remember { mutableStateOf<StudySession?>(null) }

    // Aggregate statistics
    val totalSeconds = remember(studySessions) { studySessions.sumOf { it.durationSeconds } }
    val totalHours = remember(totalSeconds) { totalSeconds / 3600.0 }

    val physicsSessions = remember(studySessions) {
        studySessions.filter { it.subject.contains("PHYSIC", ignoreCase = true) }
    }
    val chemistrySessions = remember(studySessions) {
        studySessions.filter { it.subject.contains("CHEM", ignoreCase = true) }
    }
    val mathSessions = remember(studySessions) {
        studySessions.filter { it.subject.contains("MATH", ignoreCase = true) }
    }

    val physicsHours = remember(physicsSessions) { physicsSessions.sumOf { it.durationSeconds } / 3600.0 }
    val chemistryHours = remember(chemistrySessions) { chemistrySessions.sumOf { it.durationSeconds } / 3600.0 }
    val mathHours = remember(mathSessions) { mathSessions.sumOf { it.durationSeconds } / 3600.0 }

    // Filtered list
    val filteredSessions = remember(studySessions, selectedSubjectFilter) {
        when (selectedSubjectFilter) {
            "PHYSICS" -> physicsSessions
            "CHEMISTRY" -> chemistrySessions
            "MATHEMATICS" -> mathSessions
            else -> studySessions
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JEE Study Log",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Track daily hours in Room Database",
                            fontSize = 13.sp,
                            color = Color(0xFF8E8E93)
                        )
                    }

                    Button(
                        onClick = { showLogDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("log_hours_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Log",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Log Hours",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                }
            }

            // Total Hours Hero Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E)),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xFF0A84FF).copy(alpha = 0.4f), Color(0xFF30D158).copy(alpha = 0.4f), Color(0xFFFF9F0A).copy(alpha = 0.4f))
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL PREPARATION TIME",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF8E8E93),
                                    letterSpacing = 0.8.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = String.format(Locale.US, "%.1f", totalHours),
                                        fontSize = 36.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = " hours logged",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF8E8E93),
                                        modifier = Modifier.padding(bottom = 6.dp, start = 4.dp)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2C2C2E)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = null,
                                    tint = IosOrange,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Multi-color subject distribution bar
                        if (totalHours > 0) {
                            val physRatio = (physicsHours / totalHours).toFloat()
                            val chemRatio = (chemistryHours / totalHours).toFloat()
                            val mathRatio = (mathHours / totalHours).toFloat()

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF2C2C2E))
                            ) {
                                if (physRatio > 0) {
                                    Box(
                                        modifier = Modifier
                                            .weight(physRatio.coerceAtLeast(0.01f))
                                            .fillMaxHeight()
                                            .background(Color(0xFF0A84FF))
                                    )
                                }
                                if (chemRatio > 0) {
                                    Box(
                                        modifier = Modifier
                                            .weight(chemRatio.coerceAtLeast(0.01f))
                                            .fillMaxHeight()
                                            .background(Color(0xFF30D158))
                                    )
                                }
                                if (mathRatio > 0) {
                                    Box(
                                        modifier = Modifier
                                            .weight(mathRatio.coerceAtLeast(0.01f))
                                            .fillMaxHeight()
                                            .background(Color(0xFFFF9F0A))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                SubjectMiniLegend("Physics", Color(0xFF0A84FF), String.format(Locale.US, "%.1fh", physicsHours))
                                SubjectMiniLegend("Chemistry", Color(0xFF30D158), String.format(Locale.US, "%.1fh", chemistryHours))
                                SubjectMiniLegend("Math", Color(0xFFFF9F0A), String.format(Locale.US, "%.1fh", mathHours))
                            }
                        } else {
                            Text(
                                text = "No hours logged yet. Start logging your daily JEE study sessions below!",
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                    }
                }
            }

            // 3 Subject Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SubjectSummaryCard(
                        subjectName = "Physics",
                        hours = physicsHours,
                        sessionCount = physicsSessions.size,
                        color = Color(0xFF0A84FF),
                        icon = Icons.Default.Bolt,
                        isSelected = selectedSubjectFilter == "PHYSICS",
                        onClick = {
                            selectedSubjectFilter = if (selectedSubjectFilter == "PHYSICS") "ALL" else "PHYSICS"
                        },
                        modifier = Modifier.weight(1f)
                    )

                    SubjectSummaryCard(
                        subjectName = "Chemistry",
                        hours = chemistryHours,
                        sessionCount = chemistrySessions.size,
                        color = Color(0xFF30D158),
                        icon = Icons.Default.Science,
                        isSelected = selectedSubjectFilter == "CHEMISTRY",
                        onClick = {
                            selectedSubjectFilter = if (selectedSubjectFilter == "CHEMISTRY") "ALL" else "CHEMISTRY"
                        },
                        modifier = Modifier.weight(1f)
                    )

                    SubjectSummaryCard(
                        subjectName = "Maths",
                        hours = mathHours,
                        sessionCount = mathSessions.size,
                        color = Color(0xFFFF9F0A),
                        icon = Icons.Default.Calculate,
                        isSelected = selectedSubjectFilter == "MATHEMATICS",
                        onClick = {
                            selectedSubjectFilter = if (selectedSubjectFilter == "MATHEMATICS") "ALL" else "MATHEMATICS"
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LOGGED SESSIONS (${filteredSessions.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8E8E93),
                        letterSpacing = 0.5.sp
                    )

                    if (selectedSubjectFilter != "ALL") {
                        Text(
                            text = "Clear Filter",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosBlue,
                            modifier = Modifier
                                .clickable { selectedSubjectFilter = "ALL" }
                                .padding(4.dp)
                        )
                    }
                }
            }

            // Sessions List
            if (filteredSessions.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.HistoryEdu,
                                contentDescription = null,
                                tint = Color(0xFF8E8E93),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No Study Logs Found",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (selectedSubjectFilter == "ALL")
                                    "Tap '+ Log Hours' to record your study time."
                                else
                                    "No logged sessions for $selectedSubjectFilter yet.",
                                fontSize = 13.sp,
                                color = Color(0xFF8E8E93),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { showLogDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("+ Log Hours Now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(filteredSessions, key = { it.id }) { session ->
                    StudySessionItem(
                        session = session,
                        onDeleteClick = { sessionToDelete = session }
                    )
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = { showLogDialog = true },
            containerColor = IosBlue,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("log_hours_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Log Hours", modifier = Modifier.size(28.dp))
        }
    }

    // Add/Log Study Hours Dialog
    if (showLogDialog) {
        LogStudyHoursDialog(
            onDismiss = { showLogDialog = false },
            onLogSession = { subject, topic, hours, mode ->
                viewModel.logStudyHours(
                    subject = subject,
                    topic = topic,
                    hours = hours,
                    mode = mode
                )
                showLogDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    sessionToDelete?.let { session ->
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            containerColor = Color(0xFF1C1C1E),
            title = {
                Text(
                    text = "Delete Study Session?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove the log for \"${session.topic}\" (${formatDuration(session.durationSeconds)})?",
                    color = Color(0xFFC7C7CC),
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStudySession(session)
                        sessionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IosRed)
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDelete = null }) {
                    Text("Cancel", color = Color(0xFF8E8E93))
                }
            }
        )
    }
}

// -------------------------------------------------------------
// SUB-COMPONENTS
// -------------------------------------------------------------

@Composable
private fun SubjectSummaryCard(
    subjectName: String,
    hours: Double,
    sessionCount: Int,
    color: Color,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) color.copy(alpha = 0.2f) else Color(0xFF1C1C1E)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isSelected) color else Color(0xFF2C2C2E)
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = subjectName,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = "$sessionCount logs",
                    fontSize = 10.sp,
                    color = Color(0xFF8E8E93)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = subjectName,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF8E8E93)
            )

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = String.format(Locale.US, "%.1f", hours),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "h",
                    fontSize = 12.sp,
                    color = color,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 2.dp, start = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun SubjectMiniLegend(name: String, color: Color, hoursText: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "$name: $hoursText",
            fontSize = 11.sp,
            color = Color(0xFFC7C7CC)
        )
    }
}

@Composable
private fun StudySessionItem(
    session: StudySession,
    onDeleteClick: () -> Unit
) {
    val subjectColor = when {
        session.subject.contains("PHYSIC", ignoreCase = true) -> Color(0xFF0A84FF)
        session.subject.contains("CHEM", ignoreCase = true) -> Color(0xFF30D158)
        else -> Color(0xFFFF9F0A)
    }

    val subjectIcon = when {
        session.subject.contains("PHYSIC", ignoreCase = true) -> Icons.Default.Bolt
        session.subject.contains("CHEM", ignoreCase = true) -> Icons.Default.Science
        else -> Icons.Default.Calculate
    }

    val formattedDate = remember(session.timestamp) {
        val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
        sdf.format(Date(session.timestamp))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("session_item_${session.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF2C2C2E))
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Subject Indicator Circle
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(subjectColor.copy(alpha = 0.15f))
                    .border(1.5.dp, subjectColor.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = subjectIcon,
                    contentDescription = session.subject,
                    tint = subjectColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Topic and metadata
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = session.subject.replace("_", " "),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = subjectColor,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "•",
                        fontSize = 11.sp,
                        color = Color(0xFF636366)
                    )
                    Text(
                        text = session.mode.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() },
                        fontSize = 11.sp,
                        color = Color(0xFF8E8E93)
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = session.topic,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = formattedDate,
                    fontSize = 11.sp,
                    color = Color(0xFF636366)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Duration Pill & Delete
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(subjectColor.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = formatDuration(session.durationSeconds),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = subjectColor
                    )
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("delete_session_${session.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete log",
                        tint = Color(0xFF636366),
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun LogStudyHoursDialog(
    onDismiss: () -> Unit,
    onLogSession: (subject: String, topic: String, hours: Double, mode: String) -> Unit
) {
    var selectedSubject by remember { mutableStateOf("PHYSICS") }
    var topicName by remember { mutableStateOf("") }
    var hoursInput by remember { mutableStateOf("2.0") }
    var selectedMode by remember { mutableStateOf("PROBLEM_SOLVING") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val presetDurations = listOf(
        Pair("30m", 0.5),
        Pair("1h", 1.0),
        Pair("1.5h", 1.5),
        Pair("2h", 2.0),
        Pair("2.5h", 2.5),
        Pair("3h", 3.0),
        Pair("4h", 4.0)
    )

    val studyModes = listOf(
        Pair("Problem Solving", "PROBLEM_SOLVING"),
        Pair("Theory & Notes", "THEORY_PRACTICE"),
        Pair("Revision", "REVISION"),
        Pair("Mock / PYQs", "MOCK_TEST")
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1E)),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF38383A))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Log Study Hours",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF8E8E93))
                    }
                }

                // 1. Select Subject (3 Cards)
                Text(
                    text = "SELECT SUBJECT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8E8E93),
                    letterSpacing = 0.5.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubjectSelectChip(
                        name = "Physics",
                        code = "PHYSICS",
                        color = Color(0xFF0A84FF),
                        icon = Icons.Default.Bolt,
                        isSelected = selectedSubject == "PHYSICS",
                        onClick = { selectedSubject = "PHYSICS" },
                        modifier = Modifier.weight(1f)
                    )

                    SubjectSelectChip(
                        name = "Chemistry",
                        code = "CHEMISTRY",
                        color = Color(0xFF30D158),
                        icon = Icons.Default.Science,
                        isSelected = selectedSubject == "CHEMISTRY",
                        onClick = { selectedSubject = "CHEMISTRY" },
                        modifier = Modifier.weight(1f)
                    )

                    SubjectSelectChip(
                        name = "Maths",
                        code = "MATHEMATICS",
                        color = Color(0xFFFF9F0A),
                        icon = Icons.Default.Calculate,
                        isSelected = selectedSubject == "MATHEMATICS",
                        onClick = { selectedSubject = "MATHEMATICS" },
                        modifier = Modifier.weight(1f)
                    )
                }

                // 2. Topic / Chapter Name
                OutlinedTextField(
                    value = topicName,
                    onValueChange = { topicName = it },
                    label = { Text("Topic or Chapter Name") },
                    placeholder = {
                        Text(
                            when (selectedSubject) {
                                "PHYSICS" -> "e.g. Rotational Motion, Thermodynamics"
                                "CHEMISTRY" -> "e.g. Organic Reaction Mechanisms, Equilibrium"
                                else -> "e.g. Definite Integration, Conic Sections"
                            },
                            fontSize = 12.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = IosBlue,
                        unfocusedBorderColor = Color(0xFF38383A)
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("log_topic_input")
                )

                // 3. Hours Spent
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HOURS SPENT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8E8E93),
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "$hoursInput hours",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0A84FF)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Preset Quick Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(presetDurations) { (label, hrs) ->
                            val isSelected = hoursInput == hrs.toString()
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) IosBlue else Color(0xFF2C2C2E))
                                    .clickable { hoursInput = hrs.toString() }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color(0xFFC7C7CC)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = hoursInput,
                        onValueChange = {
                            hoursInput = it
                            errorMessage = null
                        },
                        label = { Text("Custom Hours (decimal)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = IosBlue,
                            unfocusedBorderColor = Color(0xFF38383A)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("log_hours_input")
                    )
                }

                // 4. Study Mode
                Column {
                    Text(
                        text = "STUDY TYPE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF8E8E93),
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        studyModes.forEach { (label, code) ->
                            val isSelected = selectedMode == code
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0xFF3A3A3C) else Color(0xFF242426))
                                    .border(
                                        1.dp,
                                        if (isSelected) IosBlue else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedMode = code }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else Color(0xFF8E8E93),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                errorMessage?.let { err ->
                    Text(
                        text = err,
                        color = IosRed,
                        fontSize = 12.sp
                    )
                }

                // 5. Submit Button
                Button(
                    onClick = {
                        val parsedHours = hoursInput.toDoubleOrNull()
                        if (parsedHours == null || parsedHours <= 0) {
                            errorMessage = "Please enter a valid positive number of hours (e.g. 1.5)"
                            return@Button
                        }
                        if (parsedHours > 24) {
                            errorMessage = "Hours cannot exceed 24 in a single session"
                            return@Button
                        }
                        onLogSession(
                            selectedSubject,
                            topicName.trim(),
                            parsedHours,
                            selectedMode
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_log_hours_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Save to Room Database",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun SubjectSelectChip(
    name: String,
    code: String,
    color: Color,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) color.copy(alpha = 0.25f) else Color(0xFF242426))
            .border(
                1.5.dp,
                if (isSelected) color else Color(0xFF38383A),
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = name,
                tint = if (isSelected) color else Color(0xFF8E8E93),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = name,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF8E8E93)
            )
        }
    }
}

private fun formatDuration(durationSeconds: Long): String {
    val hours = durationSeconds / 3600
    val minutes = (durationSeconds % 3600) / 60
    return when {
        hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
        hours > 0 -> "${hours}h"
        minutes > 0 -> "${minutes}m"
        else -> "${durationSeconds}s"
    }
}
