package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "formula_cards")
data class FormulaCard(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subject: String, // "PHYSICS", "CHEMISTRY", "MATHEMATICS"
    val chapter: String,
    val title: String,
    val formulaLatex: String,
    val keyVariables: String = "",
    val tips: String = "",
    val keyConcept: String = "",
    val isCustom: Boolean = false,
    val isBookmarked: Boolean = false
)
