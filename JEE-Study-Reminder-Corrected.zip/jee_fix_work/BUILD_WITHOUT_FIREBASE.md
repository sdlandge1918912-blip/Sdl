# Build JEE Reminder without Firebase configuration

This project can compile without `app/google-services.json`. The Google Services Gradle plugin is applied only when that file exists.

## Build a debug APK
1. Install Android Studio (or use GitHub Actions) with JDK 21 and Android SDK Platform 35.
2. Open this folder as a Gradle project and sync.
3. Run `./gradlew assembleDebug`.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## What works without Firebase
- Local app features backed by the on-device Room database remain available.
- Parent dashboard sync and Google sign-in require a correctly configured Firebase project and `app/google-services.json`; without it, those sync features are disabled/unavailable.
- This does not migrate or erase data from an already-installed app. Keep the original app installed and back up data before replacing it.

A build was not executed in this editing environment because the Gradle distribution could not be downloaded (network access unavailable). Build on Android Studio or GitHub Actions to confirm compilation.
